import { NextRequest, NextResponse } from "next/server";

import { guardAdmin } from "@/lib/adminGuard";
import { setKeyStatus, getKeyById, deleteKey } from "@/lib/db";

type Params = { params: Promise<{ id: string }> };

/** Parses the route segment, rejecting anything that is not a positive int. */
function parseId(raw: string): number | null {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export async function DELETE(req: NextRequest, ctx: Params) {
  const blocked = await guardAdmin(req, { write: true });
  if (blocked) return blocked;

  const { id } = await ctx.params;
  const keyId = parseId(id);
  if (keyId === null || !getKeyById(keyId)) {
    return NextResponse.json({ success: false, error: "Key not found" }, { status: 404 });
  }

  deleteKey(keyId);
  return NextResponse.json({ success: true });
}

export async function PATCH(req: NextRequest, ctx: Params) {
  const blocked = await guardAdmin(req, { write: true });
  if (blocked) return blocked;

  const { id } = await ctx.params;
  const keyId = parseId(id);
  const key = keyId === null ? undefined : getKeyById(keyId);
  if (!key) {
    return NextResponse.json({ success: false, error: "Key not found" }, { status: 404 });
  }

  let action = "disable";
  try {
    const body = await req.json();
    action = body?.action === "enable" ? "enable" : "disable";
  } catch {
    action = "disable";
  }

  // Keys that have already been used cannot be re-enabled (single-use rule).
  if (action === "enable" && key.status === "used") {
    return NextResponse.json(
      { success: false, error: "A used key cannot be re-enabled" },
      { status: 400 }
    );
  }

  setKeyStatus(key.id, action === "enable" ? "available" : "disabled");
  return NextResponse.json({ success: true });
}
