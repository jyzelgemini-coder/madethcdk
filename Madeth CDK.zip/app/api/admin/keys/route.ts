import { NextRequest, NextResponse } from "next/server";

import { guardAdmin } from "@/lib/adminGuard";
import { ensureCsrfToken } from "@/lib/csrf";
import { createKey, deleteKeys, listKeys, getKeyStats } from "@/lib/db";
import {
  isValidCdkCode,
  isValidTaskCount,
  isValidPlan,
  isSuspiciousInput,
} from "@/lib/validation";

/** Hard ceiling per request so a single call cannot be used to exhaust the box. */
const MAX_CODES_PER_REQUEST = 1000;

export async function GET(req: NextRequest) {
  const blocked = await guardAdmin(req);
  if (blocked) return blocked;

  const limit = Math.min(Math.max(Number(req.nextUrl.searchParams.get("limit")) || 200, 1), 1000);
  return NextResponse.json({
    success: true,
    keys: listKeys(limit),
    stats: getKeyStats(),
    csrfToken: await ensureCsrfToken(),
  });
}

export async function POST(req: NextRequest) {
  const blocked = await guardAdmin(req, { write: true });
  if (blocked) return blocked;

  try {
    const body = await req.json();
    const codes: unknown[] = Array.isArray(body?.codes) ? body.codes : [];
    const taskCount = Math.max(1, Number(body?.taskCount) || 1);
    const plan = (body?.plan ?? "").toString();

    if (!isValidTaskCount(taskCount)) {
      return NextResponse.json({ success: false, error: "Invalid task count (must be 1-1000)" }, { status: 400 });
    }
    if (plan && (!isValidPlan(plan) || isSuspiciousInput(plan))) {
      return NextResponse.json({ success: false, error: "Invalid plan name" }, { status: 400 });
    }
    if (!codes.length) {
      return NextResponse.json({ success: false, error: "No codes provided" }, { status: 400 });
    }
    if (codes.length > MAX_CODES_PER_REQUEST) {
      return NextResponse.json(
        { success: false, error: `Too many codes in one request (max ${MAX_CODES_PER_REQUEST})` },
        { status: 400 }
      );
    }

    // Validate everything before writing anything, so a bad batch is rejected
    // whole rather than half-applied.
    const normalized: string[] = [];
    for (const raw of codes) {
      if (typeof raw !== "string") {
        return NextResponse.json({ success: false, error: "Codes must be strings" }, { status: 400 });
      }
      const code = raw.trim().toUpperCase();
      if (!code) continue;
      if (isSuspiciousInput(code) || !isValidCdkCode(code)) {
        // Echo only a short slice: the input is untrusted and this lands in a UI.
        return NextResponse.json(
          { success: false, error: `Invalid CDK format: ${code.slice(0, 40)}` },
          { status: 400 }
        );
      }
      normalized.push(code);
    }

    const created: string[] = [];
    const duplicates: string[] = [];
    const seen = new Set<string>();

    for (const code of normalized) {
      // A code repeated inside one request is a duplicate too.
      if (seen.has(code)) {
        duplicates.push(code);
        continue;
      }
      seen.add(code);

      // createKey returns null when the code already exists, so uniqueness is
      // decided by the table itself rather than a racy check-then-insert.
      if (createKey({ code, taskCount, plan })) created.push(code);
      else duplicates.push(code);
    }

    return NextResponse.json({ success: true, created, duplicates });
  } catch {
    return NextResponse.json({ success: false, error: "Bad request" }, { status: 400 });
  }
}

/** Bulk delete. The client sends the exact ids it is showing the admin. */
export async function DELETE(req: NextRequest) {
  const blocked = await guardAdmin(req, { write: true });
  if (blocked) return blocked;

  try {
    const body = await req.json();
    const raw: unknown[] = Array.isArray(body?.ids) ? body.ids : [];
    if (!raw.length) {
      return NextResponse.json({ success: false, error: "No keys selected" }, { status: 400 });
    }
    if (raw.length > MAX_CODES_PER_REQUEST) {
      return NextResponse.json({ success: false, error: "Too many keys in one request" }, { status: 400 });
    }

    const ids = raw.map(Number).filter((n) => Number.isInteger(n) && n > 0);
    if (ids.length !== raw.length) {
      return NextResponse.json({ success: false, error: "Invalid key id" }, { status: 400 });
    }

    return NextResponse.json({ success: true, deleted: deleteKeys(ids) });
  } catch {
    return NextResponse.json({ success: false, error: "Bad request" }, { status: 400 });
  }
}
