import { NextRequest, NextResponse } from "next/server";

import { createSession, destroySession } from "@/lib/auth";
import { clearCsrfToken, generateCsrfToken } from "@/lib/csrf";
import { getClientIp, isCrossSite } from "@/lib/net";
import { hit, reset } from "@/lib/ratelimit";
import { seedAdmin } from "@/lib/seed";
import { isValidUsername, isValidPassword, isSuspiciousInput } from "@/lib/validation";

/** Deliberately identical for every failure, so nothing can be enumerated. */
const GENERIC_FAILURE = "Invalid credentials";

const TOO_MANY = NextResponse.json(
  { success: false, error: "Too many attempts. Try again in a minute." },
  { status: 429, headers: { "retry-after": "60" } }
);

export async function POST(req: NextRequest) {
  seedAdmin();
  try {
    if (isCrossSite(req)) {
      return NextResponse.json({ success: false, error: "Cross-site request blocked" }, { status: 403 });
    }

    const ip = getClientIp(req);

    // Per-IP throttle when we can attribute the request, plus a global ceiling
    // that still applies when we cannot (or when the attacker spreads out).
    if (ip && hit(`login:${ip}`, 5, 60_000).limited) return TOO_MANY;
    if (hit("login:global", 60, 60_000).limited) return TOO_MANY;

    const body = await req.json();
    const username = (body?.username ?? "").toString().trim();
    const password = (body?.password ?? "").toString();

    // Every rejection below returns the same message and status: telling the
    // caller *why* the attempt failed only helps someone probing the form.
    if (
      !username ||
      !password ||
      isSuspiciousInput(username) ||
      !isValidUsername(username) ||
      !isValidPassword(password)
    ) {
      return NextResponse.json({ success: false, error: GENERIC_FAILURE }, { status: 401 });
    }

    // Throttle per account as well, so one username cannot be sprayed from many
    // addresses without tripping a limit.
    if (hit(`login:user:${username.toLowerCase()}`, 10, 60_000).limited) return TOO_MANY;

    if (!(await createSession(username, password))) {
      return NextResponse.json({ success: false, error: GENERIC_FAILURE }, { status: 401 });
    }

    if (ip) reset(`login:${ip}`);
    reset(`login:user:${username.toLowerCase()}`);

    return NextResponse.json({ success: true, csrfToken: await generateCsrfToken() });
  } catch {
    return NextResponse.json({ success: false, error: GENERIC_FAILURE }, { status: 401 });
  }
}

export async function DELETE() {
  await destroySession();
  await clearCsrfToken();
  return NextResponse.json({ success: true });
}
