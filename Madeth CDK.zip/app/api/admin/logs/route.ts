import { NextRequest, NextResponse } from "next/server";

import { guardAdmin } from "@/lib/adminGuard";
import { ensureCsrfToken } from "@/lib/csrf";
import {
  ACTIVATION_STATUSES,
  getActivationStats,
  listActivations,
  type ActivationStatus,
} from "@/lib/db";

const MAX_LIMIT = 200;

function clampInt(raw: string | null, fallback: number, min: number, max: number): number {
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

/** Activation log for the admin panel: who redeemed which code, and when. */
export async function GET(req: NextRequest) {
  const blocked = await guardAdmin(req);
  if (blocked) return blocked;

  const params = req.nextUrl.searchParams;
  const limit = clampInt(params.get("limit"), 50, 1, MAX_LIMIT);
  const offset = clampInt(params.get("offset"), 0, 0, Number.MAX_SAFE_INTEGER);

  const rawStatus = params.get("status");
  const status = ACTIVATION_STATUSES.includes(rawStatus as ActivationStatus)
    ? (rawStatus as ActivationStatus)
    : null;

  // Long search strings only cost us CPU, so cap before touching SQLite.
  const search = (params.get("q") || "").trim().slice(0, 100) || null;

  const { rows, total } = listActivations({ limit, offset, status, search });

  return NextResponse.json({
    success: true,
    total,
    limit,
    offset,
    stats: getActivationStats(),
    logs: rows.map((r) => ({
      taskId: r.id,
      code: r.code,
      email: r.email,
      status: r.status,
      progress: r.progress,
      message: r.message,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      pixelJobId: r.pixel_job_id,
      ip: r.ip,
      userAgent: r.user_agent,
      plan: r.plan,
      keyStatus: r.key_status,
    })),
    csrfToken: await ensureCsrfToken(),
  });
}
