import crypto from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

import { claimKey, createTask, releaseKey } from "@/lib/db";
import { defaultLang, type Lang } from "@/lib/i18n";
import { getClientIp, getUserAgent, readJsonBody } from "@/lib/net";
import { mapError, normalizeSecret, submitJob } from "@/lib/pixel";
import { hit } from "@/lib/ratelimit";
import {
  isValidCdkCode,
  isValidEmail,
  isValidPassword,
  isValid2FASecret,
  isSuspiciousInput,
} from "@/lib/validation";

const ID_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

/**
 * Task ids are handed out to the buyer and are the only thing needed to read a
 * task's progress, so they carry 60 bits of randomness. The earlier format used
 * 3 random bytes behind a plaintext timestamp, which left only ~16 million
 * candidates for a given minute — cheap to enumerate.
 */
function makeTaskId(): string {
  const bytes = crypto.randomBytes(12);
  let out = "";
  for (const b of bytes) out += ID_ALPHABET[b % ID_ALPHABET.length];
  return `T-${Date.now().toString(36).toUpperCase()}-${out}`;
}

function pickLang(raw: unknown): Lang {
  return raw === "en" || raw === "km" || raw === "zh" ? raw : defaultLang;
}

/**
 * Activates a CDK key by enqueuing a Pixel job.
 *
 * The key is claimed BEFORE the Pixel submission, so a code can never enqueue
 * two upstream jobs: whoever loses the atomic claim is rejected without any
 * outside work happening. If the submission is then rejected (bad password
 * format, upstream outage, insufficient credit) the key is released so the
 * customer can retry with the same code.
 */
export async function POST(req: NextRequest) {
  let lang: Lang = defaultLang;

  try {
    const parsed = await readJsonBody<Record<string, unknown>>(req, 4_096);
    if (!parsed.ok) {
      return NextResponse.json(
        { success: false, error: parsed.tooLarge ? "Request too large" : "Bad request" },
        { status: parsed.tooLarge ? 413 : 400 }
      );
    }
    const body = parsed.data;
    lang = pickLang(body?.lang);

    const code = (body?.code || "").toString().trim().toUpperCase();
    const email = (body?.email || "").toString().trim().toLowerCase();
    const password = (body?.password || "").toString();
    const twofaRaw = (body?.twofa || "").toString();

    // Comprehensive input validation
    if (!code || !email || !password || !twofaRaw.trim()) {
      return NextResponse.json(
        { success: false, error: "Missing required fields (code, email, password, twofa)" },
        { status: 400 }
      );
    }

    // Check for injection attempts
    if (isSuspiciousInput(code) || isSuspiciousInput(email)) {
      return NextResponse.json(
        { success: false, error: "Invalid input detected" },
        { status: 400 }
      );
    }

    // Validate CDK code format
    if (!isValidCdkCode(code)) {
      return NextResponse.json(
        { success: false, error: "Invalid CDK code format" },
        { status: 400 }
      );
    }

    // Validate email format
    if (!isValidEmail(email)) {
      return NextResponse.json(
        { success: false, error: "Invalid email format" },
        { status: 400 }
      );
    }

    if (!email.endsWith("@gmail.com")) {
      return NextResponse.json(
        { success: false, error: mapError("invalid_email_domain", lang) },
        { status: 400 }
      );
    }

    // Validate password
    if (!isValidPassword(password)) {
      return NextResponse.json(
        { success: false, error: "Invalid password format" },
        { status: 400 }
      );
    }

    // Validate 2FA secret
    if (!isValid2FASecret(twofaRaw)) {
      return NextResponse.json(
        { success: false, error: "Invalid 2FA secret format" },
        { status: 400 }
      );
    }

    const secret = normalizeSecret(twofaRaw);
    if (!secret.ok) {
      return NextResponse.json(
        { success: false, error: mapError(secret.error, lang) },
        { status: 400 }
      );
    }

    // Throttles keyed on the submitted data rather than the caller, so they
    // still apply when someone rotates IPs to dodge the per-IP limit.
    const ip = getClientIp(req);
    if (hit(`activate:email:${email}`, 5, 10 * 60_000).limited) {
      return NextResponse.json(
        { success: false, error: "Too many activation attempts for this account. Please wait." },
        { status: 429 }
      );
    }
    if (hit(`activate:code:${code}`, 10, 10 * 60_000).limited) {
      return NextResponse.json(
        { success: false, error: "Too many attempts with this code. Please wait." },
        { status: 429 }
      );
    }

    const taskId = makeTaskId();
    const claim = claimKey(code, email, taskId);

    if (!claim.ok) {
      if (claim.reason === "not_found") {
        return NextResponse.json({ success: false, error: "Invalid CDK code" }, { status: 404 });
      }
      if (claim.reason === "disabled") {
        return NextResponse.json(
          { success: false, error: "This CDK code has been disabled" },
          { status: 403 }
        );
      }
      return NextResponse.json(
        { success: false, error: "This CDK code has already been used (single-use)" },
        { status: 409 }
      );
    }

    const submitted = await submitJob({
      gmail: email,
      password,
      totp: secret.value.totp,
      backup: secret.value.backup,
    });

    if (!submitted.ok) {
      // A timeout is the one failure where the job may actually have been
      // enqueued upstream, so leave a trail before handing the code back.
      if (submitted.error === "upstream_timeout") {
        console.warn(
          `[activate] submit timed out for code ${code} (${email}); releasing key — verify no duplicate job upstream`
        );
      }
      releaseKey(claim.key.id);
      return NextResponse.json(
        { success: false, error: mapError(submitted.error, lang) },
        { status: submitted.status }
      );
    }

    createTask({
      id: taskId,
      code,
      email,
      pixelJobId: submitted.jobId,
      ip,
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      taskId,
      message: "Activation started",
    });
  } catch {
    return NextResponse.json({ success: false, error: "Bad request" }, { status: 400 });
  }
}
