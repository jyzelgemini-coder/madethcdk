import { NextRequest, NextResponse } from "next/server";

import { getKeyByCode } from "@/lib/db";
import { readJsonBody } from "@/lib/net";
import { isValidCdkCode, isSuspiciousInput } from "@/lib/validation";

/**
 * Reports whether a code can still be redeemed.
 *
 * This is necessarily an oracle for code validity, so it returns nothing beyond
 * what the caller already supplied plus what they need to see before entering
 * account details. Guessing is bounded by the per-IP and global limits in the
 * middleware, on top of a ~4.6e8 code space.
 */
export async function POST(req: NextRequest) {
  const parsed = await readJsonBody<Record<string, unknown>>(req, 1_024);
  if (!parsed.ok) {
    return NextResponse.json(
      { success: false, error: parsed.tooLarge ? "Request too large" : "Bad request" },
      { status: parsed.tooLarge ? 413 : 400 }
    );
  }

  const code = (parsed.data?.code || "").toString().trim().toUpperCase();
  if (!code) {
    return NextResponse.json({ success: false, error: "Code is required" }, { status: 400 });
  }
  if (isSuspiciousInput(code) || !isValidCdkCode(code)) {
    return NextResponse.json({ success: false, error: "Invalid CDK code format" }, { status: 400 });
  }

  const key = getKeyByCode(code);
  if (!key) {
    return NextResponse.json({ success: false, error: "Invalid CDK code" }, { status: 404 });
  }
  if (key.status === "disabled") {
    return NextResponse.json(
      { success: false, error: "This CDK code has been disabled" },
      { status: 403 }
    );
  }
  if (key.status === "used") {
    return NextResponse.json(
      { success: false, error: "This CDK code has already been used" },
      { status: 409 }
    );
  }

  return NextResponse.json(
    {
      success: true,
      code: key.code,
      taskCount: key.task_count,
      plan: key.plan,
    },
    { headers: { "cache-control": "no-store" } }
  );
}
