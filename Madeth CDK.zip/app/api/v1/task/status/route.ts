import { NextRequest, NextResponse } from "next/server";

import { getTask, updateTask, type TaskRecord } from "@/lib/db";
import { defaultLang, type Lang } from "@/lib/i18n";
import { getJobStatus, isAutoRetry, mapError, mapProgress } from "@/lib/pixel";
import { maskEmail } from "@/lib/mask";

const TERMINAL = new Set(["completed", "failed", "cancelled"]);

function pickLang(raw: string | null): Lang {
  return raw === "en" || raw === "km" || raw === "zh" ? raw : defaultLang;
}

/**
 * Public progress payload.
 *
 * Task ids are effectively bearer tokens, so this deliberately withholds
 * anything an attacker could harvest by guessing one: the CDK code is never
 * returned, and the email is masked to just enough for the buyer to recognise
 * their own account.
 */
function respond(task: TaskRecord) {
  return NextResponse.json(
    {
      success: true,
      taskId: task.id,
      email: maskEmail(task.email),
      status: task.status,
      progress: task.progress,
      message: task.message,
      createdAt: task.created_at,
    },
    { headers: { "cache-control": "no-store" } }
  );
}

export async function GET(req: NextRequest) {
  const taskId = req.nextUrl.searchParams.get("task_id")?.trim().slice(0, 64) || "";
  const lang = pickLang(req.nextUrl.searchParams.get("lang"));

  if (!taskId) {
    return NextResponse.json({ success: false, error: "task_id is required" }, { status: 400 });
  }

  const task = getTask(taskId);
  if (!task) {
    return NextResponse.json({ success: false, error: "Task not found" }, { status: 404 });
  }

  // Terminal tasks and legacy rows without a Pixel job are served from SQLite.
  if (TERMINAL.has(task.status) || task.pixel_job_id == null) {
    return respond(task);
  }

  const job = await getJobStatus(task.pixel_job_id);
  if (!job.ok) {
    // Upstream hiccup: keep showing the last known state rather than erroring,
    // so the polling UI does not flicker.
    return respond(task);
  }

  let status = task.status;
  let progress = task.progress;
  let message = task.message;

  switch (job.status) {
    case "success":
      status = "completed";
      progress = 100;
      message = "Activation completed successfully";
      break;
    case "error":
    case "failed":
      // Pixel retries these itself (up to 3 times), so treating the first
      // report as terminal would freeze the task on a failure that the
      // upstream may still turn into a success.
      if (isAutoRetry(job.errorMsg)) {
        status = "processing";
        message = mapError(job.errorMsg, lang);
      } else {
        status = "failed";
        progress = 100;
        message = job.errorMsg
          ? mapError(job.errorMsg, lang)
          : mapError("pixel_err_unknown", lang);
      }
      break;
    case "cancelled":
      status = "cancelled";
      progress = 100;
      message = "Activation was cancelled";
      break;
    case "pending":
      status = "processing";
      progress = mapProgress(job.currentStep) ?? progress;
      message =
        job.position > 0 ? `Queued — position ${job.position}` : "Waiting for device";
      break;
    case "running":
    default:
      status = "processing";
      progress = mapProgress(job.currentStep) ?? progress;
      message = job.currentStep || message;
      break;
  }

  updateTask(taskId, { status, progress, message });

  return respond({ ...task, status, progress, message });
}
