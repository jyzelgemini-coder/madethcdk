"use client";

/**
 * Generic failure screen. React gives the client a digest instead of the real
 * error in production, and nothing here surfaces even that: stack traces,
 * messages and digests all stay server-side.
 */
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="statusPage">
      <div className="statusCard">
        <div className="statusCode">500</div>
        <h1>Something went wrong</h1>
        <p>The request could not be completed. Please try again.</p>
        <button className="statusLink" type="button" onClick={reset}>
          Try again
        </button>
      </div>
    </main>
  );
}
