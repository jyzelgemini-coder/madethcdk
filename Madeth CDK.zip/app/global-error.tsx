"use client";

/** Last-resort handler for failures thrown in the root layout itself. */
export default function GlobalError() {
  return (
    <html lang="en">
      <body>
        <main className="statusPage">
          <div className="statusCard">
            <div className="statusCode">500</div>
            <h1>Something went wrong</h1>
            <p>The request could not be completed. Please try again.</p>
            <a className="statusLink" href="/">
              Return home
            </a>
          </div>
        </main>
      </body>
    </html>
  );
}
