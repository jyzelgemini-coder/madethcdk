import SiteShell from "@/components/SiteShell";

export default function GuidePage() {
  return <SiteShell page="guide" />;
}