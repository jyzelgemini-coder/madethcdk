import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Not found",
  robots: { index: false, follow: false },
};

/**
 * Shown for every unknown path. Deliberately says nothing about what does exist,
 * which framework serves it, or why the request failed — an unknown URL and a
 * URL the visitor simply isn't allowed to see look identical from here.
 */
export default function NotFound() {
  return (
    <main className="statusPage">
      <div className="statusCard">
        <div className="statusCode">404</div>
        <h1>Page not found</h1>
        <p>The page you requested doesn&apos;t exist.</p>
        <Link className="statusLink" href="/">
          Return home
        </Link>
      </div>
    </main>
  );
}
