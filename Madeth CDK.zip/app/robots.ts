import type { MetadataRoute } from "next";

/** Keeps the panel and the API out of search indexes. */
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/api/"] }],
  };
}
