"use client";

import { useState } from "react";

import CheckMode from "@/components/CheckMode";
import SingleMode from "@/components/SingleMode";
import type { Dict, Lang } from "@/lib/i18n";

type Mode = "single" | "check";

export default function ActivatePage({ t, lang }: { t: Dict; lang: Lang }) {
  const [mode, setMode] = useState<Mode>("single");

  return (
    <div className="awrap">
      <div className="mtabs" role="tablist" aria-label="Activation mode">
        <button
          type="button"
          role="tab"
          aria-selected={mode === "single"}
          className={`mtab ${mode === "single" ? "on" : ""}`}
          onClick={() => setMode("single")}
        >
          {t.tabSingle}
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={mode === "check"}
          className={`mtab ${mode === "check" ? "on" : ""}`}
          onClick={() => setMode("check")}
        >
          {t.tabCheck}
        </button>
      </div>

      {mode === "single" ? <SingleMode t={t} lang={lang} /> : <CheckMode t={t} />}
    </div>
  );
}
