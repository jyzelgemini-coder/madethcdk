"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type KeyStatus = "available" | "used" | "disabled";

interface CdkKey {
  id: number;
  code: string;
  task_count: number;
  plan: string;
  status: KeyStatus;
  created_at: string;
  used_at: string | null;
  used_by_email: string | null;
  task_id: string | null;
}

interface Stats {
  total: number;
  available: number;
  used: number;
  disabled: number;
}

/** One redemption, as returned by /api/admin/logs. */
interface ActivationLog {
  taskId: string;
  code: string;
  email: string;
  status: string;
  progress: number;
  message: string | null;
  createdAt: string;
  updatedAt: string;
  pixelJobId: number | null;
  ip: string | null;
  userAgent: string | null;
  plan: string | null;
  keyStatus: KeyStatus | null;
}

interface LogStats {
  total: number;
  processing: number;
  completed: number;
  failed: number;
  cancelled: number;
  today: number;
}

type LogFilter = "all" | "processing" | "completed" | "failed" | "cancelled";

type Section = "dashboard" | "create" | "keys" | "logs";

interface Confirm {
  ids: number[];
  title: string;
  body: string;
  /** Bulk removals make the admin type DELETE before the button unlocks. */
  requireType: boolean;
}

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const DIGITS = "0123456789";
const WORD_LEN = 4;
const NUM_LEN = 3;
const PRESETS = [10, 25, 50, 100, 250, 500];
const MAX_BATCH = 500;
const CONFIRM_WORD = "DELETE";
const LOG_PAGE_SIZE = 50;

function pick(charset: string, n: number): string {
  const arr = new Uint8Array(n);
  crypto.getRandomValues(arr);
  let out = "";
  for (let i = 0; i < n; i++) out += charset[arr[i] % charset.length];
  return out;
}

/** MD-CDK- followed by a random 4-letter word and a random 3-digit number. */
function randomCode(): string {
  return `MD-CDK-${pick(LETTERS, WORD_LEN)}${pick(DIGITS, NUM_LEN)}`;
}

function plural(n: number, one: string, many = `${one}s`): string {
  return `${n} ${n === 1 ? one : many}`;
}

/* ---------------- icons ---------------- */

const Ico = {
  logo: (s = 34) => (
    <svg width={s} height={s} viewBox="0 0 48 48" fill="none" aria-hidden>
      <path d="M24 12L34 18.5V31L24 37.5L14 31V18.5L24 12Z" fill="url(#apg)" fillOpacity=".95" />
      <path d="M24 20a4 4 0 00-1.6 7.66V32h3.2v-4.34A4 4 0 0024 20z" fill="#04140a" />
      <defs>
        <linearGradient id="apg" x1="14" y1="12" x2="34" y2="37" gradientUnits="userSpaceOnUse">
          <stop stopColor="#22c55e" />
          <stop offset="1" stopColor="#3b82f6" />
        </linearGradient>
      </defs>
    </svg>
  ),
  grid: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path d="M3 4a1 1 0 011-1h5a1 1 0 011 1v4a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM12 3a1 1 0 00-1 1v2a1 1 0 001 1h4a1 1 0 001-1V4a1 1 0 00-1-1h-4zM11 12a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4zM3 12a1 1 0 011-1h5a1 1 0 011 1v4a1 1 0 01-1 1H4a1 1 0 01-1-1v-4z" />
    </svg>
  ),
  plus: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
  ),
  keys: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M12.5 2a5.5 5.5 0 00-5.3 6.96L2.3 13.88a1 1 0 00-.3.71V17a1 1 0 001 1h2.4a1 1 0 001-1v-1.2h1.2a1 1 0 001-1v-1.2h1.2a1 1 0 00.7-.3l.55-.54A5.5 5.5 0 1012.5 2zm1.9 4.7a1.3 1.3 0 112.6 0 1.3 1.3 0 01-2.6 0z" clipRule="evenodd" />
    </svg>
  ),
  home: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path d="M10.7 2.3a1 1 0 00-1.4 0l-7 7a1 1 0 101.4 1.4L4 10.4V17a1 1 0 001 1h2.5a1 1 0 001-1v-3h3v3a1 1 0 001 1H15a1 1 0 001-1v-6.6l.3.3a1 1 0 001.4-1.4l-7-7z" />
    </svg>
  ),
  book: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-9-4a1 1 0 112 0 1 1 0 01-2 0zm.5 3a1 1 0 00-1 1v4a1 1 0 102 0v-4a1 1 0 00-1-1z" clipRule="evenodd" />
    </svg>
  ),
  logout: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M3 4a2 2 0 012-2h4a1 1 0 010 2H5v12h4a1 1 0 110 2H5a2 2 0 01-2-2V4zm10.3 3.3a1 1 0 011.4 0l2.5 2.5a1 1 0 010 1.4l-2.5 2.5a1 1 0 01-1.4-1.4l.8-.8H9a1 1 0 110-2h5.1l-.8-.8a1 1 0 010-1.4z" clipRule="evenodd" />
    </svg>
  ),
  burger: (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
    </svg>
  ),
  search: (
    <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M10.44 10.44a1 1 0 011.42 0l3.85 3.85a1 1 0 01-1.42 1.42l-3.85-3.85a1 1 0 010-1.42zM6.5 12a5.5 5.5 0 100-11 5.5 5.5 0 000 11z" clipRule="evenodd" />
    </svg>
  ),
  x: (s = 13) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M4.3 3.3a1 1 0 011.4 0L8 5.6l2.3-2.3a1 1 0 111.4 1.4L9.4 7l2.3 2.3a1 1 0 01-1.4 1.4L8 8.4l-2.3 2.3a1 1 0 01-1.4-1.4L6.6 7 4.3 4.7a1 1 0 010-1.4z" />
    </svg>
  ),
  trash: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 14 14" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M5 1a1 1 0 011-1h2a1 1 0 011 1v1h3a1 1 0 110 2h-1v7a2 2 0 01-2 2H5a2 2 0 01-2-2V4H2a1 1 0 010-2h3V1zm.8 4a.8.8 0 01.8.8v4.4a.8.8 0 01-1.6 0V5.8A.8.8 0 015.8 5zm3.2.8a.8.8 0 00-1.6 0v4.4a.8.8 0 001.6 0V5.8z" clipRule="evenodd" />
    </svg>
  ),
  copy: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M5 0a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V2a2 2 0 00-2-2H5zm0 1.5h6a.5.5 0 01.5.5v8a.5.5 0 01-.5.5H5a.5.5 0 01-.5-.5V2a.5.5 0 01.5-.5z" />
      <path d="M1.5 4.5A.75.75 0 000 5.25V14a2 2 0 002 2h7a.75.75 0 000-1.5H2a.5.5 0 01-.5-.5V5.25a.75.75 0 000-.75z" />
    </svg>
  ),
  check: (s = 15) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M13.9 3.6a1 1 0 010 1.4l-6.6 6.6a1 1 0 01-1.4 0L2.1 8.1a1 1 0 111.4-1.4l2.1 2.1 5.9-5.9a1 1 0 011.4 0z" />
    </svg>
  ),
  download: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M8 1a1 1 0 011 1v6.1l1.8-1.8a1 1 0 111.4 1.4l-3.5 3.5a1 1 0 01-1.4 0L2.8 7.7a1 1 0 011.4-1.4L6 8.1V2a1 1 0 011-1h1z" />
      <path d="M2 11a1 1 0 011 1v1.5h10V12a1 1 0 112 0v2a1 1 0 01-1 1H2a1 1 0 01-1-1v-2a1 1 0 011-1z" />
    </svg>
  ),
  warn: (s = 20) => (
    <svg width={s} height={s} viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M8.26 2.6a2 2 0 013.48 0l6.5 11.5A2 2 0 0116.5 17h-13a2 2 0 01-1.74-2.9l6.5-11.5zM10 6a1 1 0 011 1v4a1 1 0 11-2 0V7a1 1 0 011-1zm0 9.2a1.2 1.2 0 100-2.4 1.2 1.2 0 000 2.4z" clipRule="evenodd" />
    </svg>
  ),
  lock: (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="currentColor" aria-hidden>
      <path fillRule="evenodd" d="M7 0a3.2 3.2 0 00-3.2 3.2V5H3a1 1 0 00-1 1v7a1 1 0 001 1h8a1 1 0 001-1V6a1 1 0 00-1-1h-.8V3.2A3.2 3.2 0 007 0zm1.8 5V3.2a1.8 1.8 0 10-3.6 0V5h3.6z" clipRule="evenodd" />
    </svg>
  ),
  empty: (
    <svg width="46" height="46" viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden>
      <rect x="7" y="12" width="34" height="26" rx="4" />
      <path d="M7 21h34M16 30h8" strokeLinecap="round" />
    </svg>
  ),
  minus: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" aria-hidden>
      <path d="M2 6h10v2H2z" />
    </svg>
  ),
  plusSm: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" aria-hidden>
      <path d="M6 2h2v4h4v2H8v4H6V8H2V6h4V2z" />
    </svg>
  ),
  activity: (
    <svg width="19" height="19" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path
        fillRule="evenodd"
        d="M7.7 2.4a1 1 0 01.93.64l3.4 8.84 1.5-3.32a1 1 0 01.91-.59H18a1 1 0 110 2h-3l-2.3 5.1a1 1 0 01-1.84-.05L7.55 6.4 6.1 9.62a1 1 0 01-.91.59H2a1 1 0 110-2h2.55l2.2-4.87a1 1 0 01.95-.94z"
        clipRule="evenodd"
      />
    </svg>
  ),
  eye: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M8 3C4.6 3 1.9 5.2 1 8c.9 2.8 3.6 5 7 5s6.1-2.2 7-5c-.9-2.8-3.6-5-7-5zm0 8.2A3.2 3.2 0 118 4.8a3.2 3.2 0 010 6.4zm0-1.7a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
    </svg>
  ),
  refresh: (s = 14) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M8 3V1L4.5 4 8 7V5a3.5 3.5 0 11-3.5 3.5H2.8A5.2 5.2 0 108 3z" />
    </svg>
  ),
  prev: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M10.3 3.3a1 1 0 010 1.4L7 8l3.3 3.3a1 1 0 01-1.4 1.4l-4-4a1 1 0 010-1.4l4-4a1 1 0 011.4 0z" />
    </svg>
  ),
  next: (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M5.7 3.3a1 1 0 000 1.4L9 8l-3.3 3.3a1 1 0 001.4 1.4l4-4a1 1 0 000-1.4l-4-4a1 1 0 00-1.4 0z" />
    </svg>
  ),
};

export default function AdminPanel() {
  /* ---------------- auth ---------------- */
  const [authed, setAuthed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [sessionUser, setSessionUser] = useState<string | null>(null);
  const [csrfToken, setCsrfToken] = useState("");

  /* ---------------- shell ---------------- */
  const [section, setSection] = useState<Section>("dashboard");
  const [railed, setRailed] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [notice, setNotice] = useState<{ type: "ok" | "er"; text: string } | null>(null);

  /* ---------------- data ---------------- */
  const [keys, setKeys] = useState<CdkKey[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, available: 0, used: 0, disabled: 0 });
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);

  /* ---------------- create form ---------------- */
  const [plan, setPlan] = useState("");
  const [count, setCount] = useState(10);
  const [autoGen, setAutoGen] = useState(true);
  const [manualCodes, setManualCodes] = useState("");
  const [createdCodes, setCreatedCodes] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  /* ---------------- keys table ---------------- */
  const [filter, setFilter] = useState<"all" | KeyStatus>("all");
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<Set<number>>(new Set());

  /* ---------------- activity log ---------------- */
  const [logs, setLogs] = useState<ActivationLog[]>([]);
  const [logStats, setLogStats] = useState<LogStats>({
    total: 0,
    processing: 0,
    completed: 0,
    failed: 0,
    cancelled: 0,
    today: 0,
  });
  const [logTotal, setLogTotal] = useState(0);
  const [logOffset, setLogOffset] = useState(0);
  const [logFilter, setLogFilter] = useState<LogFilter>("all");
  const [logQuery, setLogQuery] = useState("");
  const [logLoading, setLogLoading] = useState(false);
  const [logDetail, setLogDetail] = useState<ActivationLog | null>(null);

  /* ---------------- confirm modal ---------------- */
  const [confirm, setConfirm] = useState<Confirm | null>(null);
  const [confirmText, setConfirmText] = useState("");
  const [confirmBusy, setConfirmBusy] = useState(false);
  const confirmInput = useRef<HTMLInputElement | null>(null);

  const writeHeaders = (): HeadersInit => ({
    "Content-Type": "application/json",
    "x-csrf-token": csrfToken,
  });

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/keys");
    if (!res.ok) {
      setAuthed(false);
      return;
    }
    const d = (await res.json()) as {
      success: boolean;
      keys: CdkKey[];
      stats: Stats;
      csrfToken?: string;
    };
    if (d.success) {
      setKeys(d.keys);
      setStats(d.stats);
      if (d.csrfToken) setCsrfToken(d.csrfToken);
      setAuthed(true);
    }
  }, []);

  const loadLogs = useCallback(async () => {
    setLogLoading(true);
    try {
      const q = new URLSearchParams({
        limit: String(LOG_PAGE_SIZE),
        offset: String(logOffset),
      });
      if (logFilter !== "all") q.set("status", logFilter);
      if (logQuery.trim()) q.set("q", logQuery.trim());

      const res = await fetch(`/api/admin/logs?${q}`);
      if (!res.ok) {
        if (res.status === 401) setAuthed(false);
        return;
      }
      const d = (await res.json()) as {
        success: boolean;
        logs: ActivationLog[];
        stats: LogStats;
        total: number;
        csrfToken?: string;
      };
      if (d.success) {
        setLogs(d.logs);
        setLogStats(d.stats);
        setLogTotal(d.total);
        if (d.csrfToken) setCsrfToken(d.csrfToken);
      }
    } catch {
      setNotice({ type: "er", text: "Could not load the activity log" });
    } finally {
      setLogLoading(false);
    }
  }, [logOffset, logFilter, logQuery]);

  useEffect(() => {
    load().finally(() => setChecking(false));
  }, [load]);

  // Only fetch the log while its page is open, and debounce so typing in the
  // search box does not fire a request per keystroke.
  useEffect(() => {
    if (!authed || section !== "logs") return;
    const timer = setTimeout(() => void loadLogs(), logQuery ? 300 : 0);
    return () => clearTimeout(timer);
  }, [authed, section, loadLogs, logQuery]);

  // Any filter change starts a new result set, so go back to the first page.
  useEffect(() => {
    setLogOffset(0);
  }, [logFilter, logQuery]);

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(null), 4500);
    return () => clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!confirm) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeConfirm();
    };
    window.addEventListener("keydown", onKey);
    confirmInput.current?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [confirm]);

  /* ---------------- derived ---------------- */
  const filtered = useMemo(() => {
    const base = filter === "all" ? keys : keys.filter((k) => k.status === filter);
    const q = query.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      (k) =>
        k.code.toLowerCase().includes(q) ||
        (k.used_by_email || "").toLowerCase().includes(q) ||
        k.plan.toLowerCase().includes(q)
    );
  }, [keys, filter, query]);

  const recent = useMemo(() => keys.slice(0, 6), [keys]);

  // Selection only ever refers to rows the admin can currently see.
  const pickedVisible = useMemo(
    () => filtered.filter((k) => picked.has(k.id)).map((k) => k.id),
    [filtered, picked]
  );

  const allVisiblePicked = filtered.length > 0 && pickedVisible.length === filtered.length;

  /* ---------------- auth actions ---------------- */
  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const d = await res.json();
      if (d.success) {
        setPassword("");
        setSessionUser(username);
        if (d.csrfToken) setCsrfToken(d.csrfToken);
        await load();
      } else {
        setLoginError(d.error || "Login failed");
      }
    } catch {
      setLoginError("Connection error");
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    await fetch("/api/admin/login", { method: "DELETE" });
    setAuthed(false);
    setSessionUser(null);
    setCsrfToken("");
    setKeys([]);
    setStats({ total: 0, available: 0, used: 0, disabled: 0 });
    setPicked(new Set());
  };

  /* ---------------- key actions ---------------- */
  const buildCodes = (): string[] => {
    if (autoGen) {
      const n = Math.min(Math.max(1, count), MAX_BATCH);
      // Random draws can repeat, so keep drawing until the batch holds n
      // distinct codes — otherwise asking for 50 could yield 49.
      const out = new Set<string>();
      for (let guard = 0; out.size < n && guard < n * 50; guard++) out.add(randomCode());
      return [...out];
    }
    const typed = manualCodes
      .split(/\r?\n/)
      .map((s) => s.trim().toUpperCase())
      .filter(Boolean);
    return [...new Set(typed)];
  };

  const createKeys = async () => {
    const codes = buildCodes();
    if (!codes.length) {
      setNotice({ type: "er", text: "No codes to create" });
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/keys", {
        method: "POST",
        headers: writeHeaders(),
        body: JSON.stringify({ codes, taskCount: 1, plan }),
      });
      const d = await res.json();
      if (d.success) {
        setNotice({
          type: "ok",
          text: `Created ${plural(d.created.length, "key")}${
            d.duplicates.length ? `, skipped ${plural(d.duplicates.length, "duplicate")}` : ""
          }`,
        });
        setCreatedCodes(d.created);
        setCopied(false);
        setManualCodes("");
        await load();
      } else {
        setNotice({ type: "er", text: d.error || "Failed to create keys" });
      }
    } catch {
      setNotice({ type: "er", text: "Connection error" });
    } finally {
      setLoading(false);
    }
  };

  const setStatus = async (id: number, action: "disable" | "enable") => {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/keys/${id}`, {
        method: "PATCH",
        headers: writeHeaders(),
        body: JSON.stringify({ action }),
      });
      const d = await res.json();
      if (d.success) await load();
      else setNotice({ type: "er", text: d.error || "Action failed" });
    } catch {
      setNotice({ type: "er", text: "Connection error" });
    } finally {
      setBusyId(null);
    }
  };

  /* ---------------- delete flow ---------------- */
  const askDeleteOne = (key: CdkKey) =>
    setConfirm({
      ids: [key.id],
      title: "Delete this key?",
      body: `${key.code} will be permanently removed. This cannot be undone.`,
      requireType: false,
    });

  const askDeleteMany = (ids: number[], scope: string) =>
    setConfirm({
      ids,
      title: `Delete ${plural(ids.length, "key")}?`,
      body: `You are about to permanently delete ${plural(ids.length, "key")} (${scope}). This cannot be undone.`,
      requireType: true,
    });

  const closeConfirm = () => {
    setConfirm(null);
    setConfirmText("");
  };

  const runDelete = async () => {
    if (!confirm) return;
    setConfirmBusy(true);
    try {
      const single = confirm.ids.length === 1;
      const res = single
        ? await fetch(`/api/admin/keys/${confirm.ids[0]}`, {
            method: "DELETE",
            headers: { "x-csrf-token": csrfToken },
          })
        : await fetch("/api/admin/keys", {
            method: "DELETE",
            headers: writeHeaders(),
            body: JSON.stringify({ ids: confirm.ids }),
          });
      const d = await res.json();
      if (d.success) {
        const n = single ? 1 : (d.deleted as number);
        setNotice({ type: "ok", text: `Deleted ${plural(n, "key")}` });
        setPicked(new Set());
        closeConfirm();
        await load();
      } else {
        setNotice({ type: "er", text: d.error || "Delete failed" });
      }
    } catch {
      setNotice({ type: "er", text: "Connection error" });
    } finally {
      setConfirmBusy(false);
    }
  };

  /* ---------------- selection ---------------- */
  const togglePick = (id: number) => {
    setPicked((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const togglePickAll = () => {
    setPicked((prev) => {
      const next = new Set(prev);
      if (allVisiblePicked) filtered.forEach((k) => next.delete(k.id));
      else filtered.forEach((k) => next.add(k.id));
      return next;
    });
  };

  /* ---------------- misc ---------------- */
  const copyAll = async (codes: string[]) => {
    try {
      await navigator.clipboard.writeText(codes.join("\n"));
      setCopied(true);
      setNotice({ type: "ok", text: `Copied ${plural(codes.length, "key")}` });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setNotice({ type: "er", text: "Copy failed" });
    }
  };

  const copyOne = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setNotice({ type: "ok", text: `Copied ${code}` });
    } catch {
      setNotice({ type: "er", text: "Copy failed" });
    }
  };

  const downloadTxt = (codes: string[]) => {
    const blob = new Blob([codes.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    a.href = url;
    a.download = `cdk_keys_${stamp}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setNotice({ type: "ok", text: `Downloaded ${plural(codes.length, "key")}` });
  };

  /** Exports the rows currently on screen, matching what the admin can see. */
  const exportLogsCsv = () => {
    if (!logs.length) return;
    const columns: [string, (r: ActivationLog) => string][] = [
      ["Time", (r) => r.createdAt],
      ["Code", (r) => r.code],
      ["Plan", (r) => r.plan ?? ""],
      ["Email", (r) => r.email],
      ["Status", (r) => r.status],
      ["Progress", (r) => `${r.progress}%`],
      ["Details", (r) => r.message ?? ""],
      ["IP", (r) => r.ip ?? ""],
      ["User agent", (r) => r.userAgent ?? ""],
      ["Task ID", (r) => r.taskId],
      ["Pixel job", (r) => (r.pixelJobId == null ? "" : String(r.pixelJobId))],
      ["Last update", (r) => r.updatedAt],
    ];

    const rows = [
      columns.map(([head]) => head),
      ...logs.map((r) => columns.map(([, read]) => read(r))),
    ];
    const csv = rows.map((row) => row.map(csvCell).join(",")).join("\r\n");

    // The BOM makes Excel read the file as UTF-8 instead of the local codepage.
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    a.href = url;
    a.download = `cdk_activations_${stamp}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setNotice({ type: "ok", text: `Exported ${plural(logs.length, "row")}` });
  };

  const go = (s: Section) => {
    setSection(s);
    setNavOpen(false);
  };

  const toggleNav = () => {
    if (window.matchMedia("(max-width: 860px)").matches) setNavOpen((v) => !v);
    else setRailed((v) => !v);
  };

  /* ===================== BOOT ===================== */
  if (checking) {
    return (
      <div className="ap">
        <div className="ap-boot">
          <span className="ap-boot-ring" />
          <p>Loading panel</p>
        </div>
      </div>
    );
  }

  /* ===================== LOGIN ===================== */
  if (!authed) {
    return (
      <div className="ap">
        <div className="ap-auth">
          <div className="ap-auth-card">
            <div className="ap-auth-head">
              <div className="ap-auth-logo">{Ico.logo(38)}</div>
              <h1>CDK GATEWAY</h1>
              <p>Admin Control</p>
            </div>
            <form onSubmit={login} className="ap-auth-form">
              <div className="ap-field">
                <label className="ap-label" htmlFor="ap-user-input">
                  Username
                </label>
                <input
                  id="ap-user-input"
                  className="ap-input"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                  placeholder="admin"
                  required
                />
              </div>
              <div className="ap-field">
                <label className="ap-label" htmlFor="ap-pass-input">
                  Password
                </label>
                <input
                  id="ap-pass-input"
                  className="ap-input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  required
                />
              </div>
              {loginError && (
                <div className="ap-alert ap-alert-err" role="alert">
                  {Ico.warn(16)}
                  <span>{loginError}</span>
                </div>
              )}
              <button type="submit" className="ap-btn ap-btn-primary ap-btn-lg ap-btn-block" disabled={loading}>
                {loading ? <span className="ap-btn-spin" /> : null}
                {loading ? "Signing in…" : "Sign in"}
              </button>
              <Link href="/" className="ap-auth-back">
                ← Back to website
              </Link>
            </form>
          </div>
        </div>
      </div>
    );
  }

  /* ===================== PANEL ===================== */
  const crumb =
    section === "dashboard"
      ? "Dashboard"
      : section === "create"
      ? "Create Keys"
      : section === "keys"
      ? "All Keys"
      : "Activity Log";

  const logPage = Math.floor(logOffset / LOG_PAGE_SIZE) + 1;
  const logPages = Math.max(1, Math.ceil(logTotal / LOG_PAGE_SIZE));

  return (
    <div className="ap">
      <div className={`ap-shell ${railed ? "is-min" : ""}`}>
        {/* ---------- sidebar ---------- */}
        <aside className={`ap-side ${railed ? "is-min" : ""} ${navOpen ? "is-open" : ""}`}>
          <div className="ap-side-brand">
            <span className="ap-side-mark">{Ico.logo(22)}</span>
            {!railed && (
              <span className="ap-side-name">
                <b>CDK GATEWAY</b>
                <span>Admin</span>
              </span>
            )}
          </div>

          <nav className="ap-side-nav">
            <div className="ap-nav-group">
              <span className="ap-nav-heading">Management</span>
              <button
                className={`ap-nav-item ${section === "dashboard" ? "is-active" : ""}`}
                onClick={() => go("dashboard")}
                title="Dashboard"
              >
                {Ico.grid}
                {!railed && <span>Dashboard</span>}
              </button>
              <button
                className={`ap-nav-item ${section === "create" ? "is-active" : ""}`}
                onClick={() => go("create")}
                title="Create Keys"
              >
                {Ico.plus}
                {!railed && <span>Create Keys</span>}
              </button>
              <button
                className={`ap-nav-item ${section === "keys" ? "is-active" : ""}`}
                onClick={() => go("keys")}
                title="All Keys"
              >
                {Ico.keys}
                {!railed && <span>All Keys</span>}
                {!railed && <span className="ap-nav-count">{stats.total}</span>}
              </button>
              <button
                className={`ap-nav-item ${section === "logs" ? "is-active" : ""}`}
                onClick={() => go("logs")}
                title="Activity Log"
              >
                {Ico.activity}
                {!railed && <span>Activity Log</span>}
              </button>
            </div>

            <div className="ap-nav-group">
              <span className="ap-nav-heading">Shortcuts</span>
              <Link href="/" className="ap-nav-item" title="View site">
                {Ico.home}
                {!railed && <span>View site</span>}
              </Link>
              <Link href="/guide" className="ap-nav-item" title="Guide">
                {Ico.book}
                {!railed && <span>Guide</span>}
              </Link>
            </div>
          </nav>

          <div className="ap-side-foot">
            <button className="ap-nav-item ap-nav-logout" onClick={logout} title="Log out">
              {Ico.logout}
              {!railed && <span>Log out</span>}
            </button>
          </div>
        </aside>

        {navOpen && <div className="ap-side-scrim" onClick={() => setNavOpen(false)} />}

        {/* ---------- main ---------- */}
        <div className="ap-main">
          <header className="ap-top">
            <div className="ap-top-left">
              <button className="ap-burger" onClick={toggleNav} aria-label="Toggle navigation">
                {Ico.burger}
              </button>
              <div className="ap-crumb">
                <span>Admin</span>
                <span>/</span>
                <b>{crumb}</b>
              </div>
            </div>
            <div className="ap-top-right">
              <span className="ap-live">
                <i />
                ONLINE
              </span>
              <div className="ap-user">
                <span className="ap-avatar">{(sessionUser || "A")[0].toUpperCase()}</span>
                <span className="ap-user-meta">
                  <b>{sessionUser || "admin"}</b>
                  <span>Administrator</span>
                </span>
              </div>
            </div>
          </header>

          <main className="ap-body" key={section}>
            {/* ================= DASHBOARD ================= */}
            {section === "dashboard" && (
              <>
                <div className="ap-page-head">
                  <div>
                    <h1>Dashboard</h1>
                    <p>Overview of your CDK key inventory.</p>
                  </div>
                  <div className="ap-btn-row">
                    <button className="ap-btn ap-btn-outline" onClick={() => go("keys")}>
                      {Ico.keys}
                      Manage keys
                    </button>
                    <button className="ap-btn ap-btn-primary" onClick={() => go("create")}>
                      {Ico.plus}
                      Create keys
                    </button>
                  </div>
                </div>

                <div className="ap-stats">
                  <div className="ap-stat ap-stat-total">
                    <span className="ap-stat-ico">{Ico.keys}</span>
                    <span>
                      <b>{stats.total}</b>
                      <span>Total keys</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-ok">
                    <span className="ap-stat-ico">{Ico.check(19)}</span>
                    <span>
                      <b>{stats.available}</b>
                      <span>Available</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-used">
                    <span className="ap-stat-ico">{Ico.lock}</span>
                    <span>
                      <b>{stats.used}</b>
                      <span>Used</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-off">
                    <span className="ap-stat-ico">{Ico.minus}</span>
                    <span>
                      <b>{stats.disabled}</b>
                      <span>Disabled</span>
                    </span>
                  </div>
                </div>

                <div className="ap-card">
                  <div className="ap-card-head">
                    <h2>Recent keys</h2>
                    <button className="ap-btn ap-btn-ghost ap-btn-sm" onClick={() => go("keys")}>
                      View all →
                    </button>
                  </div>
                  <div className="ap-table-wrap">
                    <table className="ap-table">
                      <thead>
                        <tr>
                          <th>Code</th>
                          <th>Plan</th>
                          <th>Status</th>
                          <th>Created</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recent.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="ap-empty">
                              {Ico.empty}
                              <p>No keys yet.</p>
                              <button className="ap-btn ap-btn-primary ap-btn-sm" onClick={() => go("create")}>
                                Create your first key
                              </button>
                            </td>
                          </tr>
                        ) : (
                          recent.map((k) => (
                            <tr key={k.id}>
                              <td>
                                <code className="ap-code">{k.code}</code>
                              </td>
                              <td>{k.plan ? <span className="ap-plan">{k.plan}</span> : <span className="ap-dim">—</span>}</td>
                              <td>
                                <StatusBadge status={k.status} />
                              </td>
                              <td className="ap-muted ap-nowrap">{formatDate(k.created_at)}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {/* ================= CREATE ================= */}
            {section === "create" && (
              <>
                <div className="ap-page-head">
                  <div>
                    <h1>Create keys</h1>
                    <p>Generate single-use CDK activation keys.</p>
                  </div>
                </div>

                <div className="ap-card">
                  <div className="ap-card-head">
                    <div>
                      <h2>Configuration</h2>
                      <p>Every key is single-use and activates one task.</p>
                    </div>
                  </div>

                  <div className="ap-card-body">
                    <div className="ap-field">
                      <label className="ap-label" htmlFor="ap-plan">
                        Plan name (optional)
                      </label>
                      <input
                        id="ap-plan"
                        className="ap-input"
                        value={plan}
                        onChange={(e) => setPlan(e.target.value)}
                        placeholder="e.g. gemini-pro-pixel-1y"
                        maxLength={60}
                      />
                      <span className="ap-hint">
                        Shown to the customer when they check the code. Letters, numbers, spaces, dots,
                        dashes and underscores.
                      </span>
                    </div>

                    <div className="ap-divider" />

                    <label className="ap-switch">
                      <input
                        type="checkbox"
                        checked={autoGen}
                        onChange={(e) => setAutoGen(e.target.checked)}
                      />
                      <span className="ap-switch-track" />
                      <span className="ap-switch-text">
                        <b>Auto-generate codes</b>
                        <span>
                          {autoGen
                            ? "Unique MD-CDK-WORD123 codes are created for you"
                            : "Paste your own codes instead"}
                        </span>
                      </span>
                    </label>

                    {autoGen ? (
                      <div className="ap-field">
                        <label className="ap-label" htmlFor="ap-count">
                          How many keys
                        </label>
                        <div className="ap-stepper">
                          <button
                            type="button"
                            onClick={() => setCount((c) => Math.max(1, c - 1))}
                            disabled={count <= 1}
                            aria-label="Decrease"
                          >
                            {Ico.minus}
                          </button>
                          <input
                            id="ap-count"
                            type="number"
                            min={1}
                            max={MAX_BATCH}
                            value={count}
                            onChange={(e) =>
                              setCount(Math.min(MAX_BATCH, Math.max(1, Number(e.target.value) || 1)))
                            }
                          />
                          <button
                            type="button"
                            onClick={() => setCount((c) => Math.min(MAX_BATCH, c + 1))}
                            disabled={count >= MAX_BATCH}
                            aria-label="Increase"
                          >
                            {Ico.plusSm}
                          </button>
                        </div>
                        <div className="ap-presets">
                          {PRESETS.map((n) => (
                            <button
                              key={n}
                              type="button"
                              className={`ap-preset ${count === n ? "is-active" : ""}`}
                              onClick={() => setCount(n)}
                            >
                              {n}
                            </button>
                          ))}
                        </div>
                        <span className="ap-hint">Maximum {MAX_BATCH} keys per batch.</span>
                      </div>
                    ) : (
                      <div className="ap-field">
                        <label className="ap-label" htmlFor="ap-manual">
                          Manual codes
                        </label>
                        <textarea
                          id="ap-manual"
                          className="ap-textarea"
                          rows={7}
                          placeholder={"MD-CDK-ABC1234\nMD-CDK-XYZ5678"}
                          value={manualCodes}
                          onChange={(e) => setManualCodes(e.target.value)}
                          spellCheck={false}
                        />
                        <span className="ap-hint">
                          One code per line, format MD-CDK-XXXXXXX. Duplicates are skipped automatically.
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="ap-card-foot">
                    <button
                      className="ap-btn ap-btn-primary ap-btn-lg"
                      onClick={createKeys}
                      disabled={loading || (!autoGen && !manualCodes.trim())}
                    >
                      {loading ? <span className="ap-btn-spin" /> : Ico.plus}
                      {loading
                        ? "Creating…"
                        : autoGen
                        ? `Create ${plural(Math.min(Math.max(1, count), MAX_BATCH), "key")}`
                        : "Create keys"}
                    </button>
                  </div>
                </div>

                {createdCodes.length > 0 && (
                  <div className="ap-card ap-card-ok">
                    <div className="ap-card-head">
                      <div>
                        <h2>
                          {Ico.check()} {plural(createdCodes.length, "key")} created
                        </h2>
                        <p>Copy or download them now — single-use codes are not shown again.</p>
                      </div>
                      <div className="ap-btn-row">
                        <button className="ap-btn ap-btn-primary ap-btn-sm" onClick={() => copyAll(createdCodes)}>
                          {copied ? Ico.check(14) : Ico.copy()}
                          {copied ? "Copied" : "Copy all"}
                        </button>
                        <button className="ap-btn ap-btn-outline ap-btn-sm" onClick={() => downloadTxt(createdCodes)}>
                          {Ico.download}
                          Download .txt
                        </button>
                      </div>
                    </div>
                    <div className="ap-codes">
                      {createdCodes.map((code) => (
                        <div key={code} className="ap-code-row">
                          <code>{code}</code>
                          <button
                            className="ap-btn ap-btn-ghost ap-btn-icon"
                            onClick={() => copyOne(code)}
                            aria-label={`Copy ${code}`}
                          >
                            {Ico.copy()}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* ================= ALL KEYS ================= */}
            {section === "keys" && (
              <>
                <div className="ap-page-head">
                  <div>
                    <h1>All keys</h1>
                    <p>Filter, search, disable or delete keys.</p>
                  </div>
                  <div className="ap-btn-row">
                    <button className="ap-btn ap-btn-outline" onClick={() => go("create")}>
                      {Ico.plus}
                      Create keys
                    </button>
                    <button
                      className="ap-btn ap-btn-danger"
                      disabled={filtered.length === 0}
                      onClick={() =>
                        askDeleteMany(
                          filtered.map((k) => k.id),
                          describeScope(filter, query)
                        )
                      }
                    >
                      {Ico.trash()}
                      Delete all {filter === "all" && !query.trim() ? "" : "shown "}({filtered.length})
                    </button>
                  </div>
                </div>

                <div className="ap-card">
                  <div className="ap-toolbar">
                    <div className="ap-filters">
                      {(["all", "available", "used", "disabled"] as const).map((f) => (
                        <button
                          key={f}
                          className={`ap-filter ${filter === f ? "is-active" : ""}`}
                          onClick={() => setFilter(f)}
                        >
                          {f}
                          <i>{f === "all" ? stats.total : stats[f]}</i>
                        </button>
                      ))}
                    </div>
                    <div className="ap-search">
                      {Ico.search}
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Search code, email or plan…"
                        aria-label="Search keys"
                      />
                      {query && (
                        <button
                          className="ap-search-clear"
                          onClick={() => setQuery("")}
                          aria-label="Clear search"
                        >
                          {Ico.x(11)}
                        </button>
                      )}
                    </div>
                  </div>

                  {pickedVisible.length > 0 && (
                    <div className="ap-bulk">
                      <span>
                        <b>{plural(pickedVisible.length, "key")}</b> selected
                      </span>
                      <div className="ap-btn-row">
                        <button className="ap-btn ap-btn-ghost ap-btn-sm" onClick={() => setPicked(new Set())}>
                          Clear
                        </button>
                        <button
                          className="ap-btn ap-btn-danger ap-btn-sm"
                          onClick={() => askDeleteMany(pickedVisible, "selected rows")}
                        >
                          {Ico.trash()}
                          Delete selected
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="ap-table-wrap">
                    <table className="ap-table">
                      <thead>
                        <tr>
                          <th className="ap-col-pick">
                            <PickBox
                              checked={allVisiblePicked}
                              indeterminate={pickedVisible.length > 0 && !allVisiblePicked}
                              onChange={togglePickAll}
                              label="Select all shown"
                              disabled={filtered.length === 0}
                            />
                          </th>
                          <th>Code</th>
                          <th>Plan</th>
                          <th>Status</th>
                          <th>Used by</th>
                          <th>Created</th>
                          <th className="ap-col-act">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filtered.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="ap-empty">
                              {Ico.empty}
                              <p>{keys.length === 0 ? "No keys yet." : "No keys match this filter."}</p>
                              {keys.length > 0 && (
                                <button
                                  className="ap-btn ap-btn-outline ap-btn-sm"
                                  onClick={() => {
                                    setFilter("all");
                                    setQuery("");
                                  }}
                                >
                                  Reset filters
                                </button>
                              )}
                            </td>
                          </tr>
                        ) : (
                          filtered.map((k) => (
                            <tr key={k.id} className={picked.has(k.id) ? "is-picked" : ""}>
                              <td>
                                <PickBox
                                  checked={picked.has(k.id)}
                                  onChange={() => togglePick(k.id)}
                                  label={`Select ${k.code}`}
                                />
                              </td>
                              <td>
                                <code className="ap-code">{k.code}</code>
                              </td>
                              <td>{k.plan ? <span className="ap-plan">{k.plan}</span> : <span className="ap-dim">—</span>}</td>
                              <td>
                                <StatusBadge status={k.status} />
                              </td>
                              <td className="ap-muted">{k.used_by_email || <span className="ap-dim">—</span>}</td>
                              <td className="ap-muted ap-nowrap">{formatDate(k.created_at)}</td>
                              <td className="ap-col-act">
                                <span className="ap-acts">
                                  {k.status === "available" && (
                                    <button
                                      className="ap-btn ap-btn-outline ap-btn-xs"
                                      disabled={busyId === k.id}
                                      onClick={() => setStatus(k.id, "disable")}
                                    >
                                      Disable
                                    </button>
                                  )}
                                  {k.status === "disabled" && (
                                    <button
                                      className="ap-btn ap-btn-outline ap-btn-xs"
                                      disabled={busyId === k.id}
                                      onClick={() => setStatus(k.id, "enable")}
                                    >
                                      Enable
                                    </button>
                                  )}
                                  {k.status === "used" && (
                                    <span className="ap-lock">
                                      {Ico.lock}
                                      Locked
                                    </span>
                                  )}
                                  <button
                                    className="ap-btn ap-btn-danger ap-btn-icon"
                                    disabled={busyId === k.id}
                                    onClick={() => askDeleteOne(k)}
                                    aria-label={`Delete ${k.code}`}
                                    title="Delete key"
                                  >
                                    {Ico.trash()}
                                  </button>
                                </span>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {/* ================= ACTIVITY LOG ================= */}
            {section === "logs" && (
              <>
                <div className="ap-page-head">
                  <div>
                    <h1>Activity log</h1>
                    <p>Every code redemption, who used it, and how it ended.</p>
                  </div>
                  <div className="ap-btn-row">
                    <button
                      className="ap-btn ap-btn-outline"
                      onClick={() => void loadLogs()}
                      disabled={logLoading}
                    >
                      {logLoading ? <span className="ap-btn-spin" /> : Ico.refresh()}
                      Refresh
                    </button>
                    <button
                      className="ap-btn ap-btn-primary"
                      onClick={exportLogsCsv}
                      disabled={logs.length === 0}
                    >
                      {Ico.download}
                      Export CSV
                    </button>
                  </div>
                </div>

                <div className="ap-stats">
                  <div className="ap-stat ap-stat-total">
                    <span className="ap-stat-ico">{Ico.activity}</span>
                    <span>
                      <b>{logStats.total}</b>
                      <span>Total activations</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-ok">
                    <span className="ap-stat-ico">{Ico.check(19)}</span>
                    <span>
                      <b>{logStats.completed}</b>
                      <span>Completed</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-used">
                    <span className="ap-stat-ico">{Ico.refresh(18)}</span>
                    <span>
                      <b>{logStats.processing}</b>
                      <span>In progress</span>
                    </span>
                  </div>
                  <div className="ap-stat ap-stat-off">
                    <span className="ap-stat-ico">{Ico.warn(19)}</span>
                    <span>
                      <b>{logStats.failed + logStats.cancelled}</b>
                      <span>Failed or cancelled</span>
                    </span>
                  </div>
                </div>

                <div className="ap-card">
                  <div className="ap-toolbar">
                    <div className="ap-filters">
                      {(["all", "processing", "completed", "failed", "cancelled"] as const).map((f) => (
                        <button
                          key={f}
                          className={`ap-filter ${logFilter === f ? "is-active" : ""}`}
                          onClick={() => setLogFilter(f)}
                        >
                          {f}
                          <i>{f === "all" ? logStats.total : logStats[f]}</i>
                        </button>
                      ))}
                    </div>
                    <div className="ap-search">
                      {Ico.search}
                      <input
                        value={logQuery}
                        onChange={(e) => setLogQuery(e.target.value)}
                        placeholder="Search email, code, task ID or IP…"
                        aria-label="Search activations"
                      />
                      {logQuery && (
                        <button
                          className="ap-search-clear"
                          onClick={() => setLogQuery("")}
                          aria-label="Clear search"
                        >
                          {Ico.x(11)}
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="ap-table-wrap">
                    <table className="ap-table">
                      <thead>
                        <tr>
                          <th>When</th>
                          <th>Code</th>
                          <th>Account</th>
                          <th>Status</th>
                          <th>IP</th>
                          <th>Details</th>
                          <th className="ap-col-act" />
                        </tr>
                      </thead>
                      <tbody>
                        {logs.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="ap-empty">
                              {Ico.empty}
                              <p>
                                {logStats.total === 0
                                  ? "No codes have been redeemed yet."
                                  : "No activations match this filter."}
                              </p>
                              {logStats.total > 0 && (
                                <button
                                  className="ap-btn ap-btn-outline ap-btn-sm"
                                  onClick={() => {
                                    setLogFilter("all");
                                    setLogQuery("");
                                  }}
                                >
                                  Reset filters
                                </button>
                              )}
                            </td>
                          </tr>
                        ) : (
                          logs.map((r) => (
                            <tr key={r.taskId}>
                              <td className="ap-muted ap-nowrap">{formatDate(r.createdAt)}</td>
                              <td>
                                <code className="ap-code">{r.code}</code>
                                {r.plan && <span className="ap-plan">{r.plan}</span>}
                              </td>
                              <td className="ap-muted">{r.email}</td>
                              <td>
                                <RunBadge status={r.status} />
                                {r.status === "processing" && (
                                  <span className="ap-progress-mini">{r.progress}%</span>
                                )}
                              </td>
                              <td className="ap-muted ap-nowrap">
                                {r.ip || <span className="ap-dim">—</span>}
                              </td>
                              <td className="ap-muted ap-clamp">
                                {r.message || <span className="ap-dim">—</span>}
                              </td>
                              <td className="ap-col-act">
                                <button
                                  className="ap-btn ap-btn-ghost ap-btn-icon"
                                  onClick={() => setLogDetail(r)}
                                  aria-label={`View activation ${r.taskId}`}
                                  title="View details"
                                >
                                  {Ico.eye()}
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {logTotal > LOG_PAGE_SIZE && (
                    <div className="ap-pager">
                      <span>
                        Page <b>{logPage}</b> of {logPages} · {logTotal} total
                      </span>
                      <div className="ap-btn-row">
                        <button
                          className="ap-btn ap-btn-outline ap-btn-sm"
                          disabled={logOffset === 0 || logLoading}
                          onClick={() => setLogOffset((o) => Math.max(0, o - LOG_PAGE_SIZE))}
                        >
                          {Ico.prev}
                          Previous
                        </button>
                        <button
                          className="ap-btn ap-btn-outline ap-btn-sm"
                          disabled={logOffset + LOG_PAGE_SIZE >= logTotal || logLoading}
                          onClick={() => setLogOffset((o) => o + LOG_PAGE_SIZE)}
                        >
                          Next
                          {Ico.next}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </main>
        </div>
      </div>

      {/* ---------- activation detail ---------- */}
      {logDetail && (
        <div
          className="ap-modal-scrim"
          onMouseDown={(e) => e.target === e.currentTarget && setLogDetail(null)}
        >
          <div className="ap-modal ap-modal-wide" role="dialog" aria-modal="true" aria-label="Activation details">
            <div className="ap-modal-head">
              <span className="ap-modal-ico ap-modal-ico-info">{Ico.activity}</span>
              <div>
                <h3>Activation details</h3>
                <p>
                  <code className="ap-code">{logDetail.code}</code> redeemed{" "}
                  {formatDate(logDetail.createdAt)}
                </p>
              </div>
              <button
                className="ap-btn ap-btn-ghost ap-btn-icon ap-modal-x"
                onClick={() => setLogDetail(null)}
                aria-label="Close"
              >
                {Ico.x(14)}
              </button>
            </div>
            <div className="ap-modal-body">
              <dl className="ap-detail">
                <DetailRow label="Status">
                  <RunBadge status={logDetail.status} />
                  <span className="ap-progress-mini">{logDetail.progress}%</span>
                </DetailRow>
                <DetailRow label="Account email">{logDetail.email}</DetailRow>
                <DetailRow label="Plan">{logDetail.plan || "—"}</DetailRow>
                <DetailRow label="Key status">
                  {logDetail.keyStatus ? (
                    <StatusBadge status={logDetail.keyStatus} />
                  ) : (
                    <span className="ap-dim">key deleted</span>
                  )}
                </DetailRow>
                <DetailRow label="Details">{logDetail.message || "—"}</DetailRow>
                <DetailRow label="Task ID">
                  <code className="ap-code">{logDetail.taskId}</code>
                </DetailRow>
                <DetailRow label="Pixel job">
                  {logDetail.pixelJobId == null ? "—" : `#${logDetail.pixelJobId}`}
                </DetailRow>
                <DetailRow label="IP address">{logDetail.ip || "—"}</DetailRow>
                <DetailRow label="Device">
                  <span className="ap-break">{logDetail.userAgent || "—"}</span>
                </DetailRow>
                <DetailRow label="Last update">{formatDate(logDetail.updatedAt)}</DetailRow>
              </dl>
              <div className="ap-alert ap-alert-warn">
                <span>
                  Account passwords and 2FA secrets are never stored — they are forwarded to the
                  activation service and discarded.
                </span>
              </div>
            </div>
            <div className="ap-modal-foot">
              <button className="ap-btn ap-btn-ghost" onClick={() => setLogDetail(null)}>
                Close
              </button>
              <button
                className="ap-btn ap-btn-outline"
                onClick={() => {
                  setSection("keys");
                  setQuery(logDetail.code);
                  setFilter("all");
                  setLogDetail(null);
                }}
              >
                {Ico.keys}
                Show this key
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- confirm modal ---------- */}
      {confirm && (
        <div className="ap-modal-scrim" onMouseDown={(e) => e.target === e.currentTarget && closeConfirm()}>
          <div className="ap-modal" role="dialog" aria-modal="true" aria-label={confirm.title}>
            <div className="ap-modal-head">
              <span className="ap-modal-ico">{Ico.warn()}</span>
              <div>
                <h3>{confirm.title}</h3>
                <p>{confirm.body}</p>
              </div>
            </div>
            <div className="ap-modal-body">
              {confirm.ids.length > 1 && <UsedWarning ids={confirm.ids} keys={keys} />}
              {confirm.requireType && (
                <div className="ap-field">
                  <label className="ap-label" htmlFor="ap-confirm">
                    Type <b>{CONFIRM_WORD}</b> to confirm
                  </label>
                  <input
                    id="ap-confirm"
                    ref={confirmInput}
                    className="ap-input ap-input-mono"
                    value={confirmText}
                    onChange={(e) => setConfirmText(e.target.value)}
                    placeholder={CONFIRM_WORD}
                    autoComplete="off"
                    spellCheck={false}
                  />
                </div>
              )}
            </div>
            <div className="ap-modal-foot">
              <button className="ap-btn ap-btn-ghost" onClick={closeConfirm} disabled={confirmBusy}>
                Cancel
              </button>
              <button
                className="ap-btn ap-btn-solid-danger"
                onClick={runDelete}
                disabled={confirmBusy || (confirm.requireType && confirmText.trim() !== CONFIRM_WORD)}
              >
                {confirmBusy ? <span className="ap-btn-spin" /> : Ico.trash()}
                {confirmBusy ? "Deleting…" : `Delete ${plural(confirm.ids.length, "key")}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- toast ---------- */}
      {notice && (
        <div className={`ap-toast ${notice.type === "ok" ? "ap-toast-ok" : "ap-toast-err"}`} role="status">
          {notice.type === "ok" ? Ico.check(17) : Ico.warn(17)}
          <span>{notice.text}</span>
        </div>
      )}
    </div>
  );
}

/* ---------------- small pieces ---------------- */

function StatusBadge({ status }: { status: KeyStatus }) {
  const cls =
    status === "available" ? "ap-badge-ok" : status === "used" ? "ap-badge-used" : "ap-badge-off";
  return <span className={`ap-badge ${cls}`}>{status}</span>;
}

function RunBadge({ status }: { status: string }) {
  const cls =
    status === "completed"
      ? "ap-badge-ok"
      : status === "processing"
      ? "ap-badge-run"
      : "ap-badge-fail";
  return <span className={`ap-badge ${cls}`}>{status}</span>;
}

function DetailRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="ap-detail-row">
      <dt>{label}</dt>
      <dd>{children}</dd>
    </div>
  );
}

/** Quotes a CSV field, and defuses values a spreadsheet would run as a formula. */
function csvCell(value: string): string {
  const safe = /^[=+\-@\t\r]/.test(value) ? `'${value}` : value;
  return `"${safe.replace(/"/g, '""')}"`;
}

function PickBox({
  checked,
  indeterminate = false,
  onChange,
  label,
  disabled = false,
}: {
  checked: boolean;
  indeterminate?: boolean;
  onChange: () => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <label className="ap-check">
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={onChange}
        aria-label={label}
        ref={(el) => {
          if (el) el.indeterminate = indeterminate;
        }}
      />
      <span />
    </label>
  );
}

function UsedWarning({ ids, keys }: { ids: number[]; keys: CdkKey[] }) {
  const used = keys.filter((k) => ids.includes(k.id) && k.status === "used");
  if (!used.length) return null;
  return (
    <div className="ap-alert ap-alert-warn">
      <span>
        <b>{plural(used.length, "key")}</b> in this batch {used.length === 1 ? "has" : "have"} already
        been redeemed. The activation stays in the activity log, but the key row itself is gone for
        good.
      </span>
    </div>
  );
}

function describeScope(filter: "all" | KeyStatus, query: string): string {
  const bits: string[] = [];
  if (filter !== "all") bits.push(`status: ${filter}`);
  if (query.trim()) bits.push(`search: "${query.trim()}"`);
  return bits.length ? bits.join(", ") : "every key";
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
