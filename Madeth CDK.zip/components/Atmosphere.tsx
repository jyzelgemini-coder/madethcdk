"use client";

import { useEffect } from "react";

/**
 * Product chrome for the public pages: a following lamp, a slow scanline,
 * film grain, and a faint grid. All decorative — pointer-events none.
 */
export default function Atmosphere() {
  useEffect(() => {
    const root = document.documentElement;
    let raf = 0;
    let x = 0;
    let y = 0;

    const onMove = (e: PointerEvent) => {
      x = e.clientX;
      y = e.clientY;
      if (raf) return;
      raf = requestAnimationFrame(() => {
        root.style.setProperty("--mx", `${x}px`);
        root.style.setProperty("--my", `${y}px`);
        raf = 0;
      });
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      window.removeEventListener("pointermove", onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className="fx" aria-hidden>
      <div className="fx-grid" />
      <div className="fx-lamp" />
      <div className="fx-scan" />
      <div className="fx-grain" />
    </div>
  );
}
