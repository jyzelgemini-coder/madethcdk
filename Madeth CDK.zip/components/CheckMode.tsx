"use client";

import { useState } from "react";

import { useToast } from "@/components/Toast";
import { getTaskStatus } from "@/lib/api";
import type { Dict } from "@/lib/i18n";

interface Found {
  taskId?: string;
  email?: string;
  status?: string;
  message?: string;
  createdAt?: string;
}

function badgeFor(status?: string) {
  const st = (status || "").toLowerCase();
  if (st === "completed" || st === "done") return "done";
  if (st === "failed" || st === "error" || st === "cancelled") return "fail";
  return "run";
}

function labelFor(t: Dict, status?: string) {
  const st = (status || "").toLowerCase();
  if (st === "completed" || st === "done") return t.statusCompleted;
  if (st === "failed" || st === "error") return t.statusFailed;
  if (st === "cancelled") return t.statusCancelled;
  return t.statusRunning;
}

export default function CheckMode({ t }: { t: Dict }) {
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [found, setFound] = useState<Found | null>(null);
  const [notFound, setNotFound] = useState(false);

  const handleCheck = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const query = q.trim();
    if (!query) {
      toast(t.errEmptyCode, "er");
      return;
    }
    setBusy(true);
    setNotFound(false);
    setFound(null);
    try {
      const d = await getTaskStatus(query);
      if (!d || !d.success) {
        setNotFound(true);
        return;
      }
      const st = (d.status || "processing").toLowerCase();
      setFound({
        taskId: d.taskId || query,
        email: d.email,
        status: st,
        message: d.message || "—",
        createdAt: d.createdAt,
      });
    } catch {
      setNotFound(true);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="console is-plain">
      <div className="console-body">
        <div className="pane">
          <p className="scount">QUERY</p>
          <div className="sh">
            <h1>{t.txtCheckTitle}</h1>
            <p className="sub">{t.txtCheckSub}</p>
          </div>
          <div className="rule" />
          <form onSubmit={handleCheck}>
            <div className="f">
              <label htmlFor="check-id">{t.lblCheckInput}</label>
              <input
                id="check-id"
                className="mono"
                value={q}
                onChange={(e) => setQ(e.target.value.trim())}
                placeholder="T-…"
                spellCheck={false}
                autoComplete="off"
                autoCapitalize="characters"
              />
              <p className="hint">{t.txtCheckHint}</p>
            </div>
            <button className="bg" type="submit" disabled={busy}>
              {busy && <span className="sp" />}
              {busy ? "…" : t.btnCheckStatus}
            </button>
          </form>

          {notFound && (
            <div className="rcard err" role="status">
              <p className="err-title">{t.notFound}</p>
              <p className="err-msg">{t.notFoundHint}</p>
            </div>
          )}

          {found && (
            <div className="rcard" role="status">
              <div className="rrow">
                <span className="rl">{t.lblTaskId}</span>
                <span className="rv mono">{found.taskId}</span>
              </div>
              <div className="rrow">
                <span className="rl">{t.lblStatus}</span>
                <span className="rv">
                  <span className={`sbadge ${badgeFor(found.status)}`}>{labelFor(t, found.status)}</span>
                </span>
              </div>
              <div className="rrow">
                <span className="rl">{t.lblAccountEmail}</span>
                <span className="rv">{found.email || "—"}</span>
              </div>
              <div className="rrow">
                <span className="rl">{t.lblReason}</span>
                <span className="rv">{found.message || "—"}</span>
              </div>
              <div className="rrow">
                <span className="rl">{t.lblTime}</span>
                <span className="rv">
                  {found.createdAt ? new Date(found.createdAt).toLocaleString() : "—"}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
