"use client";

import type { ReactNode } from "react";

import { splitEmoji, toColorEmoji } from "@/lib/emoji";

function pop(el: HTMLElement) {
  el.classList.remove("emo-pop");
  // Forces a reflow so the animation restarts on rapid repeat clicks.
  void el.offsetWidth;
  el.classList.add("emo-pop");
}

interface EmojiProps {
  children: string;
  /** Accessible name. Without one the emoji is hidden from screen readers. */
  label?: string;
  className?: string;
}

/** A single emoji: colour-forced, springy on hover, pops when clicked. */
export function Emoji({ children, label, className }: EmojiProps) {
  return (
    <span
      className={`emo${className ? ` ${className}` : ""}`}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      onClick={(e) => pop(e.currentTarget)}
      onAnimationEnd={(e) => e.currentTarget.classList.remove("emo-pop")}
    >
      {toColorEmoji(children)}
    </span>
  );
}

/**
 * Wraps every emoji inside a plain string with <Emoji>, leaving the rest of
 * the text untouched. Lets translated strings keep their emoji inline.
 */
export function EmojiText({ children }: { children: string | undefined }): ReactNode {
  if (!children) return null;

  const parts = splitEmoji(children);
  if (parts.length === 1) return children;

  // split() with a single capture group puts matches at every odd index.
  return parts.map((part, i) => (i % 2 === 1 ? <Emoji key={i}>{part}</Emoji> : part));
}
