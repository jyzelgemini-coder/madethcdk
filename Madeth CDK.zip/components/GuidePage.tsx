import Link from "next/link";

import { EmojiText } from "@/components/Emoji";
import type { Dict } from "@/lib/i18n";

export default function GuidePage({ t }: { t: Dict }) {
  const cards: { title: string; desc: string }[] = [
    { title: t.txtG1Title, desc: t.txtG1Desc },
    { title: t.txtG2Title, desc: t.txtG2Desc },
    { title: t.txtG3Title, desc: t.txtG3Desc },
    { title: t.txtG4Title, desc: t.txtG4Desc },
  ];

  return (
    <div className="gwrap">
      <div className="ghero">
        <p className="gkicker">{t.navGuide}</p>
        <h1>{t.guideHeroTitle}</h1>
        <p>{t.guideHeroSub}</p>
      </div>

      <ol className="gtimeline">
        {cards.map((c, i) => (
          <li className="gcard" key={i}>
            <span className="gnum">{String(i + 1).padStart(2, "0")}</span>
            <div>
              <h2>
                <EmojiText>{c.title}</EmojiText>
              </h2>
              <p>
                <EmojiText>{c.desc}</EmojiText>
              </p>
            </div>
          </li>
        ))}

        <li className="gcard gcard-video">
          <span className="gnum">05</span>
          <div>
            <h2>{t.guideVideoTitle}</h2>
            <p>{t.guideVideoSub}</p>
            <div className="vwrap">
              <iframe
                src="https://www.youtube-nocookie.com/embed/Gqiy9zphZMc"
                title={t.guideVideoTitle}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
            </div>
          </div>
        </li>
      </ol>

      <Link href="/" className="bg bg-inline gcta">
        {t.navActivate}
      </Link>
    </div>
  );
}
