"use client";

import { useEffect, useState } from "react";

export default function HudClock() {
  const [clock, setClock] = useState("--:--:--Z");

  useEffect(() => {
    const tick = () => {
      setClock(`${new Date().toISOString().slice(11, 19)}Z`);
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <time className="hud-clock" dateTime={clock} suppressHydrationWarning>
      {clock}
    </time>
  );
}
