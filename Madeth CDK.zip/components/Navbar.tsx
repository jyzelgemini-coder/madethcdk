"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import HudClock from "@/components/HudClock";
import { languageOptions, type Dict, type Lang } from "@/lib/i18n";

interface Props {
  t: Dict;
  lang: Lang;
  setLang: (l: Lang) => void;
}

export default function Navbar({ t, lang, setLang }: Props) {
  const pathname = usePathname();
  const onActivate = !pathname?.includes("guide");

  return (
    <header className="nav">
      <Link href="/" className="logo" aria-label="CDK Gateway home">
        <svg className="logo-mark" viewBox="0 0 32 32" fill="none" aria-hidden>
          <path
            d="M16 2.5 28 9.4v13.2L16 29.5 4 22.6V9.4L16 2.5Z"
            stroke="currentColor"
            strokeWidth="1.4"
          />
          <path
            d="M16 11.2a3.2 3.2 0 0 0-1.5 6V20h3v-2.8a3.2 3.2 0 0 0-1.5-6Z"
            fill="currentColor"
          />
        </svg>
        <span className="logo-text">CDK Gateway</span>
      </Link>

      <span className="hud-live">
        <i />
        {t.hudLive}
      </span>

      <HudClock />

      <div className="nright">
        <nav className="ntabs" aria-label="Primary">
          <Link href="/" className={`ntab ${onActivate ? "on" : ""}`}>
            {t.navActivate}
          </Link>
          <Link href="/guide" className={`ntab ${!onActivate ? "on" : ""}`}>
            {t.navGuide}
          </Link>
        </nav>
        <label>
          <span className="sr-only">Language</span>
          <select
            className="lsel"
            value={lang}
            onChange={(e) => setLang(e.target.value as Lang)}
            aria-label="Language"
          >
            {languageOptions.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </label>
      </div>
    </header>
  );
}
