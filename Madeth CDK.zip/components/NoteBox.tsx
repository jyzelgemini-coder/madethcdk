import { useState } from "react";

import { EmojiText } from "@/components/Emoji";
import { emojiHtml } from "@/lib/emoji";
import { type Dict } from "@/lib/i18n";

export default function NoteBox({ t, compact = false }: { t: Dict; compact?: boolean }) {
  const [open, setOpen] = useState(!compact);
  const items = [t.noteItem1, t.noteItem2, t.noteItem3, t.noteItem4];

  return (
    <div className={`note-box ${open ? "is-open" : ""}`}>
      <button
        type="button"
        className="note-toggle"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <span>
          <EmojiText>{t.noteTitle}</EmojiText>
        </span>
        <span className="note-chevron" aria-hidden>
          {open ? "−" : "+"}
        </span>
      </button>
      {open && (
        <div className="note-body">
          <ul className="note-list">
            {items.map((item, i) => (
              <li key={i} dangerouslySetInnerHTML={{ __html: emojiHtml(item) }} />
            ))}
          </ul>
          <p className="note-foot">
            <EmojiText>{t.noteFoot}</EmojiText>
          </p>
        </div>
      )}
    </div>
  );
}
