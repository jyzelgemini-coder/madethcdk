"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

import NoteBox from "@/components/NoteBox";
import { useToast } from "@/components/Toast";
import { activateCode, checkCode, getTaskStatus, type CheckResult } from "@/lib/api";
import type { Dict, Lang } from "@/lib/i18n";

type Step = 1 | 2 | 3;
type RunState = "running" | "completed" | "failed" | "cancelled" | "unused";

function statusLabel(t: Dict, state: RunState): string {
  if (state === "completed") return t.statusCompleted;
  if (state === "failed") return t.statusFailed;
  if (state === "cancelled") return t.statusCancelled;
  return t.statusRunning;
}

/** Codes are always MD-CDK- plus a tail. Pasting a full code still works. */
function parseTail(raw: string): string {
  const u = raw.toUpperCase().replace(/\s+/g, "");
  const stripped = u.startsWith("MD-CDK-") ? u.slice(7) : u.replace(/^MD-CDK/, "");
  return stripped.replace(/[^A-Z0-9]/g, "").slice(0, 20);
}

function fullCode(tail: string): string {
  return `MD-CDK-${tail}`;
}

export default function SingleMode({ t, lang }: { t: Dict; lang: Lang }) {
  const { toast } = useToast();
  const [step, setStep] = useState<Step>(1);
  const [tail, setTail] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [secret, setSecret] = useState("");
  const [backup, setBackup] = useState("");
  const [checking, setChecking] = useState(false);
  const [activating, setActivating] = useState(false);
  const [cdk, setCdk] = useState<CheckResult | null>(null);
  const [copied, setCopied] = useState(false);

  const [taskId, setTaskId] = useState("");
  const [taskEmail, setTaskEmail] = useState("");
  const [runState, setRunState] = useState<RunState>("running");
  const [pct, setPct] = useState(2);
  const [msg, setMsg] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const goStep = (n: Step) => setStep(n);

  const handleCheck = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const c = fullCode(tail);
    if (tail.length < 7) {
      toast(t.errEmptyCode, "er");
      return;
    }
    setChecking(true);
    try {
      const d = await checkCode(c);
      if (!d) {
        toast("Connection error", "er");
        return;
      }
      if (!d.success) {
        toast(d.error || t.errEmptyCode, "er");
        return;
      }
      setCdk(d);
      goStep(2);
    } catch {
      toast("Connection error", "er");
    } finally {
      setChecking(false);
    }
  };

  const handleActivate = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!cdk) return;
    if (!email.trim() || !password || !secret.trim()) {
      toast(t.errEmptyAccount, "er");
      return;
    }
    const twofa = backup.trim() ? `${secret.trim()} ${backup.trim()}` : secret.trim();
    setActivating(true);
    try {
      const d = await activateCode({
        code: cdk.code || fullCode(tail),
        email: email.trim(),
        password,
        twofa,
        lang,
      });
      if (!d) {
        toast("Connection error", "er");
        return;
      }
      if (!d.success) {
        toast(d.error || "Activation failed", "er");
        return;
      }
      if (!d.taskId) {
        toast("No task id returned", "er");
        return;
      }
      startProgress(d.taskId, email.trim());
      goStep(3);
    } catch {
      toast("Connection error", "er");
    } finally {
      setActivating(false);
    }
  };

  const pollOnce = async (
    tid: string,
    setState: (s: RunState) => void,
    setP: (n: number | ((p: number) => number)) => void,
    setM: (m: string | null) => void,
    clear: () => void
  ) => {
    try {
      const d = await getTaskStatus(tid, lang);
      if (!d || !d.success) return;
      const st = (d.status || "processing").toLowerCase();
      if (d.message) setM(d.message);
      if (st === "completed" || st === "done") {
        setState("completed");
        setP(100);
        clear();
      } else if (st === "failed" || st === "error") {
        setState("failed");
        setP(100);
        clear();
      } else if (st === "cancelled") {
        setState("cancelled");
        setP(100);
        clear();
      } else if (d.progress != null) {
        setP(d.progress);
      }
    } catch {
      /* transient errors are ignored */
    }
  };

  const startProgress = (tid: string, em: string) => {
    setTaskId(tid);
    setTaskEmail(em);
    setMsg(null);
    setPct(2);
    setRunState("running");
    if (timerRef.current) clearInterval(timerRef.current);

    const clear = () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    timerRef.current = setInterval(() => {
      void pollOnce(tid, setRunState, setPct, setMsg, clear);
    }, 5000);
    void pollOnce(tid, setRunState, setPct, setMsg, clear);
  };

  const reset = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setCdk(null);
    setTail("");
    setEmail("");
    setPassword("");
    setSecret("");
    setBackup("");
    setMsg(null);
    setTaskId("");
    setShowPass(false);
    goStep(1);
  };

  const copyId = async () => {
    if (!taskId) return;
    try {
      await navigator.clipboard.writeText(taskId);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast("Copy failed", "er");
    }
  };

  const led = (i: Step) => (i < step ? "dn" : i === step ? "on" : "");
  const badgeClass =
    runState === "completed"
      ? "done"
      : runState === "failed" || runState === "cancelled"
        ? "fail"
        : "run";

  return (
    <div className="console">
      <ol className="leds" aria-label="Activation steps">
        {([1, 2, 3] as const).map((i) => (
          <li key={i} className={led(i)}>
            <b>{String(i).padStart(2, "0")}</b>
            <span>{i === 1 ? t.step1Label : i === 2 ? t.step2Label : t.step3Label}</span>
          </li>
        ))}
      </ol>

      <div className="console-body">
        {step === 1 && (
          <div className="pane" key="s1">
            <p className="scount">01 / 03 · {t.step1Label}</p>
            <div className="sh">
              <h1>{t.s1Title}</h1>
              <p className="sub">{t.s1Sub}</p>
            </div>
            <div className="rule" />
            <form onSubmit={handleCheck}>
              <div className="f">
                <label htmlFor="cdk-code">{t.lblCdk}</label>
                <div className="code-field">
                  <span className="code-prefix">MD-CDK-</span>
                  <input
                    id="cdk-code"
                    value={tail}
                    onChange={(e) => setTail(parseTail(e.target.value))}
                    placeholder="XXXXXXX"
                    autoComplete="off"
                    spellCheck={false}
                    autoFocus
                    autoCapitalize="characters"
                    aria-label={t.lblCdk}
                  />
                </div>
              </div>
              <button className="bg" type="submit" disabled={checking}>
                {checking && <span className="sp" />}
                {checking ? "…" : t.btnCheckCode}
              </button>
            </form>
            <NoteBox t={t} />
            <Link href="/guide" className="help-link">
              {t.needHelp} →
            </Link>
          </div>
        )}

        {step === 2 && cdk && (
          <div className="pane" key="s2">
            <p className="scount">02 / 03 · {t.step2Label}</p>
            <div className="cbadge">
              <span className="bcode">{cdk.code}</span>
              <span className="btype">
                {t.verified}
                {cdk.plan ? ` · ${cdk.plan}` : ""}
              </span>
            </div>
            <div className="sh">
              <h1>{t.s2Title}</h1>
              <p className="sub">{t.s2Sub}</p>
            </div>
            <div className="rule" />
            <form onSubmit={handleActivate}>
              <div className="f">
                <label htmlFor="acc-email">{t.lblEmail}</label>
                <input
                  id="acc-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@gmail.com"
                  autoComplete="username"
                  inputMode="email"
                />
              </div>
              <div className="f">
                <label htmlFor="acc-pass">{t.lblPassword}</label>
                <div className="input-wrap">
                  <input
                    id="acc-pass"
                    type={showPass ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    className="input-action"
                    onClick={() => setShowPass((v) => !v)}
                    aria-label={showPass ? t.hidePassword : t.showPassword}
                    title={showPass ? t.hidePassword : t.showPassword}
                  >
                    {showPass ? (
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
                        <path d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 5.1A10 10 0 0121 12a10.8 10.8 0 01-4.1 4.6M6.1 6.1A10.8 10.8 0 003 12a10 10 0 0011.1 6.9" />
                      </svg>
                    ) : (
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
                        <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
              <div className="f">
                <label htmlFor="acc-2fa">{t.lblSecret}</label>
                <input
                  id="acc-2fa"
                  className="mono"
                  value={secret}
                  onChange={(e) => setSecret(e.target.value)}
                  placeholder="JBSWY3DPEHPK3PXP…"
                  autoComplete="one-time-code"
                  spellCheck={false}
                />
                <p className="hint">{t.txtSecretHint}</p>
              </div>
              <div className="f">
                <label htmlFor="acc-backup">
                  {t.lblBackup}
                  <span className="opt">{t.optional}</span>
                </label>
                <input
                  id="acc-backup"
                  className="mono"
                  value={backup}
                  onChange={(e) => setBackup(e.target.value)}
                  placeholder="59636051 87654321"
                  autoComplete="off"
                  spellCheck={false}
                />
                <p className="hint">{t.txtBackupHint}</p>
              </div>
              <div className="brow">
                <button className="bk" type="button" onClick={() => goStep(1)}>
                  {t.btnBack}
                </button>
                <button className="bg" type="submit" disabled={activating}>
                  {activating && <span className="sp" />}
                  {activating ? "…" : t.btnActivate}
                </button>
              </div>
            </form>
            <NoteBox t={t} compact />
          </div>
        )}

        {step === 3 && (
          <div className={`pane is-${runState}`} key="s3">
            <p className="scount">03 / 03 · {t.step3Label}</p>
            <div className="sh">
              <h1>{runState === "running" ? t.progressTitle : statusLabel(t, runState)}</h1>
            </div>
            <div className="prow">
              <span className={`sbadge ${badgeClass}`}>{statusLabel(t, runState)}</span>
            </div>
            <p className="pct">
              {pct}
              <em>%</em>
            </p>
            <div className="pbar" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
              <i style={{ width: `${pct}%` }} />
            </div>
            {runState === "running" && <p className="phint">{t.processingHint}</p>}

            <div className="job-log" aria-live="polite">
              {msg || (runState === "running" ? t.statusRunning : statusLabel(t, runState))}
              {runState === "running" && <span className="caret" />}
            </div>

            <ul className="meta">
              <li>
                <span>{t.lblTaskId}</span>
                <b className="mono mo">
                  {taskId || "—"}
                  {taskId && (
                    <button type="button" className="copy-btn" onClick={copyId}>
                      {copied ? t.copied : t.copy}
                    </button>
                  )}
                </b>
              </li>
              <li>
                <span>{t.lblAccountEmail}</span>
                <b>{taskEmail || "—"}</b>
              </li>
            </ul>

            <button className="bk bk-block" type="button" onClick={reset}>
              {t.btnReset}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
