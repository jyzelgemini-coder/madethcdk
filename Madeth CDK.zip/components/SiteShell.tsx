"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

import ActivatePage from "@/components/ActivatePage";
import Atmosphere from "@/components/Atmosphere";
import GuidePage from "@/components/GuidePage";
import Navbar from "@/components/Navbar";
import { defaultLang, i18n, type Lang } from "@/lib/i18n";

const STORAGE_KEY = "cdk_gateway_lang";

export default function SiteShell({ page }: { page: "activate" | "guide" }) {
  const [lang, setLang] = useState<Lang>(defaultLang);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY) as Lang | null;
    if (stored && i18n[stored]) setLang(stored);
    setReady(true);
  }, []);

  const changeLang = (l: Lang) => {
    setLang(l);
    try {
      window.localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* ignore storage errors */
    }
  };

  useEffect(() => {
    if (ready) {
      try {
        window.localStorage.setItem(STORAGE_KEY, lang);
      } catch {
        /* ignore */
      }
    }
  }, [lang, ready]);

  const t = i18n[lang];

  return (
    <div className="page">
      <Atmosphere />
      <Navbar t={t} lang={lang} setLang={changeLang} />
      <main className="main">
        {page === "activate" ? <ActivatePage t={t} lang={lang} /> : <GuidePage t={t} />}
      </main>
      <footer className="site-foot">
        <span className="tel">
          KEY · <b>{t.trustOnce}</b>
        </span>
        <span className="tel">
          STORE · <b>{t.trustSecure}</b>
        </span>
        <span className="tel">
          ETA · <b>{t.trustTime}</b>
        </span>
        <span className="spacer" />
        <Link href="/guide">{t.navGuide}</Link>
        <Link href="/admin">{t.footerAdmin}</Link>
      </footer>
    </div>
  );
}
