# Pixel Partner API v2 Integration — Design

Date: 2026-08-07
Status: Approved, ready for implementation planning

## Goal

Replace the simulated activation task in this project with real calls to the
Pixel Partner API v2 (`https://api.smm.io.vn`). After a user redeems a
single-use CDK code and submits their Google account details, the app enqueues a
real Pixel job and shows that job's live status until it reaches a terminal
state.

## Current state

- `components/SingleMode.tsx` — 3-step wizard: check code, enter account, poll
  progress every 5s.
- `app/api/v1/cdk/check/route.ts` — validates a code against the `keys` table.
- `app/api/v1/cdk/activate/route.ts` — consumes the key, then runs
  `simulateTask()`, a fake in-memory progress timer. This is what gets replaced.
- `app/api/v1/task/status/route.ts` — reads the `tasks` row and returns it.
- `lib/db.ts` — `consumeKey()` already claims a key atomically inside a
  transaction, guaranteeing single use.

## Decisions

1. **The CDK code is only consumed after Pixel accepts the submission.** If the
   Pixel submit fails for any reason, the code stays `available` and the user
   can correct their input and retry. This accepts a narrow race window where
   two concurrent requests using the same code could both submit to Pixel; the
   second one loses the `consumeKey` race and is reported as already used.
2. **One 2FA input field, auto-detected.** A 32-character Base32 string is sent
   as `totp`; additional groups of exactly 8 digits (2 or 3 of them) are sent as
   the optional `backup` array.
3. **A TOTP secret is mandatory.** Pixel requires `totp` on every submit, so a
   user who supplies only backup codes is rejected client-side with an
   explanatory message rather than being sent upstream to fail.

## Configuration

| Variable | Scope | Purpose |
| --- | --- | --- |
| `PIXEL_API_KEY` | server only | The `pxl_...` partner key sent as `X-API-Key` |
| `PIXEL_API_BASE` | server only | Defaults to `https://api.smm.io.vn` |

The key is never exposed to the browser — it must not be prefixed with
`NEXT_PUBLIC_`. All Pixel traffic originates from route handlers. Both variables
are documented in `.env.example`; the real key goes in `.env.local`, which is
gitignored.

## New module: `lib/pixel.ts`

The single place that knows the Pixel wire format.

- `normalizeSecret(raw)` — strips whitespace, zero-width characters and dashes,
  uppercases, then splits the input. Returns
  `{ totp: string, backup?: string[] }` or a validation error. A valid `totp` is
  exactly 32 characters from `[A-Z2-7]`. A valid backup entry is exactly 8
  digits; between 2 and 3 of them may be supplied. Backup codes without a TOTP
  are an error.
- `submitJob({ gmail, password, totp, backup })` — `POST /api/v2/pixel/submit`,
  single-account form. Returns the `job_id` on success, or a mapped error.
- `getJobStatus(jobId)` — `POST /api/v2/pixel/status` with `{ job_id }`. Returns
  the first entry of `results`.
- `mapError(code, lang)` — turns Pixel error keys into human-readable messages
  in the user's language. Covers the API-level codes (`not_enough_coins`,
  `already_running`, `invalid_totp`, `rate_limit_exceeded`, `maintenance`, …)
  and the job-level `pixel_err_*` keys. Unknown keys fall back to a generic
  message that includes the raw key so support can diagnose it.
- `mapProgress(currentStep)` — maps the documented automation steps to a
  percentage, replacing the fake incrementing counter:

  | `current_step` | % |
  | --- | --- |
  | Waiting for device | 5 |
  | Starting | 10 |
  | Email | 20 |
  | Spam check | 30 |
  | Password | 40 |
  | 2-step authentication | 50 |
  | Payment method | 60 |
  | Add payment | 70 |
  | Offer check | 80 |
  | Receive offer | 90 |
  | Payment processing | 95 |
  | Completed | 100 |

  An unrecognised step leaves the previously stored progress unchanged.

All network calls use a timeout and treat a non-2xx response or a body with
`ok: false` as a failure carrying the upstream `error` string.

## Schema change

`tasks` gains one nullable column:

```sql
ALTER TABLE tasks ADD COLUMN pixel_job_id INTEGER;
```

Applied on boot in `lib/db.ts` behind a check of `PRAGMA table_info(tasks)`, so
existing databases migrate in place and repeated boots are harmless.

## Activation flow — `POST /api/v1/cdk/activate`

1. Validate presence of `code`, `email`, `password`, `twofa`.
2. Validate the email ends with `@gmail.com`; validate the secret via
   `normalizeSecret`. Both failures return 400 with a clear message and leave
   the key untouched.
3. Load the key. Missing → 404. `disabled` → 403. `used` → 409.
4. Call `submitJob`. On failure return the mapped error with an appropriate
   status; the key remains `available`.
5. On success, generate the task id and call `consumeKey`. If it returns null,
   another request claimed the code first: log the orphaned Pixel `job_id` for
   manual reconciliation and return the 409 "already used" error.
6. `createTask` with the Pixel `job_id` stored, and return `{ success: true,
   taskId }`.
7. `simulateTask` is deleted.

## Status flow — `GET /api/v1/task/status`

1. Load the task. Missing → 404.
2. If the stored status is terminal (`completed`, `failed`, `cancelled`), return
   the row directly without contacting Pixel.
3. Otherwise call `getJobStatus(pixel_job_id)` and translate:
   - Pixel `success` → `completed`, progress 100.
   - Pixel `error` → `failed`, progress 100, message = `mapError(error_msg)`.
   - Pixel `cancelled` → `cancelled`, progress 100.
   - Pixel `pending` → `processing`, progress from `mapProgress`, message showing
     the queue position when it is greater than zero.
   - Pixel `running` → `processing`, progress and message from `current_step`.
4. Persist the translation with `updateTask`, then respond.
5. If Pixel is unreachable or returns an error, respond with the last known
   database state rather than an error, so the polling UI does not flicker.

Transient Pixel failures (`pixel_err_login_timeout`, `pixel_err_adb_connect`,
`pixel_err_pwweb`, `pixel_err_setup_stuck`, `pixel_err_unknown`) are retried
automatically upstream, so the app does not resubmit on its own.

## UI changes — `components/SingleMode.tsx`

The step-3 panel already renders task id, status, progress, email and reason, so
it needs only:

- a `cancelled` run state alongside `completed` and `failed`, sharing the
  failure badge styling;
- the reason line showing the mapped Pixel message;
- `cleanTfa` in `lib/api.ts` delegating to the shared normalisation logic so the
  client and server agree on what a valid secret looks like.

New user-facing strings are added to both languages in `lib/i18n.ts`.

## Error handling summary

| Situation | User sees | Code state |
| --- | --- | --- |
| Bad email or secret format | Field-specific message | untouched |
| Pixel rejects the submit | Mapped Pixel error | untouched |
| Pixel accepts, code race lost | "already used" | consumed by the winner |
| Job fails during processing | Mapped `pixel_err_*` reason | consumed |
| Pixel unreachable while polling | Last known progress | consumed |

## Out of scope

Batch submission, the `/api/v2/history`, `/api/v2/logs` and `/api/v2/info`
endpoints, admin-side coin balance display, and any change to the check or admin
flows.
