import { NextRequest, NextResponse } from "next/server";

import { requireAdmin } from "@/lib/auth";
import { verifyCsrfToken } from "@/lib/csrf";
import { isCrossSite } from "@/lib/net";
import { seedAdmin } from "@/lib/seed";

/**
 * Single gate for every /api/admin route.
 *
 * Returns a response when the request must be rejected, or null to continue.
 * Keeping this in one place means a new admin endpoint cannot accidentally ship
 * without a session check or, for writes, CSRF protection.
 */
export async function guardAdmin(
  req: NextRequest,
  opts: { write?: boolean } = {}
): Promise<NextResponse | null> {
  seedAdmin();

  const session = await requireAdmin();
  if (!session) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  if (opts.write) {
    if (isCrossSite(req)) {
      return NextResponse.json({ success: false, error: "Cross-site request blocked" }, { status: 403 });
    }
    if (!(await verifyCsrfToken(req.headers.get("x-csrf-token")))) {
      return NextResponse.json({ success: false, error: "Invalid CSRF token" }, { status: 403 });
    }
  }

  return null;
}
