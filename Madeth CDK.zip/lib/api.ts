import type { Lang } from "@/lib/i18n";

const API = process.env.NEXT_PUBLIC_API_BASE || "/api/v1";

export interface CheckResult {
  success: boolean;
  code?: string;
  taskCount?: number;
  plan?: string;
  error?: string;
}

export interface ActivateResult {
  success: boolean;
  taskId?: string;
  error?: string;
}

export interface TaskStatus {
  success: boolean;
  status?: string;
  taskId?: string;
  email?: string;
  message?: string;
  progress?: number;
  createdAt?: string;
}

export interface ActivatePayload {
  code: string;
  email: string;
  password: string;
  twofa: string;
  lang: Lang;
}

async function request<T>(path: string, init?: RequestInit): Promise<T | null> {
  try {
    const res = await fetch(API + path, {
      headers: init?.body ? { "Content-Type": "application/json" } : undefined,
      ...init,
    });
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

export function checkCode(code: string): Promise<CheckResult | null> {
  return request<CheckResult>("/cdk/check", {
    method: "POST",
    body: JSON.stringify({ code }),
  });
}

export function activateCode(payload: ActivatePayload): Promise<ActivateResult | null> {
  return request<ActivateResult>("/cdk/activate", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function getTaskStatus(taskId: string, lang?: Lang): Promise<TaskStatus | null> {
  const q = new URLSearchParams({ task_id: taskId });
  if (lang) q.set("lang", lang);
  return request<TaskStatus>(`/task/status?${q.toString()}`);
}

/**
 * Light client-side tidy-up of the 2FA field. Authoritative validation and
 * TOTP/backup-code splitting happen server-side in `lib/pixel.ts`.
 */
export function cleanTfa(raw: string): string {
  return raw
    .replace(/[\u200B\uFEFF]/g, "")
    .replace(/-/g, "")
    .trim()
    .toUpperCase();
}