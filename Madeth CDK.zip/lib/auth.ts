import crypto from "node:crypto";
import { cookies } from "next/headers";

import { countAdmins, createAdmin, getAdminByUsername } from "@/lib/db";

const COOKIE = "cdk_admin_session";
const HASH_ROUNDS = 100_000;
const DEV_SECRET = "dev-insecure-admin-secret-change-me";

/**
 * Values that have been published in .env.example or docs. They are long enough
 * to pass a length check but are effectively public, so treating them as unset
 * is the difference between "looks configured" and "actually secret".
 */
const PLACEHOLDER_SECRETS = new Set([
  "change-me-to-a-long-random-string",
  "dev-insecure-admin-secret-change-me",
  "dev-only-insecure-admin-secret-do-not-use-in-production",
]);

/**
 * HMAC key for session cookies.
 *
 * Session tokens are only as trustworthy as this value: anyone who knows it can
 * mint a cookie for any username. Falling back to a published constant in
 * production would therefore hand out admin access, so we refuse to start
 * instead of silently accepting forged sessions.
 */
function secret(): string {
  const configured = process.env.ADMIN_SECRET;
  const usable = configured && configured.length >= 32 && !PLACEHOLDER_SECRETS.has(configured);
  if (usable) return configured;

  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "ADMIN_SECRET is missing, too short, or still set to the example value. " +
        "Generate a real one with: node -e \"console.log(require('crypto').randomBytes(32).toString('hex'))\""
    );
  }
  return configured || DEV_SECRET;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto
    .pbkdf2Sync(password, salt, HASH_ROUNDS, 64, "sha512")
    .toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const calc = crypto
    .pbkdf2Sync(password, salt, HASH_ROUNDS, 64, "sha512")
    .toString("hex");
  const a = Buffer.from(hash, "hex");
  const b = Buffer.from(calc, "hex");
  // A truncated or malformed stored hash would make timingSafeEqual throw.
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", secret()).update(payload).digest("hex");
}

export function createToken(username: string): string {
  const payload = `${username}:${Date.now() + 1000 * 60 * 60 * 24}`;
  return `${payload}.${sign(payload)}`;
}

export function verifyToken(token: string): string | null {
  const dot = token.lastIndexOf(".");
  if (dot < 0) return null;
  const payload = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (sign(payload) !== sig) return null;
  const [username, exp] = payload.split(":");
  if (!username || !exp || Number(exp) < Date.now()) return null;
  return username;
}

export async function getSessionUser(): Promise<string | null> {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function requireAdmin(): Promise<string | null> {
  return getSessionUser();
}

/** Hash of a value nobody can supply, used to equalise timing on unknown users. */
const DUMMY_HASH = hashPassword(crypto.randomBytes(32).toString("hex"));

export async function createSession(username: string, password: string): Promise<boolean> {
  const admin = getAdminByUsername(username);

  // Always run one PBKDF2 pass. Returning early for an unknown username would
  // make "no such user" measurably faster than "wrong password" and let an
  // attacker enumerate valid admin names.
  if (!admin) {
    verifyPassword(password, DUMMY_HASH);
    return false;
  }
  if (!verifyPassword(password, admin.password_hash)) return false;
  const store = await cookies();
  store.set(COOKIE, createToken(username), {
    httpOnly: true,
    // The panel is a same-origin SPA, so it never needs the cookie on a
    // cross-site navigation. "strict" removes the residual CSRF surface.
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24,
  });
  return true;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE);
}

export function adminExists(): boolean {
  return countAdmins() > 0;
}