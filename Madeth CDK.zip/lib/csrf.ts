import crypto from "node:crypto";
import { cookies } from "next/headers";

const CSRF_COOKIE = "cdk_csrf";
const CSRF_HEADER = "x-csrf-token";

/**
 * Generate a CSRF token for the current session
 */
export async function generateCsrfToken(): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  const store = await cookies();
  
  store.set(CSRF_COOKIE, token, {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 2, // 2 hours
  });
  
  return token;
}

/**
 * Return the current CSRF token, creating one if the session doesn't have it yet
 */
export async function ensureCsrfToken(): Promise<string> {
  const existing = await getCsrfToken();
  if (existing) return existing;
  return generateCsrfToken();
}

/**
 * Verify CSRF token from request header matches cookie
 */
export async function verifyCsrfToken(headerToken: string | null): Promise<boolean> {
  if (!headerToken) return false;
  
  const store = await cookies();
  const cookieToken = store.get(CSRF_COOKIE)?.value;
  
  if (!cookieToken) return false;
  
  const a = Buffer.from(headerToken, "utf8");
  const b = Buffer.from(cookieToken, "utf8");
  
  // timingSafeEqual throws on length mismatch
  if (a.length !== b.length) return false;
  
  return crypto.timingSafeEqual(a, b);
}

/**
 * Get current CSRF token from cookie
 */
export async function getCsrfToken(): Promise<string | null> {
  const store = await cookies();
  return store.get(CSRF_COOKIE)?.value || null;
}

/**
 * Drop the CSRF token, e.g. on logout
 */
export async function clearCsrfToken(): Promise<void> {
  const store = await cookies();
  store.delete(CSRF_COOKIE);
}
