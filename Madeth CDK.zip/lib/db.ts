import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

// CDK_DB_PATH lets the security audit run against a throwaway database instead
// of the live one. Production leaves it unset.
const DB_PATH = process.env.CDK_DB_PATH
  ? path.resolve(process.env.CDK_DB_PATH)
  : path.join(process.cwd(), "data", "cdk.db");

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export type KeyStatus = "available" | "used" | "disabled";

export interface CdkKey {
  id: number;
  code: string;
  task_count: number;
  plan: string;
  status: KeyStatus;
  created_at: string;
  used_at: string | null;
  used_by_email: string | null;
  task_id: string | null;
}

export interface TaskRecord {
  id: string;
  code: string;
  email: string;
  status: string;
  progress: number;
  message: string | null;
  created_at: string;
  updated_at: string;
  /** Job id returned by the Pixel Partner API, null for legacy rows. */
  pixel_job_id: number | null;
  /** Client IP recorded at activation time, null for legacy rows. */
  ip: string | null;
  /** Client user-agent recorded at activation time, null for legacy rows. */
  user_agent: string | null;
}

/** One activation as shown in the admin activity log. */
export interface ActivationRow extends TaskRecord {
  /** Plan on the key, or null if the key row has since been deleted. */
  plan: string | null;
  key_status: KeyStatus | null;
  used_at: string | null;
}

export interface AdminUser {
  id: number;
  username: string;
  password_hash: string;
  created_at: string;
}

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("busy_timeout = 8000");

db.exec(`
  CREATE TABLE IF NOT EXISTS keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    task_count INTEGER NOT NULL DEFAULT 1,
    plan TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'available',
    created_at TEXT NOT NULL,
    used_at TEXT,
    used_by_email TEXT,
    task_id TEXT
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL,
    email TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'processing',
    progress INTEGER NOT NULL DEFAULT 2,
    message TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_keys_status ON keys(status);
  CREATE INDEX IF NOT EXISTS idx_keys_code ON keys(code);
  CREATE INDEX IF NOT EXISTS idx_tasks_code ON tasks(code);
`);

// Migrations for databases created by earlier versions. Each one is guarded by
// a column check, so repeated boots are harmless.
{
  const cols = new Set(
    (db.prepare("PRAGMA table_info(tasks)").all() as { name: string }[]).map((c) => c.name)
  );
  if (!cols.has("pixel_job_id")) db.exec("ALTER TABLE tasks ADD COLUMN pixel_job_id INTEGER");
  if (!cols.has("ip")) db.exec("ALTER TABLE tasks ADD COLUMN ip TEXT");
  if (!cols.has("user_agent")) db.exec("ALTER TABLE tasks ADD COLUMN user_agent TEXT");

  db.exec("CREATE INDEX IF NOT EXISTS idx_tasks_created ON tasks(created_at DESC)");
  db.exec("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)");
  db.exec("CREATE INDEX IF NOT EXISTS idx_tasks_email ON tasks(email)");
}

function getDb(): Database.Database {
  return db;
}

export const now = () => new Date().toISOString();

/**
 * Inserts a key, or returns null if the code already exists. The conflict
 * clause keeps the codes table the single source of truth on uniqueness,
 * rather than relying on a check-then-insert that two callers could race.
 *
 * Databases created before task types were dropped still carry a task_type
 * column declared NOT NULL DEFAULT 'extract', so omitting it here is safe.
 */
export function createKey(input: {
  code: string;
  taskCount: number;
  plan?: string;
}): CdkKey | null {
  const res = getDb()
    .prepare(
      `INSERT INTO keys (code, task_count, plan, status, created_at)
       VALUES (?, ?, ?, 'available', ?)
       ON CONFLICT(code) DO NOTHING`
    )
    .run(input.code, input.taskCount, input.plan ?? "", now());

  if (res.changes === 0) return null;
  return getKeyByCode(input.code)!;
}

export function getKeyByCode(code: string): CdkKey | undefined {
  return getDb().prepare("SELECT * FROM keys WHERE code = ?").get(code) as
    | CdkKey
    | undefined;
}

export function getKeyById(id: number): CdkKey | undefined {
  return getDb().prepare("SELECT * FROM keys WHERE id = ?").get(id) as
    | CdkKey
    | undefined;
}

export function listKeys(limit = 200): CdkKey[] {
  return getDb()
    .prepare("SELECT * FROM keys ORDER BY id DESC LIMIT ?")
    .all(limit) as CdkKey[];
}

export function setKeyStatus(id: number, status: KeyStatus): void {
  getDb()
    .prepare("UPDATE keys SET status = ? WHERE id = ?")
    .run(status, id);
}

/** Permanently removes a key row from the database. */
export function deleteKey(id: number): boolean {
  const res = getDb().prepare("DELETE FROM keys WHERE id = ?").run(id);
  return res.changes > 0;
}

/** Permanently removes many key rows at once. Returns the number deleted. */
export function deleteKeys(ids: number[]): number {
  if (!ids.length) return 0;
  const stmt = getDb().prepare("DELETE FROM keys WHERE id = ?");
  const tx = getDb().transaction((rows: number[]) => {
    let n = 0;
    for (const id of rows) n += stmt.run(id).changes;
    return n;
  });
  return tx(ids) as number;
}

export type ClaimResult =
  | { ok: true; key: CdkKey }
  | { ok: false; reason: "not_found" | "disabled" | "used" };

/**
 * Atomically claims a key for one activation. The status flip is guarded by
 * `AND status = 'available'` so exactly one caller can ever win a given code,
 * which is what makes a key single-use.
 *
 * Callers must claim *before* doing any irreversible outside work, and call
 * releaseKey if that work then fails.
 */
export function claimKey(code: string, email: string, taskId: string): ClaimResult {
  const tx = getDb().transaction((): ClaimResult => {
    const key = getKeyByCode(code);
    if (!key) return { ok: false, reason: "not_found" };
    if (key.status === "disabled") return { ok: false, reason: "disabled" };
    if (key.status === "used") return { ok: false, reason: "used" };

    const res = getDb()
      .prepare(
        `UPDATE keys SET status = 'used', used_at = ?, used_by_email = ?, task_id = ?
         WHERE id = ? AND status = 'available'`
      )
      .run(now(), email, taskId, key.id);

    if (res.changes === 0) return { ok: false, reason: "used" };
    return { ok: true, key: getKeyById(key.id)! };
  });
  return tx();
}

/**
 * Returns a claimed key to the pool. Used when the activation it was claimed
 * for could not be started, so the customer can retry with the same code.
 */
export function releaseKey(id: number): void {
  getDb()
    .prepare(
      `UPDATE keys SET status = 'available', used_at = NULL, used_by_email = NULL, task_id = NULL
       WHERE id = ? AND status = 'used'`
    )
    .run(id);
}

/**
 * Records an activation. `ip` and `userAgent` are kept for the admin activity
 * log; credentials (password, TOTP, backup codes) are deliberately never
 * persisted anywhere.
 */
export function createTask(input: {
  id: string;
  code: string;
  email: string;
  pixelJobId: number;
  ip?: string | null;
  userAgent?: string | null;
}): void {
  const t = now();
  getDb()
    .prepare(
      `INSERT INTO tasks
         (id, code, email, status, progress, created_at, updated_at, pixel_job_id, ip, user_agent)
       VALUES (?, ?, ?, 'processing', 5, ?, ?, ?, ?, ?)`
    )
    .run(
      input.id,
      input.code,
      input.email,
      t,
      t,
      input.pixelJobId,
      input.ip ?? null,
      // Cap the agent string so a hostile client cannot bloat the database.
      input.userAgent ? input.userAgent.slice(0, 400) : null
    );
}

export function getTask(id: string): TaskRecord | undefined {
  return getDb().prepare("SELECT * FROM tasks WHERE id = ?").get(id) as
    | TaskRecord
    | undefined;
}

export function updateTask(
  id: string,
  patch: { status?: string; progress?: number; message?: string | null }
): void {
  const task = getTask(id);
  if (!task) return;
  const status = patch.status ?? task.status;
  const progress = patch.progress ?? task.progress;
  const message = patch.message !== undefined ? patch.message : task.message;
  getDb()
    .prepare(
      `UPDATE tasks SET status = ?, progress = ?, message = ?, updated_at = ? WHERE id = ?`
    )
    .run(status, progress, message, now(), id);
}

/** Statuses the activity log can be filtered by. */
export const ACTIVATION_STATUSES = [
  "processing",
  "completed",
  "failed",
  "cancelled",
] as const;
export type ActivationStatus = (typeof ACTIVATION_STATUSES)[number];

/** Escapes the LIKE wildcards so a search for "%" matches a literal percent. */
function likeTerm(raw: string): string {
  return `%${raw.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
}

/**
 * Reads a page of the activation log, newest first. Joins the key so the admin
 * can see which plan was redeemed even after the key row is deleted (the join
 * simply yields null in that case).
 */
export function listActivations(opts: {
  limit: number;
  offset: number;
  status?: ActivationStatus | null;
  search?: string | null;
}): { rows: ActivationRow[]; total: number } {
  const where: string[] = [];
  const args: unknown[] = [];

  if (opts.status) {
    where.push("t.status = ?");
    args.push(opts.status);
  }
  if (opts.search) {
    where.push("(t.email LIKE ? ESCAPE '\\' OR t.code LIKE ? ESCAPE '\\' OR t.id LIKE ? ESCAPE '\\' OR IFNULL(t.ip,'') LIKE ? ESCAPE '\\')");
    const term = likeTerm(opts.search);
    args.push(term, term, term, term);
  }

  const clause = where.length ? `WHERE ${where.join(" AND ")}` : "";

  const total = (
    getDb()
      .prepare(`SELECT COUNT(*) AS n FROM tasks t ${clause}`)
      .get(...args) as { n: number }
  ).n;

  const rows = getDb()
    .prepare(
      `SELECT t.*, k.plan AS plan, k.status AS key_status, k.used_at AS used_at
         FROM tasks t
         LEFT JOIN keys k ON k.code = t.code
         ${clause}
        ORDER BY t.created_at DESC, t.rowid DESC
        LIMIT ? OFFSET ?`
    )
    .all(...args, opts.limit, opts.offset) as ActivationRow[];

  return { rows, total };
}

export function getActivationStats(): {
  total: number;
  processing: number;
  completed: number;
  failed: number;
  cancelled: number;
  today: number;
} {
  const midnight = new Date();
  midnight.setHours(0, 0, 0, 0);

  const row = getDb()
    .prepare(
      `SELECT
         COUNT(*) AS total,
         SUM(CASE WHEN status='processing' THEN 1 ELSE 0 END) AS processing,
         SUM(CASE WHEN status='completed'  THEN 1 ELSE 0 END) AS completed,
         SUM(CASE WHEN status='failed'     THEN 1 ELSE 0 END) AS failed,
         SUM(CASE WHEN status='cancelled'  THEN 1 ELSE 0 END) AS cancelled,
         SUM(CASE WHEN created_at >= ?     THEN 1 ELSE 0 END) AS today
       FROM tasks`
    )
    .get(midnight.toISOString()) as Record<string, number | null>;

  const n = (v: number | null | undefined) => v ?? 0;
  return {
    total: n(row.total),
    processing: n(row.processing),
    completed: n(row.completed),
    failed: n(row.failed),
    cancelled: n(row.cancelled),
    today: n(row.today),
  };
}

export function getKeyStats(): {
  total: number;
  available: number;
  used: number;
  disabled: number;
} {
  const row = getDb()
    .prepare(
      `SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) AS available,
        SUM(CASE WHEN status='used' THEN 1 ELSE 0 END) AS used,
        SUM(CASE WHEN status='disabled' THEN 1 ELSE 0 END) AS disabled
       FROM keys`
    )
    .get() as { total: number; available: number; used: number; disabled: number };
  return {
    total: row.total ?? 0,
    available: row.available ?? 0,
    used: row.used ?? 0,
    disabled: row.disabled ?? 0,
  };
}

export function getAdminByUsername(username: string): AdminUser | undefined {
  return getDb()
    .prepare("SELECT * FROM admins WHERE username = ?")
    .get(username) as AdminUser | undefined;
}

export function createAdmin(username: string, passwordHash: string): void {
  getDb()
    .prepare("INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)")
    .run(username, passwordHash, now());
}

export function countAdmins(): number {
  const row = getDb().prepare("SELECT COUNT(*) AS n FROM admins").get() as {
    n: number;
  };
  return row.n;
}
