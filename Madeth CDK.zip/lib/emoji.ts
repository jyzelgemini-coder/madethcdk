/**
 * Helpers for rendering emoji in their colour form.
 *
 * Several glyphs used around the site (⚡ ✉ 🏷 ⌨ ❗ ⚠) default to the
 * monochrome *text* presentation, so they show up as flat outlines next to
 * the fully-coloured ones. Appending VS16 requests the emoji presentation;
 * it is inert on code points that have no text variant.
 */

/** One emoji "grapheme": a pictograph plus optional variation selector,
 *  skin-tone modifier, and any ZWJ-joined continuation. */
export const EMOJI_RE =
  /(\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\p{Emoji_Modifier})?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\p{Emoji_Modifier})?)*)/gu;

const VS16 = "\uFE0F";
const VS15 = "\uFE0E";

export function toColorEmoji(seq: string): string {
  if (seq.includes(VS16) || seq.includes(VS15)) return seq;
  return seq + VS16;
}

/** Splits text into alternating plain / emoji chunks (emoji at odd indexes). */
export function splitEmoji(text: string): string[] {
  return text.split(EMOJI_RE);
}

/**
 * Wraps emoji in `<span class="emo">` inside an HTML string, for the few
 * places that inject markup. Callers must already trust the input.
 */
export function emojiHtml(html: string): string {
  return html.replace(EMOJI_RE, (m) => `<span class="emo">${toColorEmoji(m)}</span>`);
}
