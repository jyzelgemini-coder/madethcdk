export type Lang = "en" | "km" | "zh";

export interface Dict {
  navActivate: string;
  navGuide: string;
  hudLive: string;
  tabSingle: string;
  tabCheck: string;
  trustOnce: string;
  trustSecure: string;
  trustTime: string;
  step1Label: string;
  step2Label: string;
  step3Label: string;
  s1Title: string;
  s1Sub: string;
  lblCdk: string;
  btnCheckCode: string;
  s2Title: string;
  s2Sub: string;
  lblEmail: string;
  lblPassword: string;
  lblSecret: string;
  txtSecretHint: string;
  lblBackup: string;
  txtBackupHint: string;
  optional: string;
  btnBack: string;
  btnActivate: string;
  progressTitle: string;
  processingHint: string;
  lblTaskId: string;
  lblStatus: string;
  lblAccountEmail: string;
  lblReason: string;
  lblTime: string;
  btnReset: string;
  verified: string;
  copy: string;
  copied: string;
  showPassword: string;
  hidePassword: string;
  statusRunning: string;
  statusCompleted: string;
  statusFailed: string;
  statusCancelled: string;
  txtCheckTitle: string;
  txtCheckSub: string;
  lblCheckInput: string;
  txtCheckHint: string;
  btnCheckStatus: string;
  notFound: string;
  notFoundHint: string;
  needHelp: string;
  guideHeroTitle: string;
  guideHeroSub: string;
  txtG1Title: string;
  txtG1Desc: string;
  txtG2Title: string;
  txtG2Desc: string;
  txtG3Title: string;
  txtG3Desc: string;
  txtG4Title: string;
  txtG4Desc: string;
  guideVideoTitle: string;
  guideVideoSub: string;
  errEmptyCode: string;
  errEmptyAccount: string;
  noteTitle: string;
  noteItem1: string;
  noteItem2: string;
  noteItem3: string;
  noteItem4: string;
  noteFoot: string;
  footerAdmin: string;
}

export const i18n: Record<Lang, Dict> = {
  en: {
    navActivate: "Activate",
    navGuide: "Guide",
    hudLive: "LIVE",
    tabSingle: "Activate",
    tabCheck: "Check status",
    trustOnce: "Single-use codes",
    trustSecure: "Credentials are never stored",
    trustTime: "Usually 2–5 minutes",
    step1Label: "Verify code",
    step2Label: "Account",
    step3Label: "Progress",
    s1Title: "Unlock a CDK",
    s1Sub: "The gate only opens for an unused code. Account details come after that.",
    lblCdk: "CDK code",
    btnCheckCode: "Unlock",
    s2Title: "Connect Gmail",
    s2Sub: "Forwarded to the upgrade job, then discarded. Nothing is written to our database.",
    lblEmail: "Gmail address",
    lblPassword: "Password",
    lblSecret: "2FA secret key",
    txtSecretHint: "32 characters from the authenticator app — letters A–Z and digits 2–7.",
    lblBackup: "Backup codes",
    txtBackupHint: "Skip this if you don’t have them. Otherwise 2 or 3 codes of 8 digits, separated by spaces.",
    optional: "optional",
    btnBack: "Back",
    btnActivate: "Run upgrade",
    progressTitle: "Upgrade running",
    processingHint: "Keep this page open. Status updates every few seconds.",
    lblTaskId: "Task ID",
    lblStatus: "Status",
    lblAccountEmail: "Account",
    lblReason: "Details",
    lblTime: "Started",
    btnReset: "Activate another code",
    verified: "Verified",
    copy: "Copy",
    copied: "Copied",
    showPassword: "Show password",
    hidePassword: "Hide password",
    statusRunning: "Processing",
    statusCompleted: "Completed",
    statusFailed: "Failed",
    statusCancelled: "Cancelled",
    txtCheckTitle: "Query a job",
    txtCheckSub: "Paste the task ID from the run screen. Codes themselves cannot be looked up after use.",
    lblCheckInput: "Task ID",
    txtCheckHint: "Starts with T-, for example T-MSRRT1L2-XHUVKL4Q3XTD",
    btnCheckStatus: "Query",
    notFound: "Nothing found for that ID",
    notFoundHint: "Double-check the task ID. Codes themselves cannot be looked up after use.",
    needHelp: "Need a walkthrough? Open the guide",
    guideHeroTitle: "How activation works",
    guideHeroSub: "Four short steps. Prepare the Gmail account first — most failures come from skipping that.",
    txtG1Title: "Verify your code",
    txtG1Desc:
      "Open Activate, enter the code in MD-CDK-XXXXXXX format, and continue. A used or disabled code is rejected immediately.",
    txtG2Title: "Enter Gemini account details",
    txtG2Desc:
      "Use an established Gmail address, its password, and the 32-character 2FA secret key. Backup codes are optional. New accounts are far more likely to be blocked.",
    txtG3Title: "Watch live progress",
    txtG3Desc:
      "The page polls automatically. Processing means the job is still running; completed means it succeeded. Typical time is 2–5 minutes.",
    txtG4Title: "Check a previous activation",
    txtG4Desc:
      "Save the task ID from the progress screen. Use Check status later if you close the page — the code itself cannot be reused.",
    guideVideoTitle: "Prepare Gmail for Gemini Pro Pixel",
    guideVideoSub: "Watch this before submitting. Most “human verification” errors come from an unprepared account.",
    errEmptyCode: "Please enter a CDK code",
    errEmptyAccount: "Please enter the Gmail address, password, and 2FA secret key",
    noteTitle: "Before you start",
    noteItem1: "Use an <b>existing Gmail</b> — a brand-new mailbox is much more likely to be banned.",
    noteItem2: "Close any payment profile on the account.",
    noteItem3: "Leave any Google Family group.",
    noteItem4: "Make sure no Pro or Ultra plan is already running.",
    noteFoot:
      "Most errors can be fixed by following this list. “Human verification” usually means the Gmail account itself is restricted and may need a manual check.",
    footerAdmin: "Admin",
  },
  km: {
    navActivate: "ដំណើរការ",
    navGuide: "ការណែនាំ",
    hudLive: "LIVE",
    tabSingle: "ដំណើរការ",
    tabCheck: "ពិនិត្យស្ថានភាព",
    trustOnce: "លេខកូដប្រើបានម្តង",
    trustSecure: "ពាក្យសម្ងាត់មិនត្រូវបានរក្សាទុក",
    trustTime: "ជាធម្មតា ២–៥ នាទី",
    step1Label: "ពិនិត្យលេខកូដ",
    step2Label: "គណនី",
    step3Label: "វឌ្ឍនភាព",
    s1Title: "បញ្ចូលលេខកូដ CDK",
    s1Sub: "យើងនឹងបញ្ជាក់ថាលេខកូដមិនទាន់ប្រើ មុនពេលសុំព័ត៌មានគណនី។",
    lblCdk: "លេខកូដ CDK",
    btnCheckCode: "បើកសោ",
    s2Title: "ភ្ជាប់ Gmail",
    s2Sub: "ប្រើសម្រាប់ការដំណើរការនេះតែប៉ុណ្ណោះ។ ពាក្យសម្ងាត់ និង 2FA ត្រូវបានបញ្ជូនទៅមុខ រួចលុប។",
    lblEmail: "អាសយដ្ឋាន Gmail",
    lblPassword: "ពាក្យសម្ងាត់",
    lblSecret: "កូនសោ 2FA",
    txtSecretHint:
      "កូនសោ ៣២ តួអក្សរពីកម្មវិធី Authenticator (A–Z និងលេខ 2–7)។ ការផ្ទៀងផ្ទាត់ពីរជាន់ត្រូវបានបើក បើមិនដូច្នេះ Google នឹងទប់ស្កាត់ការចូល។",
    lblBackup: "លេខកូដបម្រុង",
    txtBackupHint:
      "ទុកឲ្យទំនេរ បើអ្នកគ្មាន។ បើមាន សូមបញ្ចូល ២ ឬ ៣ លេខកូដ ដែលនីមួយៗមាន ៨ ខ្ទង់ ដោយបែងចែកដោយចន្លោះ។",
    optional: "ស្រេចចិត្ត",
    btnBack: "ត្រលប់ក្រោយ",
    btnActivate: "ដំណើរការការដំឡើង",
    progressTitle: "កំពុងដំណើរការ",
    processingHint: "សូមទុកទំព័រនេះឱ្យបើក។ ស្ថានភាពធ្វើបច្ចុប្បន្នភាពរៀងរាល់ពីរបីវិនាទី។",
    lblTaskId: "លេខសម្គាល់ភារកិច្ច",
    lblStatus: "ស្ថានភាព",
    lblAccountEmail: "គណនី",
    lblReason: "ព័ត៌មានលម្អិត",
    lblTime: "ចាប់ផ្តើម",
    btnReset: "ដំណើរការលេខកូដផ្សេងទៀត",
    verified: "បានផ្ទៀងផ្ទាត់",
    copy: "ចម្លង",
    copied: "បានចម្លង",
    showPassword: "បង្ហាញពាក្យសម្ងាត់",
    hidePassword: "លាក់ពាក្យសម្ងាត់",
    statusRunning: "កំពុងដំណើរការ",
    statusCompleted: "ជោគជ័យ",
    statusFailed: "បរាជ័យ",
    statusCancelled: "បានបោះបង់",
    txtCheckTitle: "ស្វែងរកការដំណើរការ",
    txtCheckSub: "បិទភ្ជាប់ Task ID ពីអេក្រង់វឌ្ឍនភាព ដើម្បីមើលលទ្ធផលចុងក្រោយ។",
    lblCheckInput: "Task ID",
    txtCheckHint: "ចាប់ផ្តើមដោយ T- ឧទាហរណ៍ T-MSRRT1L2-XHUVKL4Q3XTD",
    btnCheckStatus: "ស្វែងរក",
    notFound: "រកមិនឃើញលេខសម្គាល់នេះ",
    notFoundHint: "សូមពិនិត្យ Task ID ម្ដងទៀត។ លេខកូដ CDK មិនអាចស្វែងរកបានបន្ទាប់ពីប្រើ។",
    needHelp: "ត្រូវការណែនាំ? បើកទំព័រការណែនាំ",
    guideHeroTitle: "របៀបដំណើរការ",
    guideHeroSub: "បួនជំហានខ្លី។ រៀបចំគណនី Gmail ជាមុន — កំហុសភាគច្រើនកើតពីការរំលងនេះ។",
    txtG1Title: "ផ្ទៀងផ្ទាត់លេខកូដ",
    txtG1Desc:
      "បើក Activate បញ្ចូលលេខកូដទម្រង់ MD-CDK-XXXXXXX រួចបន្ត។ លេខកូដដែលបានប្រើ ឬត្រូវបានបិទ នឹងត្រូវបដិសេធភ្លាម។",
    txtG2Title: "បញ្ចូលព័ត៌មានគណនី Gemini",
    txtG2Desc:
      "ប្រើ Gmail ចាស់ ពាក្យសម្ងាត់ និងកូនសោ 2FA ៣២ តួ។ លេខកូដបម្រុងជាការស្រេចចិត្ត។ គណនីថ្មីងាយត្រូវបានបិទ។",
    txtG3Title: "តាមដានវឌ្ឍនភាព",
    txtG3Desc:
      "ទំព័រពិនិត្យស្ថានភាពដោយស្វ័យប្រវត្តិ។ Processing មានន័យថាកំពុងដំណើរការ completed មានន័យថាជោគជ័យ។ ជាធម្មតា ២–៥ នាទី។",
    txtG4Title: "ពិនិត្យការដំណើរការមុន",
    txtG4Desc:
      "រក្សាទុក Task ID ពីអេក្រង់វឌ្ឍនភាព។ ប្រើ Check status ប្រសិនបើអ្នកបិទទំព័រ — លេខកូដមិនអាចប្រើឡើងវិញបានទេ។",
    guideVideoTitle: "រៀបចំ Gmail សម្រាប់ Gemini Pro Pixel",
    guideVideoSub: "មើលមុនពេលដាក់ស្នើ។ កំហុស “human verification” ភាគច្រើនកើតពីគណនីមិនទាន់រៀបចំ។",
    errEmptyCode: "សូមបញ្ចូលលេខកូដ CDK",
    errEmptyAccount: "សូមបញ្ចូលអាសយដ្ឋាន Gmail ពាក្យសម្ងាត់ និងកូនសោ 2FA",
    noteTitle: "មុនពេលចាប់ផ្តើម",
    noteItem1: "ប្រើ <b>Gmail ចាស់</b> — ប្រអប់សំបុត្រថ្មីងាយត្រូវបានបិទ។",
    noteItem2: "បិទ payment profile លើគណនី។",
    noteItem3: "ចាកចេញពីក្រុម Google Family។",
    noteItem4: "ប្រាកដថាគ្មានផែនការ Pro ឬ Ultra កំពុងដំណើរការ។",
    noteFoot:
      "កំហុសភាគច្រើនអាចដោះស្រាយបានដោយធ្វើតាមបញ្ជីនេះ។ “Human verification” ជាធម្មតាមានន័យថាគណនី Gmail ត្រូវបានដាក់កំហិត។",
    footerAdmin: "អ្នកគ្រប់គ្រង",
  },
  zh: {
    navActivate: "激活",
    navGuide: "指南",
    hudLive: "LIVE",
    tabSingle: "激活",
    tabCheck: "查询状态",
    trustOnce: "一次性兑换码",
    trustSecure: "凭据不会被保存",
    trustTime: "通常 2–5 分钟",
    step1Label: "验证兑换码",
    step2Label: "账户",
    step3Label: "进度",
    s1Title: "输入 CDK 兑换码",
    s1Sub: "我们会先确认兑换码未被使用，再要求填写账户信息。",
    lblCdk: "CDK 兑换码",
    btnCheckCode: "解锁",
    s2Title: "连接 Gmail",
    s2Sub: "仅用于完成本次激活。密码和 2FA 会被转发后立即丢弃。",
    lblEmail: "Gmail 地址",
    lblPassword: "密码",
    lblSecret: "2FA 密钥",
    txtSecretHint:
      "验证器应用中的 32 位密钥（字母 A–Z 和数字 2–7）。账户必须已启用两步验证，否则 Google 会拦截登录。",
    lblBackup: "备用验证码",
    txtBackupHint: "如果没有可留空。如有，请输入 2 或 3 组 8 位数字，用空格分隔。",
    optional: "选填",
    btnBack: "返回",
    btnActivate: "开始升级",
    progressTitle: "正在激活",
    processingHint: "请保持此页面打开。状态每隔几秒更新一次。",
    lblTaskId: "任务 ID",
    lblStatus: "状态",
    lblAccountEmail: "账户",
    lblReason: "详情",
    lblTime: "开始时间",
    btnReset: "激活另一个兑换码",
    verified: "已验证",
    copy: "复制",
    copied: "已复制",
    showPassword: "显示密码",
    hidePassword: "隐藏密码",
    statusRunning: "处理中",
    statusCompleted: "已完成",
    statusFailed: "失败",
    statusCancelled: "已取消",
    txtCheckTitle: "查询激活结果",
    txtCheckSub: "粘贴进度页面上的任务 ID，查看最新结果。",
    lblCheckInput: "任务 ID",
    txtCheckHint: "以 T- 开头，例如 T-MSRRT1L2-XHUVKL4Q3XTD",
    btnCheckStatus: "查询",
    notFound: "未找到该 ID",
    notFoundHint: "请核对任务 ID。兑换码本身在使用后无法查询。",
    needHelp: "需要分步说明？打开指南",
    guideHeroTitle: "激活流程",
    guideHeroSub: "四个简短步骤。请先准备好 Gmail 账户——大多数失败都来自跳过这一步。",
    txtG1Title: "验证兑换码",
    txtG1Desc: "打开“激活”，输入 MD-CDK-XXXXXXX 格式的兑换码并继续。已使用或已停用的兑换码会立即被拒绝。",
    txtG2Title: "填写 Gemini 账户",
    txtG2Desc:
      "使用已有的 Gmail、密码和 32 位 2FA 密钥。备用验证码为选填。新账户更容易被拦截。",
    txtG3Title: "查看实时进度",
    txtG3Desc: "页面会自动刷新。Processing 表示仍在处理，completed 表示成功。通常需要 2–5 分钟。",
    txtG4Title: "查询以往激活",
    txtG4Desc: "请保存进度页上的任务 ID。关闭页面后可用“查询状态”——兑换码本身无法再次使用。",
    guideVideoTitle: "为 Gemini Pro Pixel 准备 Gmail",
    guideVideoSub: "提交前请先观看。大多数“human verification”错误来自未准备好的账户。",
    errEmptyCode: "请输入 CDK 兑换码",
    errEmptyAccount: "请输入 Gmail 地址、密码和 2FA 密钥",
    noteTitle: "开始之前",
    noteItem1: "请使用<b>已有的 Gmail</b>——全新邮箱更容易被封。",
    noteItem2: "关闭账户上的付款资料。",
    noteItem3: "退出 Google 家庭组。",
    noteItem4: "确认当前没有正在运行的 Pro 或 Ultra 套餐。",
    noteFoot: "按此清单操作通常可以解决大多数错误。“Human verification”通常表示 Gmail 账户本身受限，可能需要人工处理。",
    footerAdmin: "管理后台",
  },
};

export const defaultLang: Lang = "en";

export const languageOptions: { value: Lang; label: string }[] = [
  { value: "en", label: "English" },
  { value: "km", label: "ខ្មែរ" },
  { value: "zh", label: "中文" },
];
