/**
 * Masks an email for display on public endpoints.
 *
 * Keeps enough for the owner to recognise their own account while making a
 * harvested list useless: "johndoe@gmail.com" becomes "jo•••••@gmail.com".
 */
export function maskEmail(email: string | null | undefined): string {
  if (!email) return "";
  const at = email.lastIndexOf("@");
  if (at <= 0) return "•••";

  const local = email.slice(0, at);
  const domain = email.slice(at);
  const keep = local.length <= 2 ? 1 : 2;
  return `${local.slice(0, keep)}${"•".repeat(Math.max(3, local.length - keep))}${domain}`;
}
