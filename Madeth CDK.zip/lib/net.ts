import type { NextRequest } from "next/server";

/**
 * Resolves the client IP for rate limiting and audit logging.
 *
 * `X-Forwarded-For` is attacker-controlled: anything the client sends arrives
 * verbatim in the leftmost positions, so reading `xff[0]` lets anyone reset
 * their own rate-limit bucket on every request. Each proxy *appends* the peer
 * it actually saw, so the trustworthy entry is counted from the right:
 * with one reverse proxy in front of the app, the last entry is the real peer.
 *
 * Set TRUSTED_PROXY_HOPS to the number of proxies you control (nginx, ALB,
 * Cloudflare...). Use 0 when the app is exposed directly, which makes the
 * header be ignored entirely.
 */
const HOPS = Math.max(0, Number(process.env.TRUSTED_PROXY_HOPS ?? "1") || 0);

/**
 * Returns the client IP, or null when it cannot be established.
 *
 * Callers must treat null as "cannot be attributed" and fall back to a global
 * limit rather than lumping every visitor into one shared bucket, which would
 * let the first busy visitor lock everyone else out.
 */
export function getClientIp(req: NextRequest): string | null {
  // Cloudflare's header cannot be spoofed through their edge, but only trust it
  // when the deployment actually sits behind Cloudflare.
  if (process.env.TRUST_CF_CONNECTING_IP === "1") {
    const cf = req.headers.get("cf-connecting-ip")?.trim();
    if (cf) return cf.slice(0, 64);
  }

  if (HOPS > 0) {
    const chain = (req.headers.get("x-forwarded-for") || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (chain.length) {
      // Ignore any hops the client injected to the left of our own proxies.
      return chain[Math.max(0, chain.length - HOPS)].slice(0, 64);
    }
    const real = req.headers.get("x-real-ip")?.trim();
    if (real) return real.slice(0, 64);
  }

  return null;
}

/** Trimmed user-agent, capped so a hostile client cannot bloat logs. */
export function getUserAgent(req: NextRequest): string {
  return (req.headers.get("user-agent") || "").slice(0, 400);
}

/**
 * Parses a JSON body while refusing oversized payloads.
 *
 * `req.json()` will happily buffer whatever it is given, so an unauthenticated
 * endpoint without a ceiling is a free memory-pressure lever.
 */
export async function readJsonBody<T = unknown>(
  req: NextRequest,
  maxBytes = 8_192
): Promise<{ ok: true; data: T } | { ok: false; tooLarge: boolean }> {
  const declared = Number(req.headers.get("content-length") || "0");
  if (Number.isFinite(declared) && declared > maxBytes) {
    return { ok: false, tooLarge: true };
  }

  let text: string;
  try {
    text = await req.text();
  } catch {
    return { ok: false, tooLarge: false };
  }
  if (text.length > maxBytes) return { ok: false, tooLarge: true };

  try {
    return { ok: true, data: JSON.parse(text) as T };
  } catch {
    return { ok: false, tooLarge: false };
  }
}

/**
 * True when the request is definitely cross-site.
 *
 * Browsers always attach `Origin` to cross-origin state-changing requests, so
 * a mismatch is a reliable CSRF signal. A missing header is not treated as an
 * attack (non-browser clients omit it); those requests still have to present a
 * valid CSRF token.
 */
export function isCrossSite(req: NextRequest): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return false;
  try {
    return new URL(origin).host !== (req.headers.get("host") || "");
  } catch {
    return true;
  }
}
