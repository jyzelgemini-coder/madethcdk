import type { Lang } from "@/lib/i18n";

/**
 * Client for the Pixel Partner API v2 (https://api.smm.io.vn).
 *
 * Server-side only. PIXEL_API_KEY must never be exposed to the browser,
 * so every function here is expected to run inside a route handler.
 */

const API_BASE = process.env.PIXEL_API_BASE || "https://api.smm.io.vn";
const REQUEST_TIMEOUT_MS = 20_000;

export type PixelJobStatus =
  | "pending"
  | "running"
  | "success"
  | "error"
  | "failed"
  | "cancelled";

export interface PixelSubmitResult {
  ok: true;
  jobId: number;
  position: number;
  cost: number;
}

export interface PixelFailure {
  ok: false;
  /** Machine-readable key from the upstream API, e.g. "not_enough_coins". */
  error: string;
  /** HTTP status suitable for relaying to our own client. */
  status: number;
}

export interface PixelJobState {
  ok: true;
  jobId: number;
  email: string;
  status: PixelJobStatus;
  position: number;
  currentStep: string;
  errorMsg: string;
  createdAt: string;
  finishedAt: string;
}

export interface ParsedSecret {
  totp: string;
  backup?: string[];
}

const TOTP_RE = /^[A-Z2-7]{32}$/;
const BACKUP_RE = /^\d{8}$/;

/**
 * Normalises the single "2FA secret or backup code" field into the shape the
 * Pixel API expects.
 *
 * Accepts a 32-character Base32 TOTP secret on its own, or that secret plus
 * two or three eight-digit backup codes separated by whitespace, commas or
 * newlines. Pixel requires `totp` on every submission, so backup codes without
 * a TOTP secret are rejected here rather than upstream.
 *
 * Returns a `ParsedSecret` on success or an error key on failure.
 */
export function normalizeSecret(
  raw: string
): { ok: true; value: ParsedSecret } | { ok: false; error: SecretError } {
  const cleaned = raw
    .replace(/[\u200B\uFEFF]/g, "")
    .replace(/-/g, "")
    .toUpperCase();

  const tokens = cleaned.split(/[\s,;|]+/).filter(Boolean);
  if (tokens.length === 0) return { ok: false, error: "secret_empty" };

  const totps = tokens.filter((tk) => TOTP_RE.test(tk));
  const backups = tokens.filter((tk) => BACKUP_RE.test(tk));
  const unknown = tokens.filter(
    (tk) => !TOTP_RE.test(tk) && !BACKUP_RE.test(tk)
  );

  if (totps.length === 0) {
    // Backup codes alone cannot be submitted: Pixel always requires a TOTP.
    if (backups.length > 0) return { ok: false, error: "secret_totp_required" };
    return { ok: false, error: "secret_invalid" };
  }
  if (totps.length > 1) return { ok: false, error: "secret_invalid" };
  if (unknown.length > 0) return { ok: false, error: "secret_invalid" };
  if (backups.length === 1) return { ok: false, error: "secret_backup_count" };
  if (backups.length > 3) return { ok: false, error: "secret_backup_count" };

  return {
    ok: true,
    value: backups.length >= 2 ? { totp: totps[0], backup: backups } : { totp: totps[0] },
  };
}

export type SecretError =
  | "secret_empty"
  | "secret_invalid"
  | "secret_totp_required"
  | "secret_backup_count";

async function pixelFetch(
  path: string,
  body: unknown
): Promise<{ ok: true; data: Record<string, unknown> } | PixelFailure> {
  const apiKey = process.env.PIXEL_API_KEY;
  if (!apiKey) {
    return { ok: false, error: "config_missing_key", status: 500 };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const res = await fetch(API_BASE + path, {
      method: "POST",
      headers: {
        "X-API-Key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
      signal: controller.signal,
      cache: "no-store",
    });

    let data: Record<string, unknown>;
    try {
      data = (await res.json()) as Record<string, unknown>;
    } catch {
      return { ok: false, error: "upstream_bad_response", status: 502 };
    }

    if (data.ok !== true) {
      return {
        ok: false,
        error: typeof data.error === "string" ? data.error : "upstream_error",
        status: res.status >= 400 ? res.status : 502,
      };
    }
    return { ok: true, data };
  } catch (err) {
    const aborted = err instanceof Error && err.name === "AbortError";
    return {
      ok: false,
      error: aborted ? "upstream_timeout" : "upstream_unreachable",
      status: 504,
    };
  } finally {
    clearTimeout(timer);
  }
}

/** Enqueues a single Pixel job. */
export async function submitJob(input: {
  gmail: string;
  password: string;
  totp: string;
  backup?: string[];
}): Promise<PixelSubmitResult | PixelFailure> {
  const payload: Record<string, unknown> = {
    gmail: input.gmail,
    password: input.password,
    totp: input.totp,
  };
  if (input.backup && input.backup.length >= 2) payload.backup = input.backup;

  const res = await pixelFetch("/api/v2/pixel/submit", payload);
  if (!res.ok) return res;

  const results = Array.isArray(res.data.results) ? res.data.results : [];
  const first = results[0] as Record<string, unknown> | undefined;

  if (!first || first.ok !== true || typeof first.job_id !== "number") {
    return {
      ok: false,
      error: typeof first?.error === "string" ? first.error : "submit_rejected",
      status: 400,
    };
  }

  return {
    ok: true,
    jobId: first.job_id,
    position: typeof first.position === "number" ? first.position : 0,
    cost: typeof first.cost === "number" ? first.cost : 0,
  };
}

/** Reads the current state of a single Pixel job. */
export async function getJobStatus(
  jobId: number
): Promise<PixelJobState | PixelFailure> {
  const res = await pixelFetch("/api/v2/pixel/status", { job_id: jobId });
  if (!res.ok) return res;

  const results = Array.isArray(res.data.results) ? res.data.results : [];
  const first = results[0] as Record<string, unknown> | undefined;

  if (!first || first.ok !== true) {
    return {
      ok: false,
      error: typeof first?.error === "string" ? first.error : "job_not_found",
      status: 404,
    };
  }

  const str = (v: unknown) => (typeof v === "string" ? v : "");
  return {
    ok: true,
    jobId,
    email: str(first.email),
    status: (str(first.status) || "pending") as PixelJobStatus,
    position: typeof first.position === "number" ? first.position : 0,
    currentStep: str(first.current_step),
    errorMsg: str(first.error_msg),
    createdAt: str(first.created_at),
    finishedAt: str(first.finished_at),
  };
}

/**
 * Maps a documented automation step to a percentage for the progress bar.
 * Returns null for unrecognised steps so the caller can keep the last value.
 */
export function mapProgress(currentStep: string): number | null {
  const key = currentStep.trim().toLowerCase();
  const table: Record<string, number> = {
    "waiting for device": 5,
    starting: 10,
    email: 20,
    "spam check": 30,
    password: 40,
    "2-step authentication": 50,
    "payment method": 60,
    "add payment": 70,
    "offer check": 80,
    "receive offer": 90,
    "payment processing": 95,
    completed: 100,
  };
  return key in table ? table[key] : null;
}

/** Errors Pixel retries automatically (up to 3 times); we must not resubmit. */
const AUTO_RETRY = new Set([
  "pixel_err_login_timeout",
  "pixel_err_adb_connect",
  "pixel_err_pwweb",
  "pixel_err_setup_stuck",
  "pixel_err_unknown",
]);

export function isAutoRetry(errorMsg: string): boolean {
  return AUTO_RETRY.has(errorMsg);
}

type Messages = Record<Lang, string>;

const ERROR_MESSAGES: Record<string, Messages> = {
  // --- Local validation ---
  secret_empty: {
    en: "Please enter your 2FA secret key.",
    km: "សូមបញ្ចូលកូនសោអាថ៌កំបាំង 2FA របស់អ្នក។",
    zh: "请输入您的 2FA 密钥。",
  },
  secret_invalid: {
    en: "Invalid 2FA secret. It must be a 32-character key (letters A–Z and digits 2–7).",
    km: "កូនសោ 2FA មិនត្រឹមត្រូវ។ ត្រូវមាន 32 តួអក្សរ (A–Z និងលេខ 2–7)។",
    zh: "2FA 密钥无效。必须为 32 位字符（字母 A–Z 和数字 2–7）。",
  },
  secret_totp_required: {
    en: "Backup codes alone are not enough. Please also enter your 32-character 2FA secret key.",
    km: "លេខកូដបម្រុងតែឯងមិនគ្រប់គ្រាន់ទេ។ សូមបញ្ចូលកូនសោ 2FA ចំនួន 32 តួផងដែរ។",
    zh: "仅有备用验证码不足。请同时输入您的 32 位 2FA 密钥。",
  },
  secret_backup_count: {
    en: "Backup codes must be 2 or 3 codes of exactly 8 digits each.",
    km: "លេខកូដបម្រុងត្រូវមាន 2 ឬ 3 លេខកូដ ដែលនីមួយៗមាន 8 ខ្ទង់។",
    zh: "备用验证码必须是 2 或 3 组，每组正好 8 位数字。",
  },
  invalid_email_domain: {
    en: "Only @gmail.com addresses are supported.",
    km: "គាំទ្រតែអាសយដ្ឋាន @gmail.com ប៉ុណ្ណោះ។",
    zh: "仅支持 @gmail.com 邮箱地址。",
  },

  // --- Transport / configuration ---
  config_missing_key: {
    en: "Service is not configured. Please contact support.",
    km: "សេវាកម្មមិនទាន់បានកំណត់រចនាសម្ព័ន្ធ។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "服务尚未配置，请联系客服。",
  },
  upstream_timeout: {
    en: "The activation service did not respond in time. Please try again.",
    km: "សេវាកម្មដំណើរការមិនបានឆ្លើយតបទាន់ពេល។ សូមព្យាយាមម្តងទៀត។",
    zh: "激活服务响应超时，请重试。",
  },
  upstream_unreachable: {
    en: "Cannot reach the activation service. Please try again shortly.",
    km: "មិនអាចភ្ជាប់ទៅសេវាកម្មដំណើរការបានទេ។ សូមព្យាយាមម្តងទៀតបន្តិចទៀត។",
    zh: "无法连接激活服务，请稍后重试。",
  },
  upstream_bad_response: {
    en: "The activation service returned an unexpected response.",
    km: "សេវាកម្មដំណើរការបានឆ្លើយតបមិនត្រឹមត្រូវ។",
    zh: "激活服务返回了异常响应。",
  },
  upstream_error: {
    en: "The activation service reported an error. Please try again.",
    km: "សេវាកម្មដំណើរការបានរាយការណ៍កំហុស។ សូមព្យាយាមម្តងទៀត។",
    zh: "激活服务报告了错误，请重试。",
  },

  // --- Partner API level ---
  missing_api_key: {
    en: "Service authentication failed. Please contact support.",
    km: "ការផ្ទៀងផ្ទាត់សេវាកម្មបរាជ័យ។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "服务认证失败，请联系客服。",
  },
  invalid_api_key: {
    en: "Service authentication failed. Please contact support.",
    km: "ការផ្ទៀងផ្ទាត់សេវាកម្មបរាជ័យ។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "服务认证失败，请联系客服。",
  },
  partner_suspended: {
    en: "The service account is suspended. Please contact support.",
    km: "គណនីសេវាកម្មត្រូវបានផ្អាក។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "服务账户已被暂停，请联系客服。",
  },
  blocked: {
    en: "This request was blocked. Please contact support.",
    km: "សំណើនេះត្រូវបានទប់ស្កាត់។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "此请求已被拦截，请联系客服。",
  },
  missing_fields: {
    en: "Some required account details are missing.",
    km: "ព័ត៌មានគណនីមួយចំនួនដែលចាំបាច់មិនត្រូវបានបំពេញ។",
    zh: "缺少部分必填的账户信息。",
  },
  invalid_gmail: {
    en: "Only @gmail.com addresses are supported.",
    km: "គាំទ្រតែអាសយដ្ឋាន @gmail.com ប៉ុណ្ណោះ។",
    zh: "仅支持 @gmail.com 邮箱地址。",
  },
  invalid_totp: {
    en: "The 2FA secret key is not valid. It must be 32 Base32 characters.",
    km: "កូនសោ 2FA មិនត្រឹមត្រូវ។ ត្រូវមាន 32 តួ Base32។",
    zh: "2FA 密钥无效，必须为 32 位 Base32 字符。",
  },
  invalid_backup_codes: {
    en: "One or more backup codes are not exactly 8 digits.",
    km: "លេខកូដបម្រុងមួយ ឬច្រើនមិនមាន 8 ខ្ទង់គត់ទេ។",
    zh: "一个或多个备用验证码不是正好 8 位数字。",
  },
  invalid_backup_count: {
    en: "Please provide either 2 or 3 backup codes.",
    km: "សូមផ្តល់លេខកូដបម្រុងចំនួន 2 ឬ 3។",
    zh: "请提供 2 组或 3 组备用验证码。",
  },
  invalid_json: {
    en: "The activation request could not be read. Please try again.",
    km: "មិនអាចអានសំណើដំណើរការបានទេ។ សូមព្យាយាមម្តងទៀត។",
    zh: "无法读取激活请求，请重试。",
  },
  invalid_job_id: {
    en: "Invalid activation job reference.",
    km: "លេខសម្គាល់ភារកិច្ចមិនត្រឹមត្រូវ។",
    zh: "激活任务标识无效。",
  },
  not_enough_coins: {
    en: "The service is temporarily out of credit. Please contact support.",
    km: "សេវាកម្មអស់ឥណទានបណ្តោះអាសន្ន។ សូមទាក់ទងផ្នែកជំនួយ។",
    zh: "服务额度暂时不足，请联系客服。",
  },
  burst_limit_exceeded: {
    en: "Too many requests. Please wait a moment and try again.",
    km: "សំណើច្រើនពេក។ សូមរង់ចាំបន្តិច ហើយព្យាយាមម្តងទៀត។",
    zh: "请求过于频繁，请稍候重试。",
  },
  rate_limit_exceeded: {
    en: "Too many requests. Please wait a minute and try again.",
    km: "សំណើច្រើនពេក។ សូមរង់ចាំមួយនាទី ហើយព្យាយាមម្តងទៀត។",
    zh: "请求过于频繁，请等待一分钟后重试。",
  },
  daily_limit_exceeded: {
    en: "The daily activation limit has been reached. Please try again tomorrow.",
    km: "បានឈានដល់ដែនកំណត់ដំណើរការប្រចាំថ្ងៃ។ សូមព្យាយាមថ្ងៃស្អែក។",
    zh: "已达到今日激活上限，请明天再试。",
  },
  already_running: {
    en: "This Gmail account is already being processed. Please wait for it to finish.",
    km: "គណនី Gmail នេះកំពុងត្រូវបានដំណើរការរួចហើយ។ សូមរង់ចាំឲ្យបញ្ចប់។",
    zh: "该 Gmail 账户正在处理中，请等待完成。",
  },
  already_success: {
    en: "This Gmail account has already been activated successfully.",
    km: "គណនី Gmail នេះត្រូវបានដំណើរការដោយជោគជ័យរួចហើយ។",
    zh: "该 Gmail 账户已成功激活。",
  },
  job_not_found: {
    en: "Activation job not found.",
    km: "រកមិនឃើញភារកិច្ចដំណើរការទេ។",
    zh: "未找到激活任务。",
  },
  unauthorized: {
    en: "Not allowed to read this activation job.",
    km: "គ្មានសិទ្ធិអានភារកិច្ចដំណើរការនេះទេ។",
    zh: "无权查看此激活任务。",
  },
  maintenance: {
    en: "The service is under maintenance. Please try again later.",
    km: "សេវាកម្មកំពុងជួសជុល។ សូមព្យាយាមម្តងទៀតពេលក្រោយ។",
    zh: "服务正在维护中，请稍后再试。",
  },
  pixel_maintenance: {
    en: "The service is under maintenance. Please try again later.",
    km: "សេវាកម្មកំពុងជួសជុល។ សូមព្យាយាមម្តងទៀតពេលក្រោយ។",
    zh: "服务正在维护中，请稍后再试。",
  },
  internal_error: {
    en: "The activation service hit an internal error. Please try again.",
    km: "សេវាកម្មដំណើរការជួបកំហុសខាងក្នុង។ សូមព្យាយាមម្តងទៀត។",
    zh: "激活服务发生内部错误，请重试。",
  },
  submit_rejected: {
    en: "The activation request was rejected. Please check your details.",
    km: "សំណើដំណើរការត្រូវបានបដិសេធ។ សូមពិនិត្យព័ត៌មានរបស់អ្នក។",
    zh: "激活请求被拒绝，请检查您的信息。",
  },

  // --- Job-level failures ---
  pixel_err_wrong_password: {
    en: "Wrong password. Verify your Google account password and try again.",
    km: "ពាក្យសម្ងាត់មិនត្រឹមត្រូវ។ សូមពិនិត្យពាក្យសម្ងាត់គណនី Google របស់អ្នក។",
    zh: "密码错误。请核对您的 Google 账户密码后重试。",
  },
  pixel_err_email_not_found: {
    en: "This Google account does not exist. Use a valid Gmail address.",
    km: "គណនី Google នេះមិនមានទេ។ សូមប្រើអាសយដ្ឋាន Gmail ត្រឹមត្រូវ។",
    zh: "该 Google 账户不存在，请使用有效的 Gmail 地址。",
  },
  pixel_err_email_access_deleted: {
    en: "This Google account has been suspended or deleted. Use a different email.",
    km: "គណនី Google នេះត្រូវបានផ្អាក ឬលុប។ សូមប្រើអ៊ីមែលផ្សេង។",
    zh: "该 Google 账户已被停用或删除，请更换邮箱。",
  },
  pixel_err_email_format: {
    en: "Invalid email format. Please enter a valid Gmail address.",
    km: "ទម្រង់អ៊ីមែលមិនត្រឹមត្រូវ។ សូមបញ្ចូលអាសយដ្ឋាន Gmail ត្រឹមត្រូវ។",
    zh: "邮箱格式无效，请输入有效的 Gmail 地址。",
  },
  pixel_err_underage: {
    en: "The account must be at least 18 years old to be eligible.",
    km: "គណនីត្រូវមានអាយុយ៉ាងតិច 18 ឆ្នាំ ទើបមានសិទ្ធិ។",
    zh: "账户须年满 18 岁才符合条件。",
  },
  pixel_err_no_totp: {
    en: "Two-factor authentication is not enabled on this account. Enable it and try again.",
    km: "ការផ្ទៀងផ្ទាត់ពីរជាន់មិនត្រូវបានបើកទេ។ សូមបើកវា ហើយព្យាយាមម្តងទៀត។",
    zh: "该账户未启用两步验证。请启用后重试。",
  },
  pixel_err_2fa_not_enabled: {
    en: "Two-factor authentication is not active. Enable it in your Google account settings.",
    km: "ការផ្ទៀងផ្ទាត់ពីរជាន់មិនដំណើរការទេ។ សូមបើកក្នុងការកំណត់គណនី Google។",
    zh: "两步验证未启用，请在 Google 账户设置中开启。",
  },
  pixel_err_2fa_method: {
    en: "This 2FA method is not supported. Switch to an authenticator app (TOTP) and try again.",
    km: "វិធីសាស្ត្រ 2FA នេះមិនត្រូវបានគាំទ្រទេ។ សូមប្តូរទៅកម្មវិធី Authenticator (TOTP)។",
    zh: "不支持此 2FA 方式。请改用验证器应用（TOTP）后重试。",
  },
  pixel_err_totp_no_backup: {
    en: "2FA verification failed. Re-check your 32-character secret key and try again.",
    km: "ការផ្ទៀងផ្ទាត់ 2FA បរាជ័យ។ សូមពិនិត្យកូនសោ 32 តួឡើងវិញ។",
    zh: "2FA 验证失败。请重新核对 32 位密钥后重试。",
  },
  pixel_err_backup_fail: {
    en: "All backup codes were rejected. Generate new backup codes in your Google account.",
    km: "លេខកូដបម្រុងទាំងអស់ត្រូវបានបដិសេធ។ សូមបង្កើតលេខកូដបម្រុងថ្មី។",
    zh: "所有备用验证码均被拒绝。请在 Google 账户中生成新的备用验证码。",
  },
  pixel_err_no_offer: {
    en: "This account is not eligible for the offer. Leave any family group first, or the account may have already used Gemini Pro.",
    km: "គណនីនេះមិនមានសិទ្ធិទទួលការផ្តល់ជូនទេ។ សូមចាកចេញពីក្រុមគ្រួសារជាមុនសិន ឬគណនីនេះអាចបានប្រើ Gemini Pro រួចហើយ។",
    zh: "该账户不符合优惠资格。请先退出家庭组，或该账户可能已使用过 Gemini Pro。",
  },
  pixel_err_payment_fail: {
    en: "Payment could not be completed. Please try again later or contact support.",
    km: "ការទូទាត់មិនអាចបញ្ចប់បានទេ។ សូមព្យាយាមម្តងទៀត ឬទាក់ទងផ្នែកជំនួយ។",
    zh: "支付未能完成，请稍后重试或联系客服。",
  },
  pixel_err_paycard_btn: {
    en: "An open payment profile was detected. Close it in Google Pay settings, then retry.",
    km: "បានរកឃើញ payment profile ដែលបើកចំហ។ សូមបិទវាក្នុងការកំណត់ Google Pay រួចព្យាយាមម្តងទៀត។",
    zh: "检测到未关闭的付款资料。请在 Google Pay 设置中关闭后重试。",
  },
  pixel_err_paycard_creds: {
    en: "Payment details are incorrect. Verify the payment information and retry.",
    km: "ព័ត៌មានទូទាត់មិនត្រឹមត្រូវ។ សូមផ្ទៀងផ្ទាត់ រួចព្យាយាមម្តងទៀត។",
    zh: "付款信息有误。请核对后重试。",
  },
  pixel_err_paycard_security_lock: {
    en: "The payment provider locked the account for security. Please retry later.",
    km: "អ្នកផ្តល់សេវាទូទាត់បានចាក់សោគណនីដើម្បីសុវត្ថិភាព។ សូមព្យាយាមពេលក្រោយ។",
    zh: "支付服务商出于安全原因锁定了账户，请稍后重试。",
  },
  pixel_err_paycard_timeout: {
    en: "The payment verification timed out. Please retry later.",
    km: "ការផ្ទៀងផ្ទាត់ការទូទាត់អស់ពេល។ សូមព្យាយាមពេលក្រោយ។",
    zh: "支付验证超时，请稍后重试。",
  },
  pixel_err_paycard_json: {
    en: "Payment authentication failed. Please retry later.",
    km: "ការផ្ទៀងផ្ទាត់ការទូទាត់បរាជ័យ។ សូមព្យាយាមពេលក្រោយ។",
    zh: "支付认证失败，请稍后重试。",
  },
  pixel_err_payment_profile_verify: {
    en: "Google requires identity verification for the payment profile. Complete it manually, then retry.",
    km: "Google តម្រូវឲ្យផ្ទៀងផ្ទាត់អត្តសញ្ញាណសម្រាប់ payment profile។ សូមបំពេញដោយដៃ រួចព្យាយាមម្តងទៀត។",
    zh: "Google 要求对付款资料进行身份验证。请手动完成后重试。",
  },
  pixel_err_already_queued: {
    en: "A job for this email is already queued. Please wait for it to be processed.",
    km: "ភារកិច្ចសម្រាប់អ៊ីមែលនេះស្ថិតក្នុងជួររង់ចាំរួចហើយ។",
    zh: "该邮箱的任务已在队列中，请等待处理。",
  },
  pixel_err_already_running: {
    en: "A job for this email is already running. Please wait for it to finish.",
    km: "ភារកិច្ចសម្រាប់អ៊ីមែលនេះកំពុងដំណើរការរួចហើយ។",
    zh: "该邮箱的任务正在运行，请等待完成。",
  },
  pixel_err_already_success: {
    en: "This email was already activated successfully. No further action is needed.",
    km: "អ៊ីមែលនេះត្រូវបានដំណើរការដោយជោគជ័យរួចហើយ។",
    zh: "该邮箱已成功激活，无需进一步操作。",
  },
  pixel_err_no_device: {
    en: "All processing devices are busy. The job will retry shortly.",
    km: "ឧបករណ៍ដំណើរការទាំងអស់រវល់។ ភារកិច្ចនឹងព្យាយាមម្តងទៀតឆាប់ៗ។",
    zh: "所有处理设备均繁忙，任务将稍后重试。",
  },
  pixel_err_no_serial: {
    en: "Internal device error. Please try again later.",
    km: "កំហុសឧបករណ៍ខាងក្នុង។ សូមព្យាយាមពេលក្រោយ។",
    zh: "内部设备错误，请稍后重试。",
  },
  pixel_err_adb_connect: {
    en: "Device connection failed. The system is retrying automatically.",
    km: "ការតភ្ជាប់ឧបករណ៍បរាជ័យ។ ប្រព័ន្ធកំពុងព្យាយាមម្តងទៀតដោយស្វ័យប្រវត្តិ។",
    zh: "设备连接失败，系统正在自动重试。",
  },
  pixel_err_setup_stuck: {
    en: "Setup stalled. The system is retrying automatically.",
    km: "ការរៀបចំជាប់គាំង។ ប្រព័ន្ធកំពុងព្យាយាមម្តងទៀតដោយស្វ័យប្រវត្តិ។",
    zh: "初始化卡住，系统正在自动重试。",
  },
  pixel_err_pwweb: {
    en: "Internal automation error. The system is retrying automatically.",
    km: "កំហុសស្វ័យប្រវត្តិកម្មខាងក្នុង។ ប្រព័ន្ធកំពុងព្យាយាមម្តងទៀត។",
    zh: "内部自动化错误，系统正在自动重试。",
  },
  pixel_err_browser_or_app_not_secure: {
    en: "Google blocked the sign-in as insecure. Please retry later.",
    km: "Google បានទប់ស្កាត់ការចូលថាមិនមានសុវត្ថិភាព។ សូមព្យាយាមពេលក្រោយ។",
    zh: "Google 以不安全为由阻止了登录，请稍后重试。",
  },
  pixel_err_captcha: {
    en: "Google triggered a CAPTCHA challenge. Please retry after a short delay.",
    km: "Google បានបង្ហាញ CAPTCHA។ សូមព្យាយាមម្តងទៀតបន្តិចទៀត។",
    zh: "Google 触发了人机验证，请稍后重试。",
  },
  pixel_err_robot_verify: {
    en: "Google flagged this account for suspicious activity. Try a different Gmail account or retry later.",
    km: "Google បានសម្គាល់គណនីនេះថាសកម្មភាពគួរឲ្យសង្ស័យ។ សូមប្រើ Gmail ផ្សេង ឬព្យាយាមពេលក្រោយ។",
    zh: "Google 将该账户标记为可疑活动。请更换 Gmail 账户或稍后重试。",
  },
  pixel_err_login_timeout: {
    en: "Sign-in timed out. The system is retrying automatically.",
    km: "ការចូលអស់ពេល។ ប្រព័ន្ធកំពុងព្យាយាមម្តងទៀតដោយស្វ័យប្រវត្តិ។",
    zh: "登录超时，系统正在自动重试。",
  },
  pixel_err_couldnt_sign_in: {
    en: "Google blocked the login for security reasons. Please retry later.",
    km: "Google បានទប់ស្កាត់ការចូលដោយហេតុផលសុវត្ថិភាព។ សូមព្យាយាមពេលក្រោយ។",
    zh: "出于安全原因，Google 阻止了本次登录，请稍后重试。",
  },
  pixel_err_unknown: {
    en: "An unknown error occurred. The system is retrying automatically.",
    km: "កំហុសមិនស្គាល់បានកើតឡើង។ ប្រព័ន្ធកំពុងព្យាយាមម្តងទៀត។",
    zh: "发生未知错误，系统正在自动重试。",
  },
};

const FALLBACK: Messages = {
  en: "Activation failed",
  km: "ការដំណើរការបរាជ័យ",
  zh: "激活失败",
};

/**
 * Turns a machine-readable error key into a human-readable message.
 *
 * Unknown keys fall back to a generic message with the raw key appended so
 * support can still diagnose the failure. The key is filtered to the shape the
 * upstream API documents (snake_case identifiers) so nothing else the upstream
 * might return can be reflected into our UI.
 */
export function mapError(code: string, lang: Lang = "en"): string {
  const entry = ERROR_MESSAGES[code];
  if (entry) return entry[lang] ?? entry.en;

  const fallback = FALLBACK[lang] ?? FALLBACK.en;
  return /^[a-z0-9_]{1,48}$/i.test(code) ? `${fallback} (${code})` : fallback;
}
