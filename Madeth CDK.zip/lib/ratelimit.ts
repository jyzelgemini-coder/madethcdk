/**
 * In-memory fixed-window rate limiter.
 *
 * State lives in the process, so it is per-instance: fine for a single-node
 * deployment, and every limit here is a safety net rather than the only control
 * (single-use keys are enforced in SQLite, not by throttling).
 *
 * Note that Next.js middleware and route handlers run in separate runtimes and
 * therefore keep separate maps; callers must not assume shared counters.
 */
type Entry = { count: number; resetAt: number };

const buckets = new Map<string, Entry>();

/**
 * Ceiling on tracked keys. Without this, anything that derives a bucket from
 * request data (an IP header, an email) lets a client grow the map without
 * bound until the process runs out of memory.
 */
const MAX_KEYS = 20_000;
const SWEEP_INTERVAL_MS = 30_000;
let lastSweep = Date.now();

function sweep(now: number): void {
  for (const [key, entry] of buckets) {
    if (entry.resetAt < now) buckets.delete(key);
  }
  lastSweep = now;
}

function evictOldest(): void {
  // Map preserves insertion order, so the front is the least recently created.
  let toDrop = Math.ceil(buckets.size * 0.1);
  for (const key of buckets.keys()) {
    if (toDrop-- <= 0) break;
    buckets.delete(key);
  }
}

export interface LimitResult {
  limited: boolean;
  /** Seconds until the window resets, for the Retry-After header. */
  retryAfter: number;
}

/** Counts one hit against `key` and reports whether it exceeded `limit`. */
export function hit(key: string, limit: number, windowMs: number): LimitResult {
  const now = Date.now();

  if (now - lastSweep > SWEEP_INTERVAL_MS) sweep(now);

  const entry = buckets.get(key);
  if (!entry || entry.resetAt < now) {
    if (buckets.size >= MAX_KEYS) {
      sweep(now);
      if (buckets.size >= MAX_KEYS) evictOldest();
    }
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { limited: false, retryAfter: Math.ceil(windowMs / 1000) };
  }

  entry.count += 1;
  return {
    limited: entry.count > limit,
    retryAfter: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)),
  };
}

export function reset(key: string): void {
  buckets.delete(key);
}
