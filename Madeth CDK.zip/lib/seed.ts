import crypto from "node:crypto";

import { hashPassword } from "@/lib/auth";
import { countAdmins, createAdmin } from "@/lib/db";

const DEV_FALLBACK = { username: "admin", password: "admin123" };

/**
 * Creates the first admin account when the admins table is empty.
 *
 * In production the credentials must come from the environment. A published
 * default password on an internet-facing panel is the same as no password at
 * all, so if ADMIN_PASSWORD is missing we generate a random one and print it
 * once — the deployment stays locked rather than silently accepting admin/admin123.
 */
export function seedAdmin(): void {
  if (countAdmins() > 0) return;

  const prod = process.env.NODE_ENV === "production";
  const username = process.env.ADMIN_USERNAME || DEV_FALLBACK.username;
  let password = process.env.ADMIN_PASSWORD;

  if (!password) {
    if (prod) {
      password = crypto.randomBytes(18).toString("base64url");
      console.warn(
        `[seed] ADMIN_PASSWORD was not set. Generated a one-time password for "${username}": ${password}\n` +
          "[seed] Store it now and set ADMIN_PASSWORD in the environment — it will not be shown again."
      );
    } else {
      password = DEV_FALLBACK.password;
    }
  }

  createAdmin(username, hashPassword(password));
}
