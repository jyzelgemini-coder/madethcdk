/**
 * Input validation and sanitization utilities
 * Protects against injection attacks, XSS, and malformed data
 */

// Email validation (strict)
export function isValidEmail(email: string): boolean {
  if (!email || typeof email !== "string") return false;
  
  // Basic format check
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(email)) return false;
  
  // Length checks
  if (email.length > 254) return false; // RFC 5321
  const [local, domain] = email.split("@");
  if (local.length > 64 || domain.length > 255) return false;
  
  return true;
}

// CDK code validation (MD-CDK-XXXXXXX format)
export function isValidCdkCode(code: string): boolean {
  if (!code || typeof code !== "string") return false;
  
  // Must match MD-CDK-XXXXXXX format (alphanumeric after prefix)
  const cdkRegex = /^MD-CDK-[A-Z0-9]{7,20}$/;
  return cdkRegex.test(code);
}

// Password validation (prevent common attacks)
export function isValidPassword(password: string): boolean {
  if (!password || typeof password !== "string") return false;
  
  // Length check
  if (password.length < 4 || password.length > 128) return false;
  
  // Prevent null bytes (injection attempt)
  if (password.includes("\0")) return false;
  
  return true;
}

/**
 * Cheap shape check for the combined "2FA secret / backup codes" field.
 *
 * Only rejects inputs that cannot possibly be valid: empty, oversized, or
 * containing characters outside the Base32 alphabet, digits and the separators
 * users paste between codes. `normalizeSecret` in lib/pixel.ts is the authority
 * on which combinations are acceptable and produces the precise error message.
 *
 * It deliberately does NOT require a bare 32-char Base32 string: the Partner
 * API accepts a TOTP secret *plus* two or three backup codes, and an earlier
 * stricter regex here rejected that documented combination before the parser
 * ever saw it.
 */
export function isValid2FASecret(secret: string): boolean {
  if (!secret || typeof secret !== "string") return false;
  if (secret.length > 200) return false;

  // Zero-width characters are allowed through because normalizeSecret strips
  // them; they are common in pasted secrets.
  return /^[A-Za-z0-9\s,;|\u200B\uFEFF-]+$/.test(secret);
}

// Username validation (admin login)
export function isValidUsername(username: string): boolean {
  if (!username || typeof username !== "string") return false;
  
  // Alphanumeric, underscore, hyphen only
  const usernameRegex = /^[a-zA-Z0-9_-]{3,32}$/;
  return usernameRegex.test(username);
}

// Check for SQL injection patterns
export function containsSqlInjection(input: string): boolean {
  if (!input || typeof input !== "string") return false;
  
  const sqlPatterns = [
    /(\bUNION\b|\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b)/i,
    /(\bOR\b\s+\d+\s*=\s*\d+|\bAND\b\s+\d+\s*=\s*\d+)/i,
    /(--|;|\/\*|\*\/)/,
    /(\bEXEC\b|\bEXECUTE\b)/i,
  ];
  
  return sqlPatterns.some(pattern => pattern.test(input));
}

// Check for XSS patterns
export function containsXss(input: string): boolean {
  if (!input || typeof input !== "string") return false;
  
  const xssPatterns = [
    /<script[^>]*>.*?<\/script>/i,
    /javascript:/i,
    /on\w+\s*=/i, // Event handlers like onclick=
    /<iframe/i,
    /<object/i,
    /<embed/i,
  ];
  
  return xssPatterns.some(pattern => pattern.test(input));
}

// Check for path traversal attempts
export function containsPathTraversal(input: string): boolean {
  if (!input || typeof input !== "string") return false;
  
  const pathPatterns = [
    /\.\.\//,
    /\.\.\\/,
    /%2e%2e/i,
    /\.\.%2f/i,
  ];
  
  return pathPatterns.some(pattern => pattern.test(input));
}

// Validate plan label. Free-form so admins can name plans after the product
// they sell (e.g. "gemini-pro-pixel-1y"), but restricted to a safe charset.
export function isValidPlan(plan: string): boolean {
  if (typeof plan !== "string") return false;
  if (plan === "") return true;
  return /^[a-zA-Z0-9 ._-]{1,60}$/.test(plan);
}

// Validate task count
export function isValidTaskCount(count: number): boolean {
  return Number.isInteger(count) && count >= 1 && count <= 1000;
}

// Validate language
export function isValidLang(lang: string): boolean {
  return ["en", "km", "zh"].includes(lang);
}

// Check if input contains suspicious patterns
export function isSuspiciousInput(input: string): boolean {
  if (!input || typeof input !== "string") return false;
  
  return (
    containsSqlInjection(input) ||
    containsXss(input) ||
    containsPathTraversal(input)
  );
}
