/**
 * Attack-simulation suite.
 *
 *   npm run build && npm run audit:security
 *
 * Starts its own production server on a throwaway database, with the Pixel API
 * replaced by a local mock, then attacks it: forged sessions, missing CSRF
 * tokens, SQL/XSS payloads, oversized bodies, header spoofing, brute force,
 * path probes, task-id guessing and concurrent redemptions of one code. The live
 * database is never opened, so nothing here can touch real keys.
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";

const PORT = Number(process.env.AUDIT_PORT || 3199);
const MOCK_PORT = Number(process.env.AUDIT_MOCK_PORT || 4599);
const BASE = `http://127.0.0.1:${PORT}`;
const ADMIN = { username: "audit-admin", password: "audit-admin-password-9f2" };
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120 Safari/537.36";

const ACCOUNT = {
  password: "SomePassword123",
  twofa: "JBSWY3DPEHPK3PXPJBSWY3DPEHPK3PX2",
  lang: "en",
};

/* ------------------------------------------------------------------ mock API */

let submissions = [];
const jobKinds = new Map();
let nextJobId = 9000;

function startMock() {
  const server = http.createServer((req, res) => {
    let raw = "";
    req.on("data", (c) => (raw += c));
    req.on("end", () => {
      const send = (obj) => {
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify(obj));
      };
      let body = {};
      try {
        body = JSON.parse(raw);
      } catch {}

      if (req.url === "/api/v2/pixel/submit") {
        submissions.push({ gmail: body.gmail, totp: body.totp, backup: body.backup });

        if (String(body.gmail || "").startsWith("reject")) {
          return send({
            ok: true,
            submitted: 0,
            failed: 1,
            results: [{ gmail: body.gmail, ok: false, error: "wrong_password" }],
          });
        }

        const jobId = nextJobId++;
        jobKinds.set(jobId, String(body.gmail || "").startsWith("transient") ? "retry" : "running");
        // A little latency, so the concurrency check has a real window to race in.
        return setTimeout(
          () =>
            send({
              ok: true,
              submitted: 1,
              failed: 0,
              results: [{ gmail: body.gmail, ok: true, job_id: jobId, position: 3, cost: 42 }],
            }),
          250
        );
      }

      if (req.url === "/api/v2/pixel/status") {
        const kind = jobKinds.get(body.job_id);
        if (!kind) {
          return send({ ok: true, count: 1, results: [{ job_id: body.job_id, ok: false, error: "job_not_found" }] });
        }
        return send({
          ok: true,
          count: 1,
          results: [
            {
              job_id: body.job_id,
              email: "someone@gmail.com",
              ok: true,
              status: kind === "retry" ? "error" : "running",
              position: 0,
              current_step: kind === "retry" ? "Completed" : "Password",
              error_msg: kind === "retry" ? "pixel_err_login_timeout" : "",
              created_at: "2026-01-01 00:00:00",
              finished_at: "",
            },
          ],
        });
      }

      res.writeHead(404).end("{}");
    });
  });
  return new Promise((resolve) => server.listen(MOCK_PORT, "127.0.0.1", () => resolve(server)));
}

/* --------------------------------------------------------------- http client */

let cookie = "";
let csrf = "";

async function call(pathname, init = {}) {
  const headers = { "user-agent": UA, ...(init.headers || {}) };
  if (init.body && !headers["content-type"]) headers["content-type"] = "application/json";
  if (cookie && !init.noCookie) headers.cookie = cookie;

  const res = await fetch(BASE + pathname, { ...init, headers, redirect: "manual" });

  for (const raw of res.headers.getSetCookie?.() || []) {
    const pair = raw.split(";")[0];
    const name = pair.split("=")[0];
    const kept = (cookie ? cookie.split("; ") : []).filter((p) => !p.startsWith(name + "="));
    if (!/=$/.test(pair)) kept.push(pair);
    cookie = kept.join("; ");
  }

  const text = await res.text();
  let body = null;
  try {
    body = JSON.parse(text);
  } catch {}
  return { status: res.status, body, text, headers: res.headers };
}

/** A distinct trailing X-Forwarded-For entry gives a phase its own limiter bucket. */
const asIp = (ip) => ({ "x-forwarded-for": ip });

/* -------------------------------------------------------------- test harness */

const results = [];

function check(name, pass, detail) {
  results.push({ name, pass });
  const mark = pass ? "  ok  " : " FAIL ";
  console.log(`${mark} ${name}${detail ? `  — ${detail}` : ""}`);
}

function group(title) {
  console.log(`\n── ${title} ${"─".repeat(Math.max(0, 58 - title.length))}`);
}

/* ------------------------------------------------------------------ scenarios */

async function run() {
  group("Authentication and access control");

  check("unauthenticated key listing is refused", (await call("/api/admin/keys")).status === 401);
  check("unauthenticated log access is refused", (await call("/api/admin/logs")).status === 401);

  const forged = await call("/api/admin/logs", {
    noCookie: true,
    headers: { cookie: `cdk_admin_session=${ADMIN.username}:${Date.now() + 9e6}.deadbeefdeadbeef` },
  });
  check("a forged session cookie is refused", forged.status === 401, `status=${forged.status}`);

  const wrongPw = await call("/api/admin/login", {
    method: "POST",
    body: JSON.stringify({ username: ADMIN.username, password: "wrong-password" }),
    headers: asIp("10.0.0.1"),
  });
  const noUser = await call("/api/admin/login", {
    method: "POST",
    body: JSON.stringify({ username: "nosuchadmin", password: "wrong-password" }),
    headers: asIp("10.0.0.1"),
  });
  check(
    "a wrong password and an unknown user look identical",
    wrongPw.status === noUser.status && wrongPw.body?.error === noUser.body?.error,
    `"${wrongPw.body?.error}"`
  );

  let throttled = false;
  for (let i = 0; i < 8 && !throttled; i++) {
    const r = await call("/api/admin/login", {
      method: "POST",
      body: JSON.stringify({ username: ADMIN.username, password: `guess-${i}` }),
      headers: asIp("10.0.0.99"),
    });
    throttled = r.status === 429;
  }
  check("login brute force is throttled", throttled);

  const crossLogin = await call("/api/admin/login", {
    method: "POST",
    body: JSON.stringify(ADMIN),
    headers: { origin: "https://evil.example", ...asIp("10.0.0.2") },
  });
  check("a cross-site login attempt is blocked", crossLogin.status === 403, `status=${crossLogin.status}`);

  const login = await call("/api/admin/login", {
    method: "POST",
    body: JSON.stringify(ADMIN),
    headers: { origin: BASE, ...asIp("10.0.0.3") },
  });
  csrf = login.body?.csrfToken || "";
  check("the admin can sign in", login.body?.success === true && !!csrf, `status=${login.status}`);
  if (!csrf) throw new Error("cannot continue without a session");

  group("CSRF protection");

  const write = (headers, code) =>
    call("/api/admin/keys", {
      method: "POST",
      headers,
      body: JSON.stringify({ codes: [code], taskCount: 1, plan: "audit" }),
    });

  check("a write with no CSRF token is refused", (await write({}, "MD-CDK-CSRFA01")).status === 403);
  check(
    "a write with a wrong CSRF token is refused",
    (await write({ "x-csrf-token": "a".repeat(64) }, "MD-CDK-CSRFB02")).status === 403
  );
  check(
    "a cross-site write is refused even with a valid token",
    (await write({ "x-csrf-token": csrf, origin: "https://evil.example" }, "MD-CDK-CSRFC03")).status === 403
  );

  group("Injection and malformed input");

  const check400 = async (name, payload, ip) => {
    const r = await call("/api/v1/cdk/check", { method: "POST", body: JSON.stringify(payload), headers: asIp(ip) });
    check(name, r.status === 400, `status=${r.status}`);
  };
  await check400("a SQL injection payload in a code is refused", { code: "MD-CDK-X' UNION SELECT * FROM keys--" }, "10.0.1.1");
  await check400("an XSS payload in a code is refused", { code: "<script>alert(1)</script>" }, "10.0.1.1");
  await check400("a path traversal payload in a code is refused", { code: "../../../etc/passwd" }, "10.0.1.1");

  const huge = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: "MD-CDK-AAAA111", email: "a@gmail.com", password: "x".repeat(50_000) }),
    headers: asIp("10.0.1.2"),
  });
  check("an oversized body is refused", huge.status === 413, `status=${huge.status}`);

  const wrongType = await call("/api/v1/cdk/check", {
    method: "POST",
    headers: { "content-type": "text/plain", ...asIp("10.0.1.3") },
    body: "code=MD-CDK-AAAA111",
  });
  check("a non-JSON API post is refused", wrongType.status === 415, `status=${wrongType.status}`);

  const badMethod = await call("/api/v1/cdk/activate", { method: "GET", headers: asIp("10.0.1.4") });
  check("GET on the activation endpoint is refused", badMethod.status === 405, `status=${badMethod.status}`);

  const nonGmail = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: "MD-CDK-AAAA111", email: "someone@outlook.com" }),
    headers: asIp("10.0.1.5"),
  });
  check("a non-Gmail address is refused", nonGmail.status === 400, `status=${nonGmail.status}`);

  group("Reconnaissance and information disclosure");

  for (const probe of ["/.env", "/.git/config", "/wp-admin", "/admin.php", "/backup.sql", "/config.json"]) {
    const r = await call(probe, { headers: asIp("10.0.2.1") });
    check(`probing ${probe} returns an empty 404`, r.status === 404 && r.text.length === 0, `status=${r.status} bytes=${r.text.length}`);
  }

  const scanner = await call("/", { headers: { "user-agent": "sqlmap/1.7", ...asIp("10.0.2.2") } });
  check("a scanner user-agent gets nothing back", scanner.status === 404 && scanner.text.length === 0);

  const unknown = await call("/this-path-does-not-exist-12345", { headers: asIp("10.0.2.3") });
  const leaks = {
    stackFrame: /\bat [\w.$]+ \([^)]*:\d+:\d+\)/.test(unknown.text),
    serverPath: /[A-Za-z]:\\\\|\/home\/|\/var\/www|node_modules/.test(unknown.text),
    version: /next@|"version":|\bv?1[45]\.\d+\.\d+/.test(unknown.text),
    routes: /api\/admin|cdk\/activate/.test(unknown.text),
  };
  const leaked = Object.entries(leaks).filter(([, v]) => v).map(([k]) => k);
  check(
    "an unknown path returns a generic 404 with no internals",
    unknown.status === 404 && leaked.length === 0 && /Page not found/i.test(unknown.text),
    leaked.length ? `leaked=${leaked}` : `status=${unknown.status}`
  );

  const h = (await call("/", { headers: asIp("10.0.2.4") })).headers;
  const csp = h.get("content-security-policy") || "";
  check("no x-powered-by header", !h.get("x-powered-by"));
  check("nosniff and frame denial are set", h.get("x-content-type-options") === "nosniff" && h.get("x-frame-options") === "DENY");
  check("the CSP blocks framing and plugins", csp.includes("frame-ancestors 'none'") && csp.includes("object-src 'none'"));
  check("the CSP still allows the fonts the layout loads", csp.includes("fonts.googleapis.com") && csp.includes("fonts.gstatic.com"));

  const robots = await call("/robots.txt", { headers: asIp("10.0.2.5") });
  check("robots.txt hides /admin and /api", robots.text.includes("/admin") && robots.text.includes("/api/"));

  group("Key management");

  const codes = ["MD-CDK-AUDA101", "MD-CDK-AUDB202", "MD-CDK-AUDC303", "MD-CDK-AUDD404", "MD-CDK-AUDE505"];
  const created = await call("/api/admin/keys", {
    method: "POST",
    headers: { "x-csrf-token": csrf },
    body: JSON.stringify({ codes, taskCount: 1, plan: "audit" }),
  });
  check("keys can be created", created.body?.created?.length === codes.length, JSON.stringify(created.body?.created));

  const dupe = await call("/api/admin/keys", {
    method: "POST",
    headers: { "x-csrf-token": csrf },
    body: JSON.stringify({ codes: [codes[0]], taskCount: 1, plan: "audit" }),
  });
  check("an existing code is reported as a duplicate, not re-created", dupe.body?.duplicates?.length === 1 && dupe.body?.created?.length === 0);

  const tooMany = await call("/api/admin/keys", {
    method: "POST",
    headers: { "x-csrf-token": csrf },
    body: JSON.stringify({
      codes: Array.from({ length: 1001 }, (_, i) => `MD-CDK-BULK${String(i).padStart(3, "0")}`),
      taskCount: 1,
      plan: "audit",
    }),
  });
  check("an oversized batch is refused", tooMany.status === 400, `status=${tooMany.status}`);

  const patch = (id) =>
    call(`/api/admin/keys/${id}`, {
      method: "PATCH",
      headers: { "x-csrf-token": csrf },
      body: JSON.stringify({ action: "disable" }),
    });
  const malformed = await patch("not-a-number");
  const missing = await patch("987654");
  check(
    "a malformed key id is indistinguishable from a missing one",
    malformed.status === 404 && malformed.text === missing.text,
    `malformed=${malformed.status} missing=${missing.status}`
  );

  group("Single use and the audit trail");

  submissions = [];
  const target = codes[0];
  const [a, b] = await Promise.all([
    call("/api/v1/cdk/activate", {
      method: "POST",
      body: JSON.stringify({ ...ACCOUNT, code: target, email: "audit.one@gmail.com" }),
      headers: asIp("10.0.3.1"),
    }),
    call("/api/v1/cdk/activate", {
      method: "POST",
      body: JSON.stringify({ ...ACCOUNT, code: target, email: "audit.two@gmail.com" }),
      headers: asIp("10.0.3.2"),
    }),
  ]);
  check(
    "two simultaneous redemptions of one code: exactly one wins",
    [a.status, b.status].sort().join() === "200,409",
    `statuses=${[a.status, b.status].join()}`
  );
  check("only one upstream job was submitted", submissions.length === 1, `submits=${submissions.length}`);

  const winner = a.status === 200 ? a : b;
  const taskId = winner.body.taskId;
  check("the task id carries real entropy", /^T-[0-9A-Z]+-[A-Z2-7]{12}$/.test(taskId), taskId);

  const reuse = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: target, email: "audit.three@gmail.com" }),
    headers: asIp("10.0.3.3"),
  });
  check("a used code cannot be redeemed again", reuse.status === 409, `status=${reuse.status}`);

  const allKeys = (await call("/api/admin/keys?limit=1000")).body?.keys || [];
  const usedKey = allKeys.find((k) => k.code === target);
  const reEnable = await call(`/api/admin/keys/${usedKey.id}`, {
    method: "PATCH",
    headers: { "x-csrf-token": csrf },
    body: JSON.stringify({ action: "enable" }),
  });
  check("an admin cannot re-enable a used key", reEnable.status === 400, `status=${reEnable.status}`);

  await patch(allKeys.find((k) => k.code === codes[3]).id);
  const disabled = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: codes[3], email: "audit.disabled@gmail.com" }),
    headers: asIp("10.0.3.7"),
  });
  check("a disabled code cannot be redeemed", disabled.status === 403, `status=${disabled.status}`);

  submissions = [];
  const withBackup = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({
      ...ACCOUNT,
      twofa: `${ACCOUNT.twofa} 59636051 87654321`,
      code: codes[1],
      email: "audit.backup@gmail.com",
    }),
    headers: asIp("10.0.3.4"),
  });
  check(
    "a TOTP secret plus backup codes is accepted and split correctly",
    withBackup.status === 200 && submissions[0]?.totp === ACCOUNT.twofa && submissions[0]?.backup?.length === 2,
    JSON.stringify(submissions[0])
  );

  const badSecret = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, twofa: "TOOSHORT", code: codes[2], email: "audit.short@gmail.com" }),
    headers: asIp("10.0.3.5"),
  });
  check("a malformed 2FA secret is refused", badSecret.status === 400, `status=${badSecret.status}`);

  const rejected = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: codes[2], email: "reject.me@gmail.com" }),
    headers: asIp("10.0.3.6"),
  });
  const stillOpen = await call("/api/v1/cdk/check", {
    method: "POST",
    body: JSON.stringify({ code: codes[2] }),
    headers: asIp("10.0.3.6"),
  });
  check(
    "a rejected submission hands the code back to the customer",
    rejected.body?.success === false && stillOpen.body?.success === true,
    `activate=${rejected.status} check=${stillOpen.status}`
  );

  group("Public endpoint exposure");

  const status = await call(`/api/v1/task/status?task_id=${encodeURIComponent(taskId)}`, { headers: asIp("10.0.4.1") });
  const payload = JSON.stringify(status.body);
  check("task status does not echo the CDK code", !payload.includes(target));
  check("task status masks the account email", status.body?.email?.includes("•") && !payload.includes("audit.one@gmail.com"), `email=${status.body?.email}`);
  check("task status never echoes the password", !payload.includes(ACCOUNT.password));

  const guessed = await call("/api/v1/task/status?task_id=T-ABC-GUESSGUESSGU", { headers: asIp("10.0.4.2") });
  check("a guessed task id reveals nothing", guessed.status === 404 && !guessed.text.includes("@"), `status=${guessed.status}`);

  group("Rate limiting and header spoofing");

  // Each request injects a different left-hand XFF entry while the entry the
  // proxy appends stays the same — the only thing a real attacker controls.
  let spoofBlocked = false;
  for (let i = 0; i < 8 && !spoofBlocked; i++) {
    const r = await call("/api/v1/cdk/activate", {
      method: "POST",
      body: JSON.stringify({ ...ACCOUNT, code: codes[3], email: `spoof${i}@gmail.com` }),
      headers: { "x-forwarded-for": `9.9.9.${i}, 203.0.113.7` },
    });
    spoofBlocked = r.status === 429;
  }
  check("forged X-Forwarded-For entries cannot buy a fresh quota", spoofBlocked);

  let guessBlocked = false;
  for (let i = 0; i < 26 && !guessBlocked; i++) {
    const r = await call("/api/v1/cdk/check", {
      method: "POST",
      body: JSON.stringify({ code: `MD-CDK-GUES${String(i).padStart(3, "0")}` }),
      headers: asIp("10.0.5.9"),
    });
    guessBlocked = r.status === 429;
  }
  check("brute-forcing codes against /cdk/check is throttled", guessBlocked);

  group("Activation log");

  const logs = await call("/api/admin/logs?limit=100");
  const row = logs.body?.logs?.find((l) => l.taskId === taskId);
  check("the activation is recorded", !!row, `total=${logs.body?.total}`);
  check("the log keeps the full code and email for the admin", row?.code === target && row?.email === "audit.one@gmail.com");
  check("the log records the client IP and device", !!row?.ip && !!row?.userAgent, `ip=${row?.ip}`);
  check("the log joins the plan from the key", row?.plan === "audit", `plan=${row?.plan}`);
  check("the log never contains credentials", !JSON.stringify(logs.body).includes(ACCOUNT.password));

  check("the log page size is clamped", (await call("/api/admin/logs?limit=999999")).body?.limit === 200);

  const searched = await call("/api/admin/logs?q=audit.one%40gmail.com");
  check("searching the log by email works", searched.body?.logs?.length === 1 && searched.body.logs[0].taskId === taskId, `hits=${searched.body?.logs?.length}`);
  check("a LIKE wildcard in the search is treated literally", (await call("/api/admin/logs?q=%25")).body?.logs?.length === 0);

  const byStatus = await call("/api/admin/logs?status=processing");
  check(
    "the status filter works",
    byStatus.body?.logs?.length > 0 && byStatus.body.logs.every((l) => l.status === "processing"),
    `hits=${byStatus.body?.logs?.length}`
  );
  check("an injected status filter is ignored rather than executed", (await call("/api/admin/logs?status=' OR 1=1--")).body?.success === true);

  group("Upstream error handling");

  const transient = await call("/api/v1/cdk/activate", {
    method: "POST",
    body: JSON.stringify({ ...ACCOUNT, code: codes[4], email: "transient@gmail.com" }),
    headers: asIp("10.0.6.1"),
  });
  const transientStatus =
    transient.status === 200
      ? await call(`/api/v1/task/status?task_id=${transient.body.taskId}`, { headers: asIp("10.0.6.2") })
      : null;
  check(
    "a retryable upstream error keeps the task running instead of failing it",
    transientStatus?.body?.status === "processing",
    transientStatus ? `status=${transientStatus.body?.status}` : `activate=${transient.status}`
  );
}

/* ------------------------------------------------------------------- runner */

async function waitForServer(deadlineMs = 60_000) {
  const until = Date.now() + deadlineMs;
  while (Date.now() < until) {
    try {
      const res = await fetch(BASE + "/robots.txt");
      if (res.ok) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 400));
  }
  return false;
}

function kill(child) {
  if (!child || child.exitCode !== null) return;
  if (process.platform === "win32") {
    spawn("taskkill", ["/pid", String(child.pid), "/T", "/F"], { stdio: "ignore" });
  } else {
    child.kill("SIGTERM");
  }
}

async function main() {
  if (!fs.existsSync(path.join(process.cwd(), ".next", "BUILD_ID"))) {
    console.error("No production build found. Run `npm run build` first.");
    process.exit(1);
  }

  const dbPath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "cdk-audit-")), "audit.db");
  const mock = await startMock();

  const server = spawn("npx", ["next", "start", "-p", String(PORT), "-H", "127.0.0.1"], {
    shell: true,
    env: {
      ...process.env,
      NODE_ENV: "production",
      CDK_DB_PATH: dbPath,
      ADMIN_USERNAME: ADMIN.username,
      ADMIN_PASSWORD: ADMIN.password,
      ADMIN_SECRET: "audit-only-secret-" + "9".repeat(32),
      TRUSTED_PROXY_HOPS: "1",
      PIXEL_API_BASE: `http://127.0.0.1:${MOCK_PORT}`,
      PIXEL_API_KEY: "audit-key",
    },
    stdio: ["ignore", "pipe", "pipe"],
  });

  let serverLog = "";
  server.stdout.on("data", (d) => (serverLog += d));
  server.stderr.on("data", (d) => (serverLog += d));

  console.log(`Auditing a throwaway instance on ${BASE}`);

  let failures = 1;
  try {
    if (!(await waitForServer())) {
      console.error("The server did not come up:\n" + serverLog);
      process.exit(1);
    }
    await run();

    failures = results.filter((r) => !r.pass).length;
    console.log(`\n${results.length - failures}/${results.length} checks passed`);
    for (const f of results.filter((r) => !r.pass)) console.log(`  failed: ${f.name}`);
  } catch (err) {
    console.error("\nThe audit crashed:", err);
    if (serverLog) console.error("server output:\n" + serverLog);
  } finally {
    kill(server);
    mock.close();
    // Give the child a moment to release the temp database before removing it.
    await new Promise((r) => setTimeout(r, 700));
    fs.rmSync(path.dirname(dbPath), { recursive: true, force: true });
  }

  process.exit(failures ? 1 : 0);
}

main();
