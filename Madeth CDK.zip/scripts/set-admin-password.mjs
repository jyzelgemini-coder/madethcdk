/**
 * Changes an admin password.
 *
 * ADMIN_PASSWORD in the environment only seeds the very first admin, so once the
 * account exists this is the way to rotate its password.
 *
 *   node scripts/set-admin-password.mjs                 # random password
 *   node scripts/set-admin-password.mjs "my password"   # chosen password
 *   node scripts/set-admin-password.mjs "pw" username    # a specific account
 */
import crypto from "node:crypto";
import path from "node:path";

import Database from "better-sqlite3";

const HASH_ROUNDS = 100_000;
const MIN_LENGTH = 12;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, HASH_ROUNDS, 64, "sha512").toString("hex");
  return `${salt}:${hash}`;
}

const [rawPassword, rawUser] = process.argv.slice(2);
const generated = !rawPassword;
const password = rawPassword || crypto.randomBytes(15).toString("base64url");

if (!generated && password.length < MIN_LENGTH) {
  console.error(`Password must be at least ${MIN_LENGTH} characters.`);
  process.exit(1);
}

const db = new Database(path.join(process.cwd(), "data", "cdk.db"));
const admins = db.prepare("SELECT id, username FROM admins ORDER BY id").all();

if (admins.length === 0) {
  console.error("No admin accounts exist yet. Start the app once to seed one.");
  process.exit(1);
}

const target = rawUser
  ? admins.find((a) => a.username === rawUser)
  : admins[0];

if (!target) {
  console.error(
    `No admin named "${rawUser}". Existing: ${admins.map((a) => a.username).join(", ")}`
  );
  process.exit(1);
}

db.prepare("UPDATE admins SET password_hash = ? WHERE id = ?").run(
  hashPassword(password),
  target.id
);

console.log(`Password updated for "${target.username}".`);
if (generated) console.log(`New password: ${password}`);
console.log("Existing sessions stay valid until they expire; log out to end them now.");
